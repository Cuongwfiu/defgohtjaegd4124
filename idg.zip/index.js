const next = require('next')
const { parse } = require('url')
const axios = require('axios')
const express = require('express')
const cors = require('cors')
const bodyParser = require('body-parser')
const http = require('http')
const Router = require('./backend/router')
const useSocket = require('./backend/socket.io')
const fs = require('fs')
const path = require('path')
const fileUpload = require('express-fileupload')





const binanceEmit = async(socket, time, nameTrade) => {
    if (time) {
        const urlData = `https://api.binance.com/api/v3/klines?symbol=${nameTrade}USDT&interval=${time}&limit=1000`
        const res = await axios.get(urlData)
        socket.emit('data-crypto', res.data)
    } else {
        const urlData = `https://api.binance.com/api/v3/klines?symbol=${nameTrade}USDT&interval=15m&limit=1000`
        const res = await axios.get(urlData)
        socket.emit('data-crypto', res.data)
    }

}

const cartUserEmit = async function(socket, email) {
    const urlCart = path.join(__dirname, './backend/router/dataCart.json')
    const data = JSON.parse(fs.readFileSync(urlCart))
    const filterData = data.filter(item => item.email === email)

    socket.emit('send-cart', { data: filterData })
}
const coinUserEmit = async function(socket, email, token) {
    const urlUser = path.join(__dirname, './backend/router/dataUser.json')
    const data = JSON.parse(fs.readFileSync(urlUser))
    const findData = data.find(item => {
        if (item.email === email) {
            if (item.token === token) {
                return item
            }
        }
    })
    if (findData) {
        socket.emit('send-coin', { coin: findData.coin })
    }

}
const chatUserAdmin = async(socket, token) => {
        const urlUser = path.join(__dirname, './backend/router/dataUser.json')
        const dataUser = JSON.parse(fs.readFileSync(path.join(urlUser)))
        const arrEmail = dataUser.map(item => item.email)
        const urlAdmin = path.join(__dirname, './backend/router/admin.json')
        const dataAdmin = JSON.parse(fs.readFileSync(path.join(urlAdmin)))
        const findAdmin = dataAdmin.find(item => item.token === token)
        if (findAdmin) {
            const urlChat = path.join(__dirname, './backend/router/dataChat.json')
            const dataChat = JSON.parse(fs.readFileSync(path.join(urlChat)))
            const newArr = arrEmail.map(item => {
                const filterSeend = dataChat.filter(itemz => itemz.email === item && itemz.seender == false && itemz.active == "user").length
                return {
                    email: item,
                    quatitySeender: filterSeend
                }
            })
            socket.emit('send-data-chat', { data: newArr })
        }
    }
    // getuser
const getUser = (token, socket) => {
        const urlAdmin = path.join(__dirname, './backend/router/admin.json')
        const dataAdmin = JSON.parse(fs.readFileSync(urlAdmin))
        const findAdmin = dataAdmin.find((item) => {
            if (token == item.token) {
                return item
            }
        })
        if (findAdmin) {
            const urlUser = path.join(__dirname, './backend/router/dataUser.json')
            const cartUser = path.join(__dirname, './backend/router/dataCart.json')
            const dataCart = JSON.parse(fs.readFileSync(cartUser))
            const dataUser = JSON.parse(fs.readFileSync(urlUser))

            const billUser = path.join(__dirname, './backend/router/billUser.json')
            const dataBill = JSON.parse(fs.readFileSync(billUser))
            const mapData = dataUser.map(item => {
                const userAwait = dataCart.filter(itemz => {
                    if (itemz) {
                        if (itemz.email === item.email) {
                            return itemz.people === ''
                        }
                    }
                }).length
                const billLength = dataBill.filter(itemz => {
                    if (itemz) {
                        if (itemz.email === item.email) {
                            return itemz.status == 0
                        }
                    }
                }).length
                const obj = {
                    resultAwait: userAwait,
                    resultBill: billLength,
                    email: item.email,
                    banking: item.banking,
                    coin: item.coin
                }
                return obj
            })
            socket.emit('res-user', { data: mapData })
        }
    }
    // bill-user
const billUserEmit = async function(socket, email) {
    const urlBill = path.join(__dirname, './backend/router/billUser.json')
    const data = JSON.parse(fs.readFileSync(urlBill))
    const filterData = data.filter(item => item.email === email)
    socket.emit('send-bill', { data: filterData })
}
const server = express()
server.use(cors({
    origin: "*"
}))
server.use(bodyParser.urlencoded({ extended: true }))
server.use(bodyParser.json())
server.use(fileUpload())
server.use('/', Router)
server.use('/file-img', express.static(path.join('./icon')))
server.use('/upload-data', express.static(path.join('./upload')))
const httpServer = http.createServer(server)
useSocket(httpServer, (socket, io) => {
    try {
        let cryptoInterval;
        let cartUserInterval
        let coinUserInterval
        let chatAdminInterval
        let getUserInterval
        let billUserInterval
        socket.on('crypto', ({ time, intervalTime, nameTrade }) => {
            binanceEmit(socket, null, nameTrade)
            if (cryptoInterval) {
                clearInterval(cryptoInterval)
            }
            cryptoInterval = setInterval(() => {
                binanceEmit(socket, time, nameTrade)
            }, 60000 * intervalTime)

        })

        socket.on('cart-user', ({ email }) => {
            cartUserEmit(socket, email)
            if (cartUserInterval) {
                clearInterval(cartUserInterval)
            }
            cartUserInterval = setInterval(() => {
                cartUserEmit(socket, email)
            }, 2000)
        })

        socket.on('coin-user', ({ email, token }) => {
                coinUserEmit(socket, email, token)
                if (coinUserInterval) {
                    clearInterval(coinUserInterval)
                }
                coinUserInterval = setInterval(() => {
                    coinUserEmit(socket, email, token)
                }, 2000)
            })
            // Chat
        socket.on('get-chat-admin', ({ token }) => {
            chatUserAdmin(socket, token)
            chatAdminInterval = setInterval(() => {
                chatUserAdmin(socket, token)
            }, 2000)
        })


        // getUser
        socket.on('admin-get-user', ({ token }) => {
                getUser(token, socket)
                if (getUserInterval) {
                    clearInterval(coinUserInterval)
                }
                getUserInterval = setInterval(() => {
                    getUser(token, socket)
                }, 2000)


            })
            // bill-user
        socket.on('bill-user', ({ email }) => {
            billUserEmit(socket, email)
            if (billUserInterval) {
                clearInterval(billUserInterval)
            }
            billUserInterval = setInterval(() => {
                billUserEmit(socket, email)
            }, 2000)
        })


        socket.on('admin-join', ({ email, token }) => {
            const urlAdmin = path.join(__dirname, './backend/router/admin.json')
            const dataAdmin = JSON.parse(fs.readFileSync(path.join(urlAdmin)))
            const findAdmin = dataAdmin.find(item => {
                if (item.token === token) {
                    return item
                }
            })
            if (findAdmin) {
                const urlChat = path.join(__dirname, './backend/router/dataChat.json')
                const datachat = JSON.parse(fs.readFileSync(path.join(urlChat)))
                const mapDataChat = datachat.map(item => {
                    if (item.email === email) {
                        item.seender = true
                    }
                    return item
                })
                fs.writeFileSync(path.join(urlChat), JSON.stringify(mapDataChat))
                const filterChat = mapDataChat.filter(item => {
                    return item.email == email
                }).sort((a, b) => a.date - b.date)
                socket.emit('data-chat-all', { data: filterChat })
                socket.join(email)
            }

        })
        socket.on('user-join', ({ email, token }) => {
            const urlUser = path.join(__dirname, './backend/router/dataUser.json')
            const dataUser = JSON.parse(fs.readFileSync(path.join(urlUser)))
            const findUser = dataUser.find(item => {
                if (item.token === token) {
                    return item
                }
            })
            if (findUser) {

                const urlChat = path.join(__dirname, './backend/router/dataChat.json')
                const datachat = JSON.parse(fs.readFileSync(path.join(urlChat)))
                const filterChat = datachat.filter(item => {
                    return item.email == email
                }).sort((a, b) => a.date - b.date)
                socket.emit('data-chat-all', { data: filterChat })
                socket.join(email)
            }

        })
        socket.on('chat', ({ email, msg, active, date, type, ext }) => {
            const urlChat = path.join(__dirname, './backend/router/dataChat.json')
            const datachat = JSON.parse(fs.readFileSync(path.join(urlChat)))
            if (type == 'text') {
                const obj = {
                    email: email,
                    msg: msg,
                    seender: false,
                    date: date,
                    active: active,
                    type: type,
                    notification: false
                }

                datachat.push(obj)
                fs.writeFileSync(path.join(urlChat), JSON.stringify(datachat))
                const filterDataChat = datachat.filter(data => data.email === email).sort((a, b) => a.date - b.date)
                io.to(email).emit('chat', { data: filterDataChat })
            } else {
                const uploadPath = path.join(__dirname, 'upload')
                const dirUpload = fs.readdirSync(uploadPath)
                const funcFindFile = (arr, str) => {
                    return arr.some(item => item == str)
                }
                let str = ''
                let i = 1
                do {
                    i++
                    str = `${i}.${ext}`
                } while (funcFindFile(dirUpload, str));
                server.use('/upload-data', express.static(path.join('./upload')))

                fs.writeFileSync(path.join(__dirname, 'upload', `${str}`), msg)
                const urlImage = `/upload-data/${str}`
                const obj = {
                    email: email,
                    msg: urlImage,
                    seender: false,
                    date: date,
                    active: active,
                    type: type,
                    notification: false
                }
                datachat.push(obj)
                fs.writeFileSync(path.join(urlChat), JSON.stringify(datachat))
                const filterDataChat = datachat.filter(data => data.email === email).sort((a, b) => a.date - b.date)
                io.to(email).emit('chat', { data: filterDataChat })
            }

        })



        // 
        socket.on('disconnect', () => {
            if (billUserInterval) {
                clearInterval(billUserInterval)
            }
            if (cryptoInterval) {
                clearInterval(cryptoInterval);
            }
            if (getUserInterval) {
                clearInterval(getUserInterval)
            }
            if (cartUserInterval) {
                clearInterval(cartUserInterval)
            }
            if (coinUserInterval) {
                clearInterval(coinUserInterval)
            }
            if (chatAdminInterval) {
                clearInterval(chatAdminInterval)
            }
        })
    } catch (error) {
        if (error) {
            console.log('lỗi socket io');
        }
    }

})

httpServer.listen(4900, (err) => {
    if (err) throw err;
})