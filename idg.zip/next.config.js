/** @type {import('next').NextConfig} */
const nextConfig = {
    reactStrictMode: true,
    swcMinify: true,
    images: {
        domains: ['www.idg88fx.com']
    },
    eslint: {
        ignoreDuringBuilds: true
    },
    compiler: {
        styledComponents: true
    }
}

module.exports = nextConfig