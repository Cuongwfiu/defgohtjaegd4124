const io = require('socket.io')

const options = {
    cors: {
        origin: "*"
    },
    maxHttpBufferSize: 50 * 1024 * 1024,
}


const useSocket = (httpServer, callback) => {
    const socketIO = io(httpServer, options);
    socketIO.on('connection', (socket) => {
        callback(socket, socketIO)
    })



}


module.exports = useSocket;