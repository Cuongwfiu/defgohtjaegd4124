const { default: axios } = require('axios');
const jwt = require('jsonwebtoken');
const express = require('express');
const fs = require('fs');
const path = require('path');
const Router = express.Router()
const dataTrade = JSON.parse(fs.readFileSync(path.join(__dirname, './dataTrade.json')))

function isIDExists(id, array) {
    return array.some(item => item.id === id);
}

// Hàm tạo một ID mới không trùng với các ID hiện có trong mảng
function generateUniqueID(array) {
    let newID;
    do {
        // Tạo một ID ngẫu nhiên (ví dụ: sử dụng timestamp)
        newID = Date.now();
    } while (isIDExists(newID, array));
    return newID;
}
Router.get('/api-trade/:nameTrade', async(req, res, next) => {
    const nameTrade = req.params.nameTrade
    try {
        const data = await axios.get(`https://api.binance.com/api/v3/klines?symbol=${nameTrade}USDT&interval=1s&limit=1`)
        const findTrade = dataTrade.find(item => {
            return item.name === nameTrade
        })
        const formatData = {
            coinTrade: parseFloat(data.data[0][1]),
            typeTrade: findTrade
        }
        res.send(formatData)
    } catch (error) {
        if (error) {
            res.send('error')
        }
    }
})
Router.get('/get-popular-transactions', (req, res, next) => {
    const dataPopular = JSON.parse(fs.readFileSync(path.join(__dirname, './popularTrans.json')))
    res.send(dataPopular)
})

Router.get('/get-email', (req, res, next) => {
    const dataEmail = JSON.parse(fs.readFileSync(path.join(__dirname, './dataUser.json')))
    const mapEmail = dataEmail.map(item => item.email)
    res.send(mapEmail)
})
Router.post('/register', (req, res) => {
    const dataEmail = JSON.parse(fs.readFileSync(path.join(__dirname, './dataUser.json')))
    const { name, email, password } = req.body;

    const dataUser = {
        name,
        email,
        password,
        coin: "",
        token: "",
        banking: [],
        vip: "",
        securityCode: ""
    };

    const token = jwt.sign(dataUser, JSON.stringify(dataUser), { expiresIn: '30d' });

    dataUser.token = token;
    dataEmail.push(dataUser)
    fs.writeFileSync(path.join(__dirname, './dataUser.json'), JSON.stringify(dataEmail))
    res.json({ token });
});
Router.post('/login', (req, res) => {
    const dataEmail = JSON.parse(fs.readFileSync(path.join(__dirname, './dataUser.json')))
    const { email, password } = req.body;
    const findUser = dataEmail.find((user) => {
        if (user.email === email) {
            if (user.password === password) {
                return user
            } else {

            }
        }
    })
    if (findUser) {
        const obj = {
            email,
            password
        }
        const token = jwt.sign(obj, JSON.stringify(obj), { expiresIn: '30d' });
        const mapUser = dataEmail.map((item) => {
            if (item.email === email) {
                item.token = token
            }
            return item
        })
        const newObj = {
            email: findUser.email,
            username: findUser.name,
            token: token
        }
        fs.writeFileSync(path.join(__dirname, './dataUser.json'), JSON.stringify(mapUser))
        res.json(newObj);
    } else {
        res.json({ token: 'undefined' });
    }

});



Router.get('/info-user/:email', (req, res, next) => {
    const dataEmail = JSON.parse(fs.readFileSync(path.join(__dirname, './dataUser.json')))
    const email = req.params.email
    const token = req.headers.authorization
    const findData = dataEmail.find(item => {
        if (item.email === email) {
            if (item.token === token) {
                return item
            }
        }
    })
    res.send(findData)
})
Router.post('/add-to-card', (req, res, next) => {
    const dataClient = req.body
    const dataUser = JSON.parse(fs.readFileSync(path.join(__dirname, './dataUser.json')))
    const mapData = dataUser.map(item => {
        if (item.email == dataClient.email) {
            item.banking.push(dataClient.data)
        }
        return item
    })
    fs.writeFileSync(path.join(__dirname, './dataUser.json'), JSON.stringify(mapData))
    res.send({ status: "success" })
})
Router.get('/active-card/:email', (req, res) => {
    const dataUser = JSON.parse(fs.readFileSync(path.join(__dirname, './dataUser.json')))
    const email = req.params.email
    const findData = dataUser.find(item => item.email === email)
    const dataBanking = findData.banking
    res.send({ status: "success", bankData: dataBanking })
})
Router.get('/coin-account/:email', (req, res) => {
    const dataUser = JSON.parse(fs.readFileSync(path.join(__dirname, './dataUser.json')))
    const email = req.params.email
    const findData = dataUser.find(item => item.email === email)
    if (findData) {
        res.send({ status: "success", coin: findData.coin })
    } else {
        res.send({ status: "failure" })
    }

})
Router.get('/get-cart-user/:email', (req, res) => {
    const email = req.params.email
    const dataCart = JSON.parse(fs.readFileSync(path.join(__dirname, './dataCart.json')))
    const filteData = dataCart.filter(item => {
        if (item.email === email) {
            return item
        }
    })
    res.send({
        status: "success",
        data: filteData
    })
})

// Cart post 


function randomizePeople(data) {
    // Tính số lượng "win" và "lose" hiện tại
    const currentWins = data.filter(item => item.people === "win").length;
    const currentLosses = data.filter(item => item.people === "lose").length;

    // Tính số lượng cần thêm "win" và "lose" để đạt được tỷ lệ 50/50
    let neededWins = Math.floor(data.length / 2) - currentWins;
    let neededLosses = Math.floor(data.length / 2) - currentLosses;
    // Tạo mảng mới với sự xuất hiện ngẫu nhiên của "win" và "lose"
    const randomizedData = data.map(item => {
        if (item.people === "") {
            if (neededWins > 0 && neededLosses > 0) {
                const randomResult = Math.random() < 0.5 ? "win" : "lose";
                neededWins -= randomResult === "win" ? 1 : 0;
                neededLosses -= randomResult === "lose" ? 1 : 0;
                return {...item, people: randomResult };
            } else if (neededWins > 0) {
                neededWins--;
                return {...item, people: "win" };
            } else if (neededLosses > 0) {
                neededLosses--;
                return {...item, people: "lose" };
            }
        }
        return item;
    });

    return randomizedData;
}





Router.post('/post-to-cart', (req, res) => {
    const { type, coin, date, email, nameCoin, token, minute, numInCre, people, priceOrder, coinInitial } = req.body
    const profitNum = (Number(numInCre) / 100) * Number(coin)
    const dataCart = JSON.parse(fs.readFileSync(path.join(__dirname, './dataCart.json')))
    const dataUser = JSON.parse(fs.readFileSync(path.join(__dirname, './dataUser.json')))
    const id = generateUniqueID(dataCart)
    const obj = {
        type,
        coin: Number(coin).toFixed(2),
        date,
        email,
        nameCoin,
        minute,
        numInCre,
        people,
        profit: profitNum.toFixed(2),
        priceOrder,
        id,
        coinInitial,
        notification: false
    }
    const findUser = dataUser.find(item => {
        if (item.token == token) {
            if (item.email == email) {
                return item
            }
        }
    })
    if (findUser) {
        dataCart.push(obj);
        const mapDataUser = dataUser.map((item) => {
            if (item.email == email) {
                item.coin = Number(item.coin) - Number(coin)
            }
            return item
        })
        const findUser = mapDataUser.find(item => item.email === email)
        fs.writeFileSync(path.join(__dirname, './dataUser.json'), JSON.stringify(mapDataUser))
        fs.writeFileSync(path.join(__dirname, './dataCart.json'), JSON.stringify(dataCart))
        const filterCartData = dataCart.filter((item) => { return item.email == email })
        setTimeout(() => {
            const dataCart = JSON.parse(fs.readFileSync(path.join(__dirname, './dataCart.json')))
            const randomizedData = randomizePeople(dataCart);
            fs.writeFileSync(path.join(__dirname, './dataCart.json'), JSON.stringify(randomizedData))
        }, 60000)
        res.send({
            status: "success",
            coin: Number(findUser.coin),
            data: filterCartData
        })
    } else {
        res.send({
            status: "failure",
        })
    }

})


Router.post('/post-to-cart-no-random', (req, res) => {
    const { type, coin, date, email, nameCoin, token, minute, numInCre, people, priceOrder, coinInitial } = req.body
    const profitNum = (Number(numInCre) / 100) * Number(coin)
    const dataCart = JSON.parse(fs.readFileSync(path.join(__dirname, './dataCart.json')))
    const dataUser = JSON.parse(fs.readFileSync(path.join(__dirname, './dataUser.json')))
    const id = generateUniqueID(dataCart)
    const obj = {
        type,
        coin: Number(coin).toFixed(2),
        date,
        email,
        nameCoin,
        minute,
        numInCre,
        people,
        profit: profitNum.toFixed(2),
        priceOrder,
        id,
        coinInitial,
        notification: false
    }
    const findUser = dataUser.find(item => {
        if (item.token == token) {
            if (item.email == email) {
                return item
            }
        }
    })
    if (findUser) {
        dataCart.push(obj);
        const mapDataUser = dataUser.map((item) => {
            if (item.email == email) {
                item.coin = Number(item.coin) - Number(coin)
            }
            return item
        })
        const findUser = mapDataUser.find(item => item.email === email)
        fs.writeFileSync(path.join(__dirname, './dataUser.json'), JSON.stringify(mapDataUser))
        fs.writeFileSync(path.join(__dirname, './dataCart.json'), JSON.stringify(dataCart))
        const filterCartData = dataCart.filter((item) => { return item.email == email })
        res.send({
            status: "success",
            coin: Number(findUser.coin),
            data: filterCartData
        })
    } else {
        res.send({
            status: "failure",
        })
    }

})





Router.post('/login-admin', (req, res, next) => {
    const { name, password, date } = req.body
    const urlAdmin = path.join(__dirname, './admin.json')
    const dataAdmin = JSON.parse(fs.readFileSync(urlAdmin))
    const findDataAdmin = dataAdmin.find(item => {
        if (item.email === name) {
            if (item.password === password) {
                return item
            }
        }
    })
    if (findDataAdmin) {
        const objScreat = {
            email: name,
            password: password,
            date
        }
        const signToken = jwt.sign(objScreat, JSON.stringify(objScreat))
        const addToken = dataAdmin.map(item => {
            if (item.email === name) {
                item.token = signToken
            }
            return item
        })
        fs.writeFileSync(urlAdmin, JSON.stringify(addToken))
        res.send({ status: "success", signToken: signToken })
    } else {
        res.send({ status: "failure" })
    }

})
Router.get('/is-admin', (req, res) => {
    const auth = req.headers.authorization.split(" ");
    const token = auth[1]
    if (token) {
        const urlAdmin = path.join(__dirname, './admin.json')
        const dataAdmin = JSON.parse(fs.readFileSync(urlAdmin))
        const findAdmin = dataAdmin.find(item => item.token === token)
        if (findAdmin) {
            res.send({ status: "success", email: findAdmin.email })
        } else {
            res.send({ status: "failure" })
        }

    } else {
        res.send({ status: "failure" })
    }
})

Router.get('/is-login/:email', (req, res) => {
    const email = req.params.email
    const auth = req.headers.authorization
    const dataUser = JSON.parse(fs.readFileSync(path.join(__dirname, './dataUser.json')))
    const findUser = dataUser.find(item => {
        if (item.email === email) {
            if (item.token === auth) {
                return item
            }
        }
    })
    if (findUser) {
        res.send({ status: 1 })
    } else {
        res.send({ status: 0 })
    }
})

Router.post('/add-security', (req, res) => {
    const { token, email, security } = req.body
    const urlUser = path.join(__dirname, './dataUser.json')
    const dataUser = JSON.parse(fs.readFileSync(urlUser))
    const findUser = dataUser.find((item, index) => {
        if (item.email === email) {
            if (item.token === token) {
                return item
            }
        }
    })
    if (findUser) {
        const mapDataUser = dataUser.map(item => {
            if (item.email === email) {
                item.securityCode = security
            }
            return item
        })
        fs.writeFileSync(urlUser, JSON.stringify(mapDataUser))
        res.send({ status: 1 })
    } else {
        res.send({ status: 0 })
    }
})


Router.post('/with-draw', (req, res) => {
    const { email, token, amount, securityCode } = req.body
    const urlUser = path.join(__dirname, './dataUser.json')
    const urlBill = path.join(__dirname, './billUser.json')
    const dataBill = JSON.parse(fs.readFileSync(urlBill))
    const dataUser = JSON.parse(fs.readFileSync(urlUser))
    const findUser = dataUser.find((item, index) => {
        if (item.email === email) {
            if (item.token === token) {
                return item
            }
        }
    })
    const id = generateUniqueID(dataBill)
    if (findUser) {
        if (securityCode.length > 0) {
            if (findUser.securityCode == securityCode) {
                const mapDataUser = dataUser.map(item => {
                    if (item.email === email) {
                        item.coin = Number(item.coin) - Number(amount)
                    }
                    return item
                })

                const obj = {
                    email: email,
                    coin: amount,
                    status: 0,
                    banking: findUser.banking[0].BankAcc,
                    namebanking: findUser.banking[0].bankIns,
                    date: Date.now(),
                    type: 2,
                    id
                }

                dataBill.push(obj)
                fs.writeFileSync(urlBill, JSON.stringify(dataBill))
                fs.writeFileSync(urlUser, JSON.stringify(mapDataUser))
                const resCoin = Number(findUser.coin) - Number(amount)
                res.send({ status: 'success', resCoin: resCoin })
            } else {
                res.send({ status: 'Security Code not found' })
            }


        } else {
            res.send({ status: 'Security Code > 0' })
        }

    } else {
        res.send({ status: 'No Find User' })
    }
})
Router.get('/bill-data/:email', (req, res) => {
    const email = req.params.email
    const token = req.headers.authorization
    const urlUser = path.join(__dirname, './dataUser.json')
    const urlBill = path.join(__dirname, './billUser.json')
    const dataBill = JSON.parse(fs.readFileSync(urlBill))
    const dataUser = JSON.parse(fs.readFileSync(urlUser))
    const findUser = dataUser.find((item, index) => {
        if (item.email === email) {
            if (item.token === token) {
                return item
            }
        }
    })
    if (findUser) {
        const filterBill = dataBill.filter((item, index) => {
            if (item.email == email) {
                return item
            }
        })
        res.send({ data: filterBill, status: 1 })
    } else {
        res.send({ data: [], status: 0 })
    }
})
Router.get('/admin-get-users', (req, res) => {
    const token = req.headers.authorization
    const urlAdmin = path.join(__dirname, './admin.json')
    const dataAdmin = JSON.parse(fs.readFileSync(urlAdmin))
    const findAdmin = dataAdmin.find((item) => {

        if (token == item.token) {
            return item
        }

    })
    if (findAdmin) {
        const urlUser = path.join(__dirname, './dataUser.json')
        const dataUser = JSON.parse(fs.readFileSync(urlUser))
        const mapData = dataUser.map(item => {
            const obj = {
                email: item.email,
                banking: item.banking,
                coin: item.coin
            }
            return obj
        })
        res.send({ status: 1, arr: mapData })
    } else {
        res.send({ status: 0 })
    }

})
Router.get('/admin-get-users/:email', (req, res) => {
    const token = req.headers.authorization
    const email = req.params.email
    const urlAdmin = path.join(__dirname, './admin.json')
    const dataAdmin = JSON.parse(fs.readFileSync(urlAdmin))
    const findAdmin = dataAdmin.find((item) => {

        if (token == item.token) {
            return item
        }

    })
    if (findAdmin) {
        const urlUser = path.join(__dirname, './dataUser.json')
        const dataUser = JSON.parse(fs.readFileSync(urlUser))
        const findUser = dataUser.find(item => item.email == email)
        res.send({ status: 1, dataUser: findUser })
    } else {
        res.send({ status: 0 })
    }

})
Router.post('/admin-deposit', (req, res) => {
    const { email, coin, banking, namebanking } = req.body
    const urlUser = path.join(__dirname, './dataUser.json')
    const dataUser = JSON.parse(fs.readFileSync(urlUser))
    const findUser = dataUser.find((item) => {
        if (email == item.email) {
            return item
        }
    })
    if (findUser) {
        try {
            const mapData = dataUser.map((item) => {
                if (item.email == email) {
                    item.coin = Number(coin) + Number(item.coin)
                }
                return item
            })
            const urlBill = path.join(__dirname, './billUser.json')

            const dataBill = JSON.parse(fs.readFileSync(urlBill))
            const id = generateUniqueID(dataBill)
            const obj = {
                email: email,
                coin: Number(coin),
                status: 1,
                banking: banking,
                namebanking: namebanking,
                date: Date.now(),
                type: 1,
                id
            }
            dataBill.push(obj)

            fs.writeFileSync(urlUser, JSON.stringify(mapData))
            fs.writeFileSync(urlBill, JSON.stringify(dataBill))
            res.send({ status: 1 })
        } catch (error) {
            res.send({ status: 0 })
        }
    } else {
        res.send({ status: 0 })
    }
})
Router.put('/admin-update-cart', (req, res) => {
    const { data, people } = req.body
    const profit = data.profit
    const email = data.email
    const urlCart = path.join(__dirname, './dataCart.json')
    const dataCart = JSON.parse(fs.readFileSync(urlCart))
    const urlUser = path.join(__dirname, './dataUser.json')
    const dataUser = JSON.parse(fs.readFileSync(urlUser))

    if (people.toLowerCase() == 'win') {
        const mapDataUser = dataUser.map(item => {
            if (item.email == email) {
                item.coin = Number(item.coin) + (Number(profit) + Number(data.coin))
            }
            return item
        })
        console.log(mapDataUser)
        fs.writeFileSync(urlUser, JSON.stringify(mapDataUser))
    }

    const mapDatacart = dataCart.map(item => {
        if (item.email == email) {
            if (item.id == data.id) {
                item.people = people
            }
        }
        return item
    })

    fs.writeFileSync(urlCart, JSON.stringify(mapDatacart))
    res.send({
        status: 1
    })
})


Router.put('/admin-withdraw', (req, res) => {
    const { id, token } = req.body
    const urlBill = path.join(__dirname, './billUser.json')
    const dataBill = JSON.parse(fs.readFileSync(urlBill))
    const findDataBill = dataBill.find(data => {
        return data.id == id
    })
    const urlAdmin = path.join(__dirname, './admin.json')
    const dataAdmin = JSON.parse(fs.readFileSync(urlAdmin))
    const findAdmin = dataAdmin.find(data => data.token == token)
    if (findAdmin) {
        if (findDataBill) {
            const mapDataBill = dataBill.map(item => {
                if (item.id == id) {
                    item.status = Number(1)
                }
                return item
            })
            fs.writeFileSync(urlBill, JSON.stringify(mapDataBill))
            res.send({
                status: 1
            })
        }
    }

})
Router.put('/re-password', (req, res) => {
    const { repass, security, email, token } = req.body
    const urlUser = path.join(__dirname, './dataUser.json')
    const dataUser = JSON.parse(fs.readFileSync(urlUser))
    const findUser = dataUser.find(item => {
        if (item.email == email) {
            if (item.token == token) {
                if (item.password == security) {
                    return item
                }

            }
        }
    })
    if (findUser) {
        const mapUser = dataUser.map(item => {
            if (item.email == email) {
                item.password = repass
            }
            return item
        })
        fs.writeFileSync(urlUser, JSON.stringify(mapUser))
        res.send({ status: 1 })
    } else {
        res.send({ status: 2 })
    }

})
Router.get('/get-cart/:email', (req, res) => {
    const email = req.params.email
    const urlCart = path.join(__dirname, './dataCart.json')
    const data = JSON.parse(fs.readFileSync(urlCart))
    const filterData = data.filter(item => item.email === email)

    res.send(filterData)
})

Router.get('/get-chat-user/:email', (req, res) => {
    const email = req.params.email
    const urlDataChat = path.join(__dirname, 'dataChat.json')
    const dataChat = JSON.parse(fs.readFileSync(urlDataChat))
    const filterData = dataChat.filter(item => {
        if (item.email == email) {
            if (item.notification == false) {
                if (item.active == 'admin') {
                    return item
                }

            }
        }
    })
    if (filterData.length > 0) {
        const newArray = dataChat.map(item => {
            if (item.active == 'admin') {
                if (item.email == email) {
                    if (item.notification == false) {
                        item.notification = true
                    }
                }
            }
            return item
        })
        fs.writeFileSync(urlDataChat, JSON.stringify(newArray))
        res.send({ result: filterData, status: 1 })
    } else {
        res.send({ result: [], status: 0 })
    }

})
Router.get('/get-chat-admin', (req, res) => {
    const urlDataChat = path.join(__dirname, 'dataChat.json')
    const dataChat = JSON.parse(fs.readFileSync(urlDataChat))
    const filterData = dataChat.filter(item => {
        if (item.notification == false) {
            if (item.active == 'user') {
                return item
            }

        }

    })
    if (filterData.length > 0) {
        const newArray = dataChat.map(item => {
            if (item.active == 'user') {
                if (item.notification == false) {
                    item.notification = true
                }
            }
            return item
        })
        fs.writeFileSync(urlDataChat, JSON.stringify(newArray))
        res.send({ result: filterData, status: 1 })
    } else {
        res.send({ result: [], status: 0 })
    }
})

Router.get('/get-cart-user', (req, res) => {
    const urlDataCart = path.join(__dirname, 'dataCart.json')
    const dataCart = JSON.parse(fs.readFileSync(urlDataCart))
    const filterData = dataCart.filter(item => {
        if (item.notification == false) {
            return item
        }

    })
    if (filterData.length > 0) {
        const newArray = dataCart.map(item => {

            if (item.notification == false) {
                item.notification = true
            }

            return item
        })
        fs.writeFileSync(urlDataCart, JSON.stringify(newArray))
        res.send({ resultz: filterData, statusz: 1 })
    } else {
        res.send({ resultz: [], statusz: 0 })
    }
})

Router.delete('/delete-cart/:email', (req, res) => {
    const email = req.params.email
    const urlDataCart = path.join(__dirname, 'dataCart.json')
    const dataCart = JSON.parse(fs.readFileSync(urlDataCart))
    const findData = dataCart.filter(item => {
        if (item.email == email) {
            return item
        }
    })
    const newArray = dataCart.filter(item => {
        if (item.email !== email) {
            return item
        }
    })
    fs.writeFileSync(urlDataCart, JSON.stringify(newArray))
    if (findData.length > 0) {
        res.send('Xóa thành công')
    } else {
        res.send('Dữ liệu người dùng đã được xóa trước đó')
    }

})



Router.delete('/delete-user/:email', async(req, res) => {
    try {
        const email = req.params.email;
        const urlDataCart = path.join(__dirname, 'dataCart.json');
        const urlDataChat = path.join(__dirname, 'dataChat.json');
        const urlDataBill = path.join(__dirname, 'billUser.json');
        const urldataUser = path.join(__dirname, 'dataUser.json');

        const [dataCart, dataChat, dataBill, dataUser] = await Promise.all([
            readFile(urlDataCart),
            readFile(urlDataChat),
            readFile(urlDataBill),
            readFile(urldataUser)
        ]);

        const userExists = dataUser.some(item => item.email === email);
        if (!userExists) {
            return res.status(404).send('Người dùng không tồn tại');
        }

        const newArray = dataCart.filter(item => item.email !== email);
        const newArray2 = dataChat.filter(item => item.email !== email);
        const newArray3 = dataBill.filter(item => item.email !== email);
        const newArray4 = dataUser.filter(item => item.email !== email);

        await Promise.all([
            writeFile(urlDataCart, JSON.stringify(newArray)),
            writeFile(urlDataChat, JSON.stringify(newArray2)),
            writeFile(urlDataBill, JSON.stringify(newArray3)),
            writeFile(urldataUser, JSON.stringify(newArray4))
        ]);

        res.send('Xóa thành công');
    } catch (error) {
        console.error(error);
        res.status(500).send('Lỗi server');
    }
});

async function readFile(filePath) {
    const fileContent = await fs.promises.readFile(filePath, 'utf-8');
    return JSON.parse(fileContent);
}

async function writeFile(filePath, data) {
    await fs.promises.writeFile(filePath, data, 'utf-8');
}




Router.put('/random-data-card', (req, res) => {
    const { data } = req.body

    const urlDataRandom = path.join(__dirname, 'activeRandom.json')
    const newObj = { active: data }
    fs.writeFileSync(urlDataRandom, JSON.stringify(newObj))
    res.send({ result: data })
})
Router.get('/random-data-card', (req, res) => {
    const urlDataRandom = path.join(__dirname, 'activeRandom.json')
    const dataRandom = JSON.parse(fs.readFileSync(urlDataRandom))
    res.send({ result: dataRandom.active })
})
module.exports = Router