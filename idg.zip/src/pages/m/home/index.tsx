import DropDownSelect from "@/components/DropDownSelect/DropDownSelect"
import RenderPopular from "@/components/renderPopular"
import { API_KEY } from "@/config/api"
import UseTranslate from "@/hook/translate"
import { userLogin } from "@/hook/useLogin"
import Link from "next/link"
import { useRouter } from "next/router"
import React, { useEffect, useState } from "react"
const Home: React.FC = () => {
    const [popularTransaction, setPopularTransaction] = useState<any>([])
    const [langs, setLangs] = useState<any>('')
    useEffect(() => {
        fetch(`${API_KEY}/get-popular-transactions`).then((response) => response.json()).then((data: any) => {
            setPopularTransaction(data)
        })
        const lang = localStorage.getItem('lang')
        if (lang) {
            setLangs(lang)
        } else {
            setLangs('en')
        }
    }, [])





    const optionHome = [
        {
            name: "Study",
            path: "/m/learn",
            icon: () => <svg xmlns="http://www.w3.org/2000/svg" className="w-10 h-10" viewBox="0 0 24 24"><path className="fill-current stroke-neutral-dark" d="M21,18H6c-0.6,0-1,0.4-1,1s0.4,1,1,1h15v2H6c-1.7,0-3-1.3-3-3V4c0-1.1,0.9-2,2-2h16V18z M5,16C5.2,16,5.3,16,5.5,16H19V4H5 V16z"></path><rect className="fill-primary-main" x="8" y="7" width="8" height="2"></rect></svg>
        },
        {
            name: "Help Center",
            path: "/m/help",
            icon: () => <svg xmlns="http://www.w3.org/2000/svg" className="w-10 h-10" viewBox="0 0 24 24"><path className="fill-current stroke-neutral-dark" d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10 10-4.5 10-10S17.5 2 12 2zm0 18c-4.4 0-8-3.6-8-8s3.6-8 8-8 8 3.6 8 8-3.6 8-8 8z"></path><path className="fill-primary-main" d="M11 16h2v2h-2zM12 6c-2.2 0-4 1.8-4 4h2c0-1.1.9-2 2-2s2 .9 2 2c0 2-3 1.8-3 5h2c0-2.2 3-2.5 3-5 0-2.2-1.8-4-4-4z"></path></svg>
        },
        {
            name: "VIP",
            path: "/m/vip",
            icon: () => <svg xmlns="http://www.w3.org/2000/svg" className="w-10 h-10" viewBox="0 0 24 24"><path className="fill-current stroke-neutral-dark" d="M17.4 3.8c.7 0 1.3.3 1.6.9l.1.1 3.3 5.8c.4.7.3 1.6-.2 2.3l-.1.1-9.3 9.3c-.5.5-1.2.5-1.7.1l-.1-.1L1.7 13c-.6-.6-.8-1.5-.4-2.3l.1-.1 3.3-5.8c.3-.6.9-.9 1.6-1h11.1zm0 2H6.6l-3.3 5.8 8.8 8.8 8.8-8.8-3.5-5.8z"></path><path className="fill-primary-main" d="M7.3 10.1c.4-.4.9-.4 1.3-.1l.1.1 3.3 3.3 3.3-3.3c.4-.4 1-.4 1.4 0 .4.4.4.9.1 1.3l-.1.1-3.8 3.8c-.5.5-1.2.5-1.7.1l-.1-.1-3.8-3.8c-.4-.3-.4-1 0-1.4z"></path></svg>
        },
        {
            name: "Leaderboard",
            path: "/m/leaderboard",
            icon: () => <svg viewBox="0 0 24 24" className="w-10 h-10" xmlns="http://www.w3.org/2000/svg"><path className="stroke-current stroke-1 fill-none" d="M15,21H9v-8.4C9,12.3,9.3,12,9.6,12h4.8c0.3,0,0.6,0.3,0.6,0.6V21z M20.4,21H15v-2.9c0-0.3,0.3-0.6,0.6-0.6h4.8 c0.3,0,0.6,0.3,0.6,0.6v2.3C21,20.7,20.7,21,20.4,21z M9,21v-4.9c0-0.3-0.3-0.6-0.6-0.6H3.6c-0.3,0-0.6,0.3-0.6,0.6v4.3 C3,20.7,3.3,21,3.6,21H9z"></path><path className="stroke-primary-main stroke-1 fill-none" d="M10.8,5.1l0.9-1.9c0.1-0.2,0.5-0.2,0.6,0l0.9,1.9l2,0.3c0.3,0,0.4,0.4,0.2,0.6l-1.5,1.5l0.3,2.1 c0,0.3-0.2,0.5-0.5,0.4L12,9l-1.8,1c-0.2,0.1-0.5-0.1-0.5-0.4l0.3-2.1L8.6,6C8.4,5.8,8.5,5.5,8.8,5.4L10.8,5.1z"></path></svg>
        },
        {
            name: "Invite friends",
            path: "/m/comming",
            icon: () => <svg xmlns="http://www.w3.org/2000/svg" className="w-10 h-10" fill="none" viewBox="0 0 24 24"><g className="stroke-current"><path d="M14.811 16.405 9.3 13.223M14.811 7.591 9.3 10.773"></path><circle cx="6.15" cy="11.994" r="2.4" className="stroke-primary-main"></circle><circle r="2.4" transform="matrix(1 0 0 -1 17.85 17.995)"></circle><circle cx="17.85" cy="6" r="2.4"></circle></g></svg>
        },
        {
            name: "Savings",
                   path: "/m/comming",
            icon: () => <svg className="w-10 h-10" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9" className="stroke-current fill-none"></circle><path d="M15.822 9v1.828h-2.811v1.194c2.277.103 3.989.544 3.989 1.073 0 .529-1.713.97-3.99 1.072V18h-2.003v-3.832C8.721 14.068 7 13.625 7 13.095c0-.53 1.721-.973 4.007-1.073v-1.194H8.195V9h7.627Zm-2.811 4.71c1.797-.082 3.128-.374 3.128-.723s-1.331-.642-3.13-.723v1.104a19.322 19.322 0 0 1-2.004.001v-1.108c-1.806.08-3.146.374-3.146.724s1.34.644 3.146.724l.12.005c.12.005.242.008.365.011h.011l.104.002h.03l.087.002h.557l.088-.002h.031l.112-.002h.005l.246-.007h.012l.109-.004h.012l.117-.005Z" className="fill-primary-main"></path><path className="stroke-primary-main" d="M15 6h6M18 3v6"></path></svg>
        },
        {
            name: "Trading robot",
                   path: "/m/comming",
            icon: () => <svg className="w-10 h-10" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path className="stroke-current" d="M12 3v4"></path><rect x="3" y="7" width="18" height="14" rx="2" className="stroke-current fill-none"></rect><path d="M9 17h6" className="stroke-current"></path><circle cx="9" cy="13" r="1" className="fill-primary-main"></circle><circle cx="15" cy="13" r="1" className="fill-primary-main"></circle><circle cx="12" cy="2.5" r="1.5" className="fill-primary-main"></circle></svg>
        },
        {
            name: "Mining",
                   path: "/m/comming",
            icon: () => <svg xmlns="http://www.w3.org/2000/svg" className="w-10 h-10" fill="none" viewBox="0 0 24 24"><rect x="9" y="9" width="6" height="6" className="stroke-primary-main"></rect><rect width="16" height="16" x="4" y="4" rx="2" ry="2" className="stroke-current"></rect><path d="M9 1v3M15 1v3M9 20v3M15 20v3M20 9h3M20 14h3M1 9h3M1 14h3" className="stroke-current"></path></svg>
        },
    ]
    const [stopTestUser, setStopTestUser] = useState<any>(false);
    const router = useRouter()
    useEffect(() => {
        async function runTestUser() {
            await userLogin(router)
        }
        if (!stopTestUser) {
            runTestUser()
            setStopTestUser(true)
            console.log('stop test user');
        }
    }, [stopTestUser])
    return (
        <div className="m_home">
            <div className="m_home_banner">
                <img src="https://www.idg88fx.com/upload/ui/7bab0b30-4299-487f-80d2-8c681dd3dbe8_400_400.png" alt="" />
            </div>

            <div className="m_home_service">
                <Link href={'/m/deposit'} className="m_home_service_deposit">
                    <div>
                        <svg className="w-10 h-10" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">

                            <path d="M6 18.5L4.22278 10.5025C4.10071 9.95321 4.45574 9.41138 5.0081 9.30398L21.069 6.18102C21.591 6.07953 22.1011 6.40425 22.23 6.9201L23.5 12" className="stroke-current"></path> <rect x="6" y="11.9999" width="20" height="14" rx="1" className="stroke-current">
                            </rect><path d="M18.9977 18.5243L18.3463 17.7656L17.5187 18.4763L18.2985 19.2391L18.9977 18.5243ZM28.385 19.5243C28.9373 19.5243 29.385 19.0766 29.385 18.5243C29.385 17.972 28.9373 17.5243 28.385 17.5243L28.385 19.5243ZM21.0489 21.9297C21.4437 22.3159 22.0768 22.309 22.463 21.9142C22.8492 21.5194 22.8423 20.8863 22.4475 20.5001L21.0489 21.9297ZM22.3996 16.9211C22.8186 16.5613 22.8666 15.9299 22.5068 15.5109C22.147 15.0919 21.5157 15.0439 21.0967 15.4038L22.3996 16.9211ZM18.9977 19.5243L28.385 19.5243L28.385 17.5243L18.9977 17.5243L18.9977 19.5243ZM18.2985 19.2391L21.0489 21.9297L22.4475 20.5001L19.697 17.8094L18.2985 19.2391ZM19.6492 19.2829L22.3996 16.9211L21.0967 15.4038L18.3463 17.7656L19.6492 19.2829Z" className="fill-primary-main"></path></svg>
                        <UseTranslate
                            data={{
                                Tag: 'span',
                                className: '',
                                lang: langs
                            }} >
                            Deposit
                        </UseTranslate>

                    </div>
                    <div>
                        <svg focusable="false" aria-hidden="true" viewBox="0 0 24 24" data-testid="ArrowForwardIcon"><path d="m12 4-1.41 1.41L16.17 11H4v2h12.17l-5.58 5.59L12 20l8-8z"></path></svg>
                    </div>
                </Link>
                <Link href={'/m/chat'} className="m_home_service_main">
                    <div>
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" className="w-10 h-10">
                            <path d="M17.37,6.73c.9,0,1.63,.73,1.63,1.63v3.26c0,.9-.73,1.63-1.63,1.63h-.87c-.41,3.26-3.19,5.71-6.48,5.71v-1.63c2.7,0,4.89-2.19,4.89-4.89V7.55c0-3.77-4.08-6.12-7.34-4.24-1.51,.87-2.45,2.49-2.45,4.24v5.71H2.69c-.9,0-1.63-.73-1.63-1.63v-3.26c0-.9,.73-1.63,1.63-1.63h.87C4.18,1.75,9.97-.69,13.97,2.35c1.4,1.06,2.31,2.64,2.53,4.38h.87Z"></path><path d="M6.57,13.08l.86-1.38c.78,.49,1.68,.74,2.59,.74,.92,0,1.82-.26,2.59-.74l.86,1.38c-1.04,.65-2.24,.99-3.46,.99-1.22,0-2.42-.34-3.46-.99Z">
                            </path></svg>
                        <UseTranslate
                            data={{
                                Tag: 'span',
                                className: '',
                                lang: langs
                            }} >
                            Service
                        </UseTranslate>
                    </div>
                    <div>
                        <svg focusable="false" aria-hidden="true" viewBox="0 0 24 24" data-testid="ArrowForwardIcon"><path d="m12 4-1.41 1.41L16.17 11H4v2h12.17l-5.58 5.59L12 20l8-8z"></path></svg>
                    </div>
                </Link>
            </div>
            <UseTranslate
                data={{
                    Tag: 'h3',
                    className: '',
                    lang: langs
                }} >
                Popular transaction pair
            </UseTranslate>
            <div className="m_home_popular">
                {popularTransaction.map((item: any, index: any) => {
                    return (
                        <RenderPopular key={index} namePopular={item.name} />

                    )
                })}
            </div>
            <div className="m_home_option">
                {optionHome.map((item: any, index: any) => {
                    return (
                        <div className="m_home_option_item" key={index}>
                            <Link href={item.path}>
                                {item.icon()}
                                <UseTranslate
                                    data={{
                                        Tag: 'span',
                                        className: '',
                                        lang: langs
                                    }} >
                                    {item.name}
                                </UseTranslate>
                            </Link>
                        </div>
                    )
                })}
            </div>
        </div>
    )
}
export default Home