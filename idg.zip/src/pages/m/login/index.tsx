import { API_KEY } from "@/config/api"
import axios from "axios"
import Link from "next/link"
import { useRouter } from "next/router"
import React, { useEffect, useRef, useState } from "react"
const Login: React.FC = () => {
    const router = useRouter()
    const [render, setRender] = useState<any>('')
    const [langs, setLangs] = useState<any>('')
    useEffect(() => {
        const lang = localStorage.getItem('lang')
        if (lang) {
            setLangs(lang)
        } else {
            setLangs('en')
        }
        const infoUser = localStorage.getItem('infoUser')
        if (infoUser) {
            const token = localStorage.getItem('token')
            if (token) {
                axios.get(`${API_KEY}/is-login/${JSON.parse(infoUser).email}`, {
                    headers: { Authorization: `${token}` }
                }).then((res: any) => {
                    if (res.data.status === 1) {
                        setRender(res.data.status)
                        router.push('/m/home')
                    } else if (res.data.status === 0) {
                        setRender(res.data.status)
                    }
                })
            } else {
                setRender(0)
            }
        } else {
            setRender(0)
        }
    }, [])
    const [dataUser, setDataUser] = useState<any>({
        name: "",
        password: ""
    })
    const userRef = useRef<any>(null)
    const passwordRef = useRef<any>(null)
    const handleLogin = (e: any) => {
        e.preventDefault();
        if (dataUser.name.length == 0 || dataUser.password.length == 0) {

        } else {
            axios.post(`${API_KEY}/login`, {
                email: dataUser.name,
                password: dataUser.password
            }).then(item => {
                if (item.data.token == 'undefined') {
                    alert('Tài khoản hoặc mật khẩu không đúng')
                } else {
                    localStorage.setItem('token', item.data.token)
                    // document.cookie = `token = ${item.data.token}`
                    localStorage.setItem('infoUser', JSON.stringify({ email: item.data.email, name: item.data.username }))
                    e.target.closest('form').submit()
                }
            })

        }


    };
    return (
        <>
            {render === 1 ? <></> : render === 0 ?
                <div className="m_login">
                    <div className="m_login_header">
                        <svg style={{ cursor: "pointer" }} onClick={() => {
                            router.push('/m/home')
                        }} className="MuiSvgIcon-root MuiSvgIcon-fontSizeMedium css-vubbuv" focusable="false" aria-hidden="true" viewBox="0 0 24 24" data-testid="ArrowBackIcon"><path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z"></path></svg>
                        <Link href={'/m/register'} >{langs=='vi'?'Đăng ký':'Register'}</Link>
                    </div>
                    <div className="m_login_container">
                        <h1>{langs=='vi'?'Vui lòng đăng nhập !':'Login please !'}</h1>
                        <div className="m_login_container_options">
                            <span>E-mail</span>
                        </div>
                        <form className="m_login_container_form">
                            <div style={{ boxSizing: "border-box" }}>
                                <label style={{

                                    left: dataUser ? dataUser.name.length > 0 ? "0.5%" : "1.5%" : "1.5%",
                                    top: dataUser ? dataUser.name.length > 0 ? "-20%" : "36%" : "36%",
                                    scale: dataUser ? dataUser.name.length > 0 ? "0.9" : "1" : "1",
                                    backgroundImage: `linear-gradient(to bottom,  ${dataUser ? dataUser.name.length > 0 ? "#000000" : "#1D1C22" : "#1D1C22"}, #1D1C22)`
                                }}>E-mail</label>
                                <input
                                    style={{ boxSizing: "border-box" }}
                                    ref={userRef}
                                    name="email"
                                    type="email"
                                    onChange={(e: any) => {

                                        const newDataUser = { ...dataUser }
                                        newDataUser.name = e.target.value;
                                        setDataUser(newDataUser)
                                    }}
                                />
                            </div>
                            <div style={{ boxSizing: "border-box" }}>
                                <label style={{
                                    left: dataUser ? dataUser.password.length > 0 ? "0.5%" : "1.5%" : "1.5%",
                                    top: dataUser ? dataUser.password.length > 0 ? "-20%" : "36%" : "36%",
                                    scale: dataUser ? dataUser.password.length > 0 ? "0.9" : "1" : "1",
                                    backgroundImage: `linear-gradient(to bottom,  ${dataUser ? dataUser.password.length > 0 ? "#000000" : "#1D1C22" : "#1D1C22"}, #1D1C22)`
                                }}>  {langs=='vi'?'Mật khẩu':'Password'} </label>

                                <input
                                    style={{ boxSizing: "border-box" }}
                                    name="password"
                                    type="password"
                                    ref={passwordRef}
                                    onChange={(e: any) => {
                                        const newDataUser = { ...dataUser }
                                        newDataUser.password = e.target.value;
                                        setDataUser(newDataUser)
                                    }}
                                />
                            </div>

                            <button style={{ cursor: "pointer" }} onClick={handleLogin} type="submit">
                               {langs=='vi'?'Đăng nhập':'Log in'} 
                            </button>
                        </form>
                    </div>
                </div>
                : <></>}

        </>

    )
}
export default Login