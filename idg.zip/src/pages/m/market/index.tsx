import { API_KEY } from "@/config/api"
import React, { useEffect, useRef, useState } from "react"
import { io } from "socket.io-client"
import { createChart } from "lightweight-charts"
import Link from "next/link"
import RenderMarket from "@/components/renderMarket"
import UseTranslate from "@/hook/translate"
import { useRouter } from "next/router"
import { userLogin } from "@/hook/useLogin"
const socket = io(`${API_KEY}`)
const Market: React.FC = () => {
    const [langs, setLangs] = useState<any>('')
    useEffect(() => {
        if (typeof window !== 'undefined') {
            if (document) {
                const htmlElement = document.querySelector('html');
                if (htmlElement) {
                    htmlElement.style.backgroundColor = '#000000';
                }
            }
        }
        const lang = localStorage.getItem('lang')
        if (lang) {
            setLangs(lang)
        } else {
            setLangs('en')
        }
        return () => {
            if (typeof window !== 'undefined') {
                if (document) {
                    const htmlElement = document.querySelector('html');
                    if (htmlElement) {
                        htmlElement.style.backgroundColor = 'transparent';
                    }
                }
            }
        };
    }, [])
    const marketArr = [
        {
            name: "DOGE",
        },
        {
            name: "XRP",
        },
        {
            name: "CHZ",
        },
        {
            name: "FTM",
        },
        {
            name: "MATIC",
        },
        {
            name: "SAND",
        },
        {
            name: "APE",
        },
        {
            name: "SOL",
        },
        {
            name: "DOT",
        },
        {
            name: "AVAX",
        },
        {
            name: "UNI",
        },
        {
            name: "ATOM",
        },
        {
            name: "AXS",
        },
        {
            name: "ETC",
        },
        {
            name: "BNB",
        },
        {
            name: "LTC",
        },
        {
            name: "ETH",
        },
        {
            name: "BTC",
        }
    ]

    const router = useRouter()
    const [stopTestUser, setStopTestUser] = useState<any>(false);
    useEffect(() => {
        async function runTestUser() {
            await userLogin(router)
        }
        if (!stopTestUser) {
            runTestUser()
            setStopTestUser(true)
            console.log('stop test user');
        }
    }, [stopTestUser])
    return (
        <div className="m_market">
            <UseTranslate
                data={{
                    Tag: 'div',
                    className: 'm_market_header',
                    lang: langs
                }} >
                <Link href={'#'}>
                    Cryptocurrency
                </Link>
            </UseTranslate>



            <div className="m_market_container">
                <table className="m_market_container_table">
                    <thead className="m_market_container_table_head">
                        <UseTranslate
                            data={{
                                Tag: 'tr',
                                className: '',
                                lang: langs
                            }} >
                            <th>
                                <span>Transaction / Trading volume</span>
                            </th>
                            <th>
                                <span>Price</span>
                            </th>
                            <th>
                                <span>24H rising decline</span>
                            </th>
                        </UseTranslate>

                    </thead>
                    <tbody className="m_market_container_table_body">
                        {marketArr.map((item: any, index: any) => {
                            return (
                                <RenderMarket key={index} nameTrade={item.name} />
                            )
                        })}

                    </tbody>
                </table>
            </div>
        </div>
    )
}
export default Market