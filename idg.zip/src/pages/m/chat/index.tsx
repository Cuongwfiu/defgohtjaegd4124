
import ImageZoom from "@/components/SingleImageGallery";
import { API_KEY } from "@/config/api";
import { socket } from "@/hook/socketIO"
import UseTranslate from "@/hook/translate";
import { userLogin } from "@/hook/useLogin";
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import axios from "axios";
import { useRouter } from "next/router";
import React, { useEffect, useRef, useState } from "react"
const Chat: React.FC = () => {
    const [dataChat, setDataChat] = useState<any>([])
    const [textSend, setTextSend] = useState<any>('')
    const [email, setEmail] = useState<any>('')
    const [runScroll, setRunScroll] = useState<any>(false)
    const contentChat = useRef<any>(null)
    const [isUser, setIsUser] = useState<any>('')
    const router = useRouter()
    const [autoChat, setAutoChat] = useState<any>('')
    const [langs, setLangs] = useState<any>('')
    const fileInputRef = useRef<any>(null);
    useEffect(() => {
        const lcs: any = localStorage
        lcs.setItem('realTime', true)
        window.addEventListener('beforeunload',()=>{
            lcs.removeItem('realTime')  
        })
        const lang = localStorage.getItem('lang')
        if (lang) {
            setLangs(lang)
        } else {
            setLangs('en')
        }
        const infoUser: any = localStorage.getItem('infoUser');
        if (infoUser) {
            const token = localStorage.getItem('token');
            if (!token) {
                localStorage.removeItem('infoUser')
                setIsUser('noUser')
            } else {
                setIsUser('isUser')
            }
            setEmail(JSON.parse(infoUser).email)

            socket.emit('user-join', { email: JSON.parse(infoUser).email, token: token })
            socket.on('chat', ({ data }) => {
                setDataChat(data)

            })
        } else {
            router.push('/m/login')
        }
        socket.on('data-chat-all', ({ data }) => {
            setDataChat(data);
            if (data.length > 0) {
            } else {
                setAutoChat('img')
                setTimeout(() => {
                    setAutoChat('msg')
                }, 2000)
            }
            if (contentChat.current) {
                if (contentChat.current.scrollHeight) {
                    setTimeout(() => {
                        const heightContent = contentChat.current.scrollHeight
                        contentChat.current.scrollTo({ top: heightContent });
                    }, 100);
                }

            }
            setRunScroll(true)
        })
        return()=>{
            lcs.removeItem('realTime')  
        }
    }, [])
    useEffect(() => {
        if (runScroll) {
            if (contentChat.current) {
                if (contentChat.current.scrollHeight) {
                    const heightContent = contentChat.current.scrollHeight
                    contentChat.current.scrollTo({ top: heightContent, behavior: 'smooth' });
                }

            }
        }

    }, [runScroll, dataChat])
    function formatTimeAgo(milliseconds: any) {
        const now = Math.floor(Date.now()); // Lấy thời gian hiện tại dưới dạng mili giây
        const elapsed = now - milliseconds;

        if (elapsed < 60000) { // 60 giây
            return `${Math.round(elapsed / 1000)} giây trước`;
        } else if (elapsed < 3600000) { // 60 phút
            const minutes = Math.floor(elapsed / 60000);
            return `${minutes} phút trước`;
        } else if (elapsed < 86400000) { // 24 giờ
            const hours = Math.floor(elapsed / 3600000);
            return `${hours} giờ trước`;
        } else if (elapsed < 2592000000) { // 30 ngày
            const days = Math.floor(elapsed / 86400000);
            return `${days} ngày trước`;
        } else if (elapsed < 31536000000) { // 365 ngày
            const months = Math.floor(elapsed / 2592000000);
            return `${months} tháng trước`;
        } else {
            const years = Math.floor(elapsed / 31536000000);
            return `${years} năm trước`;
        }
    }
    const [stopTestUser, setStopTestUser] = useState<any>(false);
    useEffect(() => {
        async function runTestUser() {
            await userLogin(router)
        }
        if (!stopTestUser) {
            runTestUser()
            setStopTestUser(true)
        }
    }, [stopTestUser])
    const [sendFile, setSendFile] = useState<any>(null)
    return (
        <>

            {isUser === 'isUser' ?
                <div className="main_chat_msg">
                    <div style={{ backgroundColor: "#247CFF" }} className="m_header_chat">
                        <ArrowBackIcon style={{ cursor: "pointer", color: "white" }}
                            onClick={() => { router.back() }} />
                        <h2 style={{ color: "white" }}>{langs == 'vi' ? 'Chăm sóc khách hàng' : 'Online support!'}</h2>
                    </div>
                    <div ref={contentChat} className="m_content_chat">
                        {dataChat.length > 0 ? dataChat.map((item: any, index: any) => {
                            if (item) {
                                if (item.type == 'image') {
                                    return (
                                        <div key={index} className={`bubbleWrapper`}>
                                            <div className={`${item.active.toLowerCase() === 'admin' ? 'inlineContainer' : 'inlineContainer own'}`}>
                                                {/* <img style={{ height: "40px", width: "40px" }} className="inlineIcon" src={`${item.active === 'admin' ? 'https://cdn.pixabay.com/photo/2019/08/11/18/59/icon-4399701_1280.png'
                                            : 'https://png.pngtree.com/png-vector/20191125/ourmid/pngtree-beautiful-admin-roles-line-vector-icon-png-image_2035379.jpg'}`} /> */}
                                                {item.active === 'admin' ? <img style={{ height: "40px", width: "40px" }} className="inlineIcon" src={`${API_KEY}/file-img/contact.png`} /> : <></>}
                                                <div style={{ backgroundColor: "transparent", border: "none" }} className={`${item.active.toLowerCase() === 'admin' ? 'otherBubble other' : 'ownBubble own'}`}>
                                                    <ImageZoom imageUrl={`${API_KEY}${item.msg}`} />
                                                </div>
                                            </div><span className={`${item.active.toLowerCase() === 'admin' ? 'other' : 'own'}`}>{formatTimeAgo(Number(item.date))}</span>
                                        </div>
                                    )
                                } else {
                                    return (
                                        <div key={index} className={`bubbleWrapper`}>
                                            <div className={`${item.active.toLowerCase() === 'admin' ? 'inlineContainer' : 'inlineContainer own'}`}>
                                                {item.active === 'admin' ? <img style={{ height: "40px", width: "40px" }} className="inlineIcon" src={`${API_KEY}/file-img/contact.png`} /> : <></>}

                                                <div className={`${item.active.toLowerCase() === 'admin' ? 'otherBubble other' : 'ownBubble own'}`}>
                                                    {item.msg}
                                                </div>
                                            </div><span className={`${item.active.toLowerCase() === 'admin' ? 'other' : 'own'}`}>{formatTimeAgo(Number(item.date))}</span>
                                        </div>
                                    )
                                }
                            }

                        }) : autoChat == 'img' ?
                            <div className={`bubbleWrapper`}>
                                <div className={`inlineContainer own'}`}>
                                    <img style={{ height: "40px", width: "40px" }} className="inlineIcon" src={`${API_KEY}/file-img/contact.png`} />

                                    <img style={{ width: 80 }} src="https://media.tenor.com/sMenWFrH3YsAAAAC/typing-text.gif" alt="" />

                                </div><span className={`other`}>{formatTimeAgo(Number(Date.now()))}</span>
                            </div>
                            : autoChat == 'msg' ?
                                <div className={`bubbleWrapper`}>
                                    <div className={`inlineContainer own'}`}>
                                        <img style={{ height: "40px", width: "40px" }} className="inlineIcon" src={`${API_KEY}/file-img/contact.png`} />
                                        <UseTranslate
                                            data={{
                                                Tag: 'div',
                                                className: 'otherBubble other',
                                                lang: langs
                                            }} >
                                            Hello, how can I help you?
                                        </UseTranslate>
                                    </div><span className={`other`}>{formatTimeAgo(Number(Date.now()))}</span>
                                </div> : ''
                        }

                    </div>
                    <div className="m_send_chat">
                        <div className="useFile">

                            <label htmlFor="file-chat">
                                <img src={`${API_KEY}/file-img/photo.png`} alt="" />
                            </label>
                            <input
                                ref={fileInputRef}
                                onChange={(e: any) => {
                                    if (e.target.files[0].type == 'image/jpeg' || e.target.files[0].type == 'image/png') {
                                        console.log(e.target.files[0])
                                        const ext = e.target.files[0].type.split('/')[1]
                                        socket.emit('chat', { email: email, msg: e.target.files[0], active: "user", date: Date.now(), type: "image", ext: ext })
                                        fileInputRef.current.value = null;
                                    }

                                }} id="file-chat" accept=".png,.jpg" type="file" />
                            <div className="useFile_like">    <img onClick={() => {
                                const msg = '👍'
                                setTextSend('')
                                socket.emit('chat', { email: email, msg: msg, active: "user", date: Date.now(), type: "text" })
                            }} src={`${API_KEY}/file-img/like.png`} alt="" /></div>
                        </div>
                        <div className="chat-box-footer">

                            <textarea value={textSend} onChange={(e) => {
                                setTextSend(e.target.value);
                            }} id="chat_input" placeholder={langs == 'vi' ? 'Nhập vào tin nhắn của bạn' : "Enter your message here..."}></textarea>
                            <button onClick={async () => {
                                setTextSend('')
                                socket.emit('chat', { email: email, msg: textSend, active: "user", date: Date.now(), type: "text" })
                            }} id="send">
                                <span className="send-chat" >{langs == 'vi' ? 'Gửi đi' : "Send"}</span>
                                {/* <svg style={{ width: "24px", height: "24px" }} viewBox="0 0 24 24">
                                <path fill="#006ae3" d="M2,21L23,12L2,3V10L17,12L2,14V21Z" />
                            </svg> */}
                            </button>
                        </div>
                    </div>
                </div>
                : isUser === 'noUser' ? <div>Vui lòng đăng nhập</div> : <></>}

        </>


    )
}
export default Chat