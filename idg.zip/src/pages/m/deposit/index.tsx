import UseTranslate from "@/hook/translate"
import { useRouter } from "next/router"
import React, { useEffect, useState } from "react"
import SupportAgentIcon from '@mui/icons-material/SupportAgent';
const Deposit: React.FC = () => {
    const router = useRouter()
    const [langs, setLangs] = useState<any>('')
    useEffect(() => {
        const lang = localStorage.getItem('lang')
        if (lang) {
            setLangs(lang)
        } else {
            setLangs('en')
        }
        if (document) {
            const htmlElement = document.querySelector('html');
            if (htmlElement) {
                htmlElement.style.backgroundColor = '#000000';
            }
        }

        return () => {
            if (typeof window !== 'undefined') {
                if (document) {
                    const htmlElement = document.querySelector('html');
                    if (htmlElement) {
                        htmlElement.style.backgroundColor = 'transparent';
                    }
                }
            }
        };
    }, [])
    return (
        <div>
            <div className="m_profile_header">
                <div>
                    <svg onClick={() => {
                        router.back()
                    }} className="MuiSvgIcon-root MuiSvgIcon-fontSizeMedium css-vubbuv" focusable="false" aria-hidden="true" viewBox="0 0 24 24" data-testid="ArrowBackIcon"><path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z"></path></svg>
                    <UseTranslate

                        data={{
                            Tag: 'h3',
                            className: '',
                            lang: langs
                        }} >
                        Deposit
                    </UseTranslate>
                </div>

            </div>
            <div>
                <UseTranslate
                    style={{ textAlign: "center" }}
                    data={{
                        Tag: 'h1',
                        className: '',
                        lang: langs
                    }} >
                    Choose your deposit method
                </UseTranslate>

                <div onClick={() => {
                    router.push('/m/chat')
                }} className="deposit">
                    <UseTranslate

                        data={{
                            Tag: 'span',
                            className: '',
                            lang: langs
                        }} >
                        Artificial Deposit
                    </UseTranslate>
                    <UseTranslate

                        data={{
                            Tag: 'span',
                            className: '',
                            lang: langs
                        }} >
                        Contact artificial customer service to get deposit guidelines
                    </UseTranslate>
                </div>
            </div>
        </div>
    )
}
export default Deposit