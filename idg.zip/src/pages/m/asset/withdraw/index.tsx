import { API_KEY } from "@/config/api";
import UseTranslate from "@/hook/translate";
import { Alert, Button, FormControl, InputLabel, MenuItem, Select, Snackbar, TextField } from "@mui/material";
import { styled } from '@mui/system';
import axios from "axios";
import { useRouter } from "next/router";
import React, { useEffect, useState } from "react"
const MyButton = styled(Button)(({ theme }) => ({
    backgroundColor: "#F7A600",
    color: "black",
    fontSize: "13px",
    fontWeight: 600,
    textTransform: "none",
    padding: "7px 0",
    '&:hover': {
        backgroundColor: '#BF7700',
    },
}));

const MyTransparentButton = styled(Button)(({ theme }) => ({
    backgroundColor: "transparent",
    color: "#BF7700",
    fontSize: "13px",
    fontWeight: 600,
    textTransform: "none",
    padding: "7px 0",
    border: "1px solid #BF7700",
    '&:hover': {
        border: "1px solid #ec960a",
    },
}));

const MyStartButton = styled(Button)(({ theme }) => ({
    backgroundColor: "#343338",
    color: "rgba(255, 255, 255, 0.397)",
    fontSize: "13px",
    textTransform: "none",
    '&:hover': {
        backgroundColor: "#343338",
    },
}));

const WithDraw: React.FC = () => {

    const router = useRouter()
    const [langs, setLangs] = useState<any>('')
    const [arrbanking, setArrBanking] = useState<any>([])
    const [banking, setBanking] = useState<any>('')
    const [currentbalance, setCurrentBalance] = useState<any>('')
    const [amount, setamount] = useState<any>('0')
    const [helperTexts, sethelperTexts] = useState<any>('')
    const [securityCode, setSecurityCode] = useState<any>('')
    const [notification, setNotification] = useState<any>('')
    const [confirmSuccess, setConfirmSuccess] = useState<any>('')
  
    const handleChange = async (e: any) => {
        setBanking(e.target.value);
    }
    const handleChangeAmount = (e: any) => {
        let newValue = e.target.value.replace(/[^0-9]/g, '');
        const value = parseFloat(newValue)
        setamount(value)
        if (newValue.length == 0) {
            setamount(0)
        }

    };
    const handleChangeSecurityCode = (e: any) => {
        setSecurityCode(e.target.value)
    };
    const formatCoin = (number: any) => {
        const formattedNumber = number.toLocaleString('en-US', {
            style: 'decimal',
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
        });
        return formattedNumber;
    }

    useEffect(() => {
        if (amount == 0) {
            if (langs == 'en') {
                sethelperTexts('The minimum amount is 1')
            } else if (langs == 'vi') {
                sethelperTexts('Số tiền tối thiểu là 1')
            } else {
                sethelperTexts('The minimum amount is 1')
            }

        } else {
            sethelperTexts('')
        }
    }, [amount, langs])
    useEffect(() => {
        const lang = localStorage.getItem('lang')
        if (lang) {
            setLangs(lang)
        } else {
            setLangs('en')
        }

        const infoUser: any = localStorage.getItem('infoUser')
        if (infoUser) {
            const token = localStorage.getItem('token')
            if (token) {
                const infoUserFunc = async () => {
                    const res = await axios.get(`${API_KEY}/info-user/${JSON.parse(infoUser).email}`, {
                        headers: {
                            Authorization: token
                        }
                    })
                    const data = res.data
                    if (data.banking.length > 0) {
                        setCurrentBalance(data.coin)
                        setArrBanking(data.banking)
                        setBanking(data.banking[0].BankAcc)
                        if (data.securityCode.length > 0) {
                            setSecurityCode(data.securityCode)
                        }
                    }

                }
                infoUserFunc()
            }

        }

        if (document) {
            const htmlElement = document.querySelector('html');
            if (htmlElement) {
                htmlElement.style.backgroundColor = '#000000';
            }
        }
        return () => {
            if (typeof window !== 'undefined') {
                if (document) {
                    const htmlElement = document.querySelector('html');
                    if (htmlElement) {
                        htmlElement.style.backgroundColor = 'transparent';
                    }
                }
            }
        };
    }, [])

    function hideValue(value: any) {
        const atIndex = value.length - 1
        const lastIndex = 1
        const slicevalue = value?.slice(lastIndex, atIndex)
        const lent = slicevalue?.length
        let str = ''
        for (let i = 0; i < lent; i++) {
            str += '*'
        }
        const relaceValue = value?.replace(slicevalue, str)
        return relaceValue;

    }
    const [open, setOpen] = useState<any>(false);
    const handleClose = (event?: React.SyntheticEvent | Event, reason?: string) => {
        setOpen(false);
    };
    const [open2, setOpen2] = useState<any>(false);
    const handleClose2 = (event?: React.SyntheticEvent | Event, reason?: string) => {
        setOpen2(false);
    };
    const [open3, setOpen3] = useState<any>(false);
    const handleClose3 = (event?: React.SyntheticEvent | Event, reason?: string) => {
        setOpen3(false);
    };
    return (
        <div>
            <div className="m_profile_header">
                <div>
                    <svg onClick={() => {
                        router.back()
                    }} className="MuiSvgIcon-root MuiSvgIcon-fontSizeMedium css-vubbuv" focusable="false" aria-hidden="true" viewBox="0 0 24 24" data-testid="ArrowBackIcon"><path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z"></path></svg>
                    <UseTranslate

                        data={{
                            Tag: 'h3',
                            className: '',
                            lang: langs
                        }} >
                        Withdraw
                    </UseTranslate>
                </div>

            </div>
            <div className="withdraw_container">
                <div className="withdraw_container_img">
                    <img src="https://www.idg88fx.com/_next/static/media/atm.8f0fc2f1.svg" alt="" />
                </div>
                <div className="withdraw_container_content">
                    <FormControl style={{ backgroundColor: "#1D1C22" }} fullWidth>
                        <InputLabel style={{ color: "white" }} >{langs == 'en' ? 'Account' : langs == 'vi' ? 'Tài khoản' : 'Account'}</InputLabel>
                        <Select
                            style={{ color: "white" }}
                            value={banking}
                            label="banking"
                            onChange={handleChange}
                        >
                            {arrbanking.map((item: any, index: any) => {
                                return (
                                    <MenuItem key={index} value={item.BankAcc}>{hideValue(item.BankAcc)} ({item.bankIns})</MenuItem>
                                )
                            })}
                        </Select>
                    </FormControl>
                    <TextField
                        onChange={handleChangeAmount}
                        value={amount}
                        error={amount == 0}
                        onFocus={() => {
                            if (amount > 0) {
                                sethelperTexts('')
                            } else {
                                if (langs == 'en') {
                                    sethelperTexts('The minimum amount is 1')
                                } else if (langs == 'vi') {
                                    sethelperTexts('Số tiền tối thiểu là 1')
                                } else {
                                    sethelperTexts('The minimum amount is 1')
                                }

                            }
                        }} helperText={helperTexts} inputProps={{ style: { color: "white" } }} fullWidth style={{ backgroundColor: "#1D1C22", marginTop: 30 }} label={langs == 'vi' ? "Số tiền" : "Amount"} variant="outlined" />
                    <div className="withdraw_container_content_balance mt">
                        <UseTranslate

                            data={{
                                Tag: 'span',
                                className: '',
                                lang: langs
                            }} >
                            Current balance:
                        </UseTranslate>
                        <span>{formatCoin(currentbalance)} USDT</span>
                    </div>
                    <TextField
                        type="password"
                        onChange={handleChangeSecurityCode}
                        value={securityCode}
                        inputProps={{ style: { color: "white" } }} fullWidth style={{ backgroundColor: "#1D1C22", marginTop: 20 }} label={langs == 'vi' ? "Mật khẩu bị mật" : "Security Code"} variant="outlined" />

                    <div className="mt">
                        <MyButton onClick={() => {
                            router.push('/m/setting/password/security')
                        }} fullWidth>
                            <UseTranslate
                                style={{ color: 'black' }}
                                data={{
                                    Tag: 'span',
                                    className: '',
                                    lang: langs
                                }} >
                                Manage the withdrawal password
                            </UseTranslate>
                        </MyButton>
                    </div>
                    <div className="mt">
                        <MyTransparentButton onClick={() => {
                            router.push('/m/setting/payment')
                        }} fullWidth>
                            <UseTranslate
                                style={{ color: "#F7A600" }}
                                data={{
                                    Tag: 'span',
                                    className: '',
                                    lang: langs
                                }} >
                                Management of withdrawal
                            </UseTranslate>
                        </MyTransparentButton>
                    </div>
                    <div className="comfirm_withdraw">
                        <div className="comfirm_withdraw_fees">
                            <UseTranslate
                                data={{
                                    Tag: 'span',
                                    className: '',
                                    lang: langs
                                }} >
                                Fees
                            </UseTranslate>
                            <span>{formatCoin((2 / 100) * Number(amount))} USDT</span>
                        </div>
                        <div className="comfirm_withdraw_amount">
                            <UseTranslate
                                data={{
                                    Tag: 'span',
                                    className: '',
                                    lang: langs
                                }} >
                                Amount Received
                            </UseTranslate>

                            <span>{formatCoin(Number(amount) - ((2 / 100) * Number(amount)))} USDT</span>
                        </div>
                        {amount == '0' ? <MyStartButton fullWidth>{langs == 'vi' ? 'Xác nhận' : 'Confirm'}</MyStartButton> : <MyButton onClick={() => {
                            if (Number(amount) > Number(currentbalance)) {
                                setOpen(true)
                            } else {

                                const token = localStorage.getItem('token')
                                const infoUser = localStorage.getItem('infoUser')
                                if (infoUser) {
                                    if (token) {
                                        axios.post(`${API_KEY}/with-draw`, {
                                            amount: amount,
                                            email: JSON.parse(infoUser).email,
                                            token: token,
                                            securityCode: securityCode
                                        }).then((res: any) => {
                                            if (res.data.status == 'success') {
                                                setCurrentBalance(res.data.resCoin)
                                                setConfirmSuccess(<UseTranslate
                                                    style={{ color: "#418944" }}
                                                    data={{
                                                        Tag: 'span',
                                                        className: '',
                                                        lang: langs
                                                    }} >
                                                    Successful purchase
                                                </UseTranslate>)
                                                setOpen3(true)

                                            } else {
                                                setOpen2(true)
                                                setNotification(
                                                    <UseTranslate
                                                        style={{ color: "#EC4134" }}
                                                        data={{
                                                            Tag: 'span',
                                                            className: '',
                                                            lang: langs
                                                        }} >
                                                        {res.data.status}
                                                    </UseTranslate>

                                                )
                                            }
                                        })
                                    }
                                }

                            }
                        }} fullWidth>{langs == 'vi' ? 'Xác nhận' : 'Confirm'}</MyButton>}
                    </div>
                </div>
            </div>
            <Snackbar open={open} autoHideDuration={6000} onClose={handleClose}>
                <Alert onClose={handleClose} severity="error" sx={{ width: '100%' }}>
                    ( <UseTranslate
                        style={{ color: "#EC4134" }}
                        data={{
                            Tag: 'span',
                            className: '',
                            lang: langs
                        }} >
                        Insufficient balance
                    </UseTranslate>
                    )
                </Alert>
            </Snackbar>
            <Snackbar open={open2} autoHideDuration={6000} onClose={handleClose2}>
                <Alert onClose={handleClose2} severity="error" sx={{ width: '100%' }}>
                    <span>{notification}</span>
                </Alert>
            </Snackbar>
            <Snackbar open={open3} autoHideDuration={6000} onClose={handleClose3}>
                <Alert onClose={handleClose3} severity="success" sx={{ width: '100%' }}>
                    {confirmSuccess}
                </Alert>
            </Snackbar>
        </div>
    )
}
export default WithDraw