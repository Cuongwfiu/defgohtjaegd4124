import React from "react"
const Learn:React.FC = ()=>{
return(
<>
<object data="https://www.idg88fx.com/m/learn" type="application/pdf" style={{width:"100%",height:"100vh"}}>
</object>
</>
)
}
export default Learn