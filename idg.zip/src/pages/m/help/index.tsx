import React from "react"
const HelpCenter:React.FC = ()=>{
return(
<>
<object data="https://www.idg88fx.com/m/help"  style={{width:"100%",height:"100vh"}}>
</object>
</>
)
}
export default HelpCenter