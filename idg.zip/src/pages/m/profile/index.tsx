
import UseTranslate from "@/hook/translate"
import { userLogin } from "@/hook/useLogin"
import { useRouter } from "next/router"
import React, { useEffect, useState } from "react"


const Profile: React.FC = (props) => {
    const router = useRouter()

    const [infoUS, setInfoUS] = useState<any>(null)
    const [langs, setLangs] = useState<any>('')
    const [fullNameLang, setFullNameLang] = useState<any>('')

    useEffect(() => {
        const lang = localStorage.getItem('lang')
        const fullnamelang = localStorage.getItem('fullnamelang')
        if (lang) {
            setLangs(lang)
        } else {
            setLangs('en')
        }
        if (fullnamelang) {
            setFullNameLang(fullnamelang)
        } else {
            setFullNameLang('English')
        }



        const infoUser: any = localStorage.getItem('infoUser');
        if (infoUser) {

            setInfoUS(JSON.parse(infoUser))
        } else {
            router.push('/m/home')
        }



    }, [])
    function hideEmail(email: any) {
        const atIndex = email?.indexOf('@') - 2
        const lastIndex = 2
        const sliceEmail = email?.slice(lastIndex, atIndex)
        const lent = sliceEmail?.length
        let str = ''
        for (let i = 0; i < lent; i++) {
            str += '*'
        }
        const relaceEmail = email?.replace(sliceEmail, str)
        return relaceEmail;

    }
    const [stopTestUser, setStopTestUser] = useState<any>(false);
    useEffect(() => {
        async function runTestUser() {
            await userLogin(router)
        }
        if (!stopTestUser) {
            runTestUser()
            setStopTestUser(true)
            console.log('stop test user');
        }
    }, [stopTestUser])
    return (
        <div className="m_profile">
            <div className="m_profile_header">
                <div>
                    <svg onClick={() => {
                        router.back()
                    }} className="MuiSvgIcon-root MuiSvgIcon-fontSizeMedium css-vubbuv" focusable="false" aria-hidden="true" viewBox="0 0 24 24" data-testid="ArrowBackIcon"><path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z"></path></svg>
                    <UseTranslate

                        data={{
                            Tag: 'h3',
                            className: '',
                            lang: langs
                        }} >
                        Personal center
                    </UseTranslate>
                </div>
            </div>
            <div className="m_profile_container">
                <div className="m_profile_container_block1">

                    <div>
                        <span>
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 24 24" className="text-xl fill-secondary-main [&amp;>path:first-child]:fill-primary-main" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg"><path d="M12 10c1.151 0 2-.848 2-2s-.849-2-2-2c-1.15 0-2 .848-2 2s.85 2 2 2zm0 1c-2.209 0-4 1.612-4 3.6v.386h8V14.6c0-1.988-1.791-3.6-4-3.6z"></path><path d="M19 2H5c-1.103 0-2 .897-2 2v13c0 1.103.897 2 2 2h4l3 3 3-3h4c1.103 0 2-.897 2-2V4c0-1.103-.897-2-2-2zm-5 15-2 2-2-2H5V4h14l.002 13H14z"></path></svg>
                            <UseTranslate

                                data={{
                                    Tag: 'span',
                                    className: '',
                                    lang: langs
                                }} > User name</UseTranslate>

                        </span>

                        <span>  {infoUS?.name}</span>
                    </div>
                    <div>
                        <span><svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 24 24" className="text-xl fill-secondary-main [&amp;>path:last-child]:fill-primary-main" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg"><path fill="none" d="M0 0h24v24H0z"></path><path d="M3 6l8 5 8-5v3h2V4c0-1.1-.9-2-2-2H3c-1.1 0-1.99.9-1.99 2L1 16c0 1.1.9 2 2 2h10v-2H3V6zm16-2l-8 5-8-5h16z"></path><path d="M21 14v4c0 1.1-.9 2-2 2s-2-.9-2-2v-4.5c0-.28.22-.5.5-.5s.5.22.5.5V18h2v-4.5a2.5 2.5 0 00-5 0V18c0 2.21 1.79 4 4 4s4-1.79 4-4v-4h-2z"></path></svg> Mail</span>

                        <span>{hideEmail(infoUS?.email)}</span>

                    </div>
                    <div>
                        <span>
                            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 16 16" className="text-xl fill-secondary-main [&amp;>path:last-child]:fill-primary-main" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg"><path d="M11 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h6zM5 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H5z"></path><path d="M8 14a1 1 0 1 0 0-2 1 1 0 0 0 0 2z"></path></svg>
                            <UseTranslate

                                data={{
                                    Tag: 'span',
                                    className: '',
                                    lang: langs
                                }} >
                                Phone number
                            </UseTranslate>
                        </span>
                        <span> Not set</span>


                    </div>
                    <div onClick={() => {
                        router.push('/m/setting/password')
                    }}>
                        <span>
                            <svg stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round" className="text-xl stroke-secondary-main [&amp;>path:last-child]:stroke-primary-main" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 9.9-1"></path></svg>

                            <UseTranslate

                                data={{
                                    Tag: 'span',
                                    className: '',
                                    lang: langs
                                }} >
                                Login password
                            </UseTranslate>

                        </span>
                        <span><svg className="MuiSvgIcon-root MuiSvgIcon-colorDisabled MuiSvgIcon-fontSizeMedium css-159og39" focusable="false" aria-hidden="true" viewBox="0 0 24 24" data-testid="ArrowForwardIcon"><path d="m12 4-1.41 1.41L16.17 11H4v2h12.17l-5.58 5.59L12 20l8-8z"></path></svg></span>
                    </div>
                    <div onClick={() => {
                        router.push('/m/setting/password/security')
                    }}>
                        <span>
                            <svg stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round" className="text-xl stroke-secondary-main [&amp;>path:last-child]:stroke-primary-main" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 9.9-1"></path></svg>

                            <UseTranslate

                                data={{
                                    Tag: 'span',
                                    className: '',
                                    lang: langs
                                }} >
                                Security Code
                            </UseTranslate>

                        </span>
                        <span><svg className="MuiSvgIcon-root MuiSvgIcon-colorDisabled MuiSvgIcon-fontSizeMedium css-159og39" focusable="false" aria-hidden="true" viewBox="0 0 24 24" data-testid="ArrowForwardIcon"><path d="m12 4-1.41 1.41L16.17 11H4v2h12.17l-5.58 5.59L12 20l8-8z"></path></svg></span>
                    </div>
                </div>
                <div className="m_profile_container_block2">
                    <div onClick={() => {
                        router.push('/m/setting/payment')
                    }}><span><svg stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round" className="text-xl stroke-secondary-main [&amp;>path:nth-child(n+7)]:stroke-primary-main" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><path d="M3 21l18 0"></path><path d="M3 10l18 0"></path><path d="M5 6l7 -3l7 3"></path><path d="M4 10l0 11"></path><path d="M20 10l0 11"></path><path d="M8 14l0 3"></path><path d="M12 14l0 3"></path><path d="M16 14l0 3"></path></svg>

                            <UseTranslate

                                data={{
                                    Tag: 'span',
                                    className: '',
                                    lang: langs
                                }} >
                                Withdrawal account
                            </UseTranslate>

                        </span>
                        <span><svg className="MuiSvgIcon-root MuiSvgIcon-colorDisabled MuiSvgIcon-fontSizeMedium css-159og39" focusable="false" aria-hidden="true" viewBox="0 0 24 24" data-testid="ArrowForwardIcon"><path d="m12 4-1.41 1.41L16.17 11H4v2h12.17l-5.58 5.59L12 20l8-8z"></path></svg></span>


                    </div>
                </div>
                <div className="m_profile_container_block3">
                    <div onClick={() => {
                        router.push('/m/setting/locale')
                    }}>
                        <span><svg stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round" className="text-xl stroke-secondary-main [&amp;>path:nth-child(n+6)]:stroke-primary-main" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><path d="M4 5h7"></path><path d="M7 4c0 4.846 0 7 .5 8"></path><path d="M10 8.5c0 2.286 -2 4.5 -3.5 4.5s-2.5 -1.135 -2.5 -2c0 -2 1 -3 3 -3s5 .57 5 2.857c0 1.524 -.667 2.571 -2 3.143"></path><path d="M12 20l4 -9l4 9"></path><path d="M19.1 18h-6.2"></path></svg>
                            <UseTranslate

                                data={{
                                    Tag: 'span',
                                    className: '',
                                    lang: langs
                                }} >
                                Language
                            </UseTranslate>

                        </span>

                        <span>{fullNameLang}<svg className="MuiSvgIcon-root MuiSvgIcon-colorDisabled MuiSvgIcon-fontSizeMedium css-159og39" focusable="false" aria-hidden="true" viewBox="0 0 24 24" data-testid="ArrowForwardIcon"><path d="m12 4-1.41 1.41L16.17 11H4v2h12.17l-5.58 5.59L12 20l8-8z"></path></svg></span>

                    </div>
                    <div>
                        <span><svg stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round" className="text-xl stroke-secondary-main [&amp;>line]:stroke-primary-main" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>
                            <UseTranslate

                                data={{
                                    Tag: 'span',
                                    className: '',
                                    lang: langs
                                }} >
                                About Us
                            </UseTranslate>
                        </span>
                        <span><svg className="MuiSvgIcon-root MuiSvgIcon-colorDisabled MuiSvgIcon-fontSizeMedium css-159og39" focusable="false" aria-hidden="true" viewBox="0 0 24 24" data-testid="ArrowForwardIcon"><path d="m12 4-1.41 1.41L16.17 11H4v2h12.17l-5.58 5.59L12 20l8-8z"></path></svg></span>

                    </div>
                </div>
            </div>
            <div className="m_profile_logout"><button onClick={() => {
                localStorage.removeItem('token')
                localStorage.removeItem('infoUser')
                window.location.reload()
            }}>Log out</button></div>
        </div>
    )

}



export default Profile