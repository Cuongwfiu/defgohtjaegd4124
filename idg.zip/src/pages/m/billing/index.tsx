import { API_KEY } from "@/config/api"
import UseTranslate from "@/hook/translate"
import axios from "axios"
import { useRouter } from "next/router"
import React, { useEffect, useState } from "react"
const Billing: React.FC = () => {
    const router = useRouter()
    const [langs, setLangs] = useState<any>('')
    const [dataBill, setDataBIll] = useState<any>([])
    useEffect(() => {
        const lang = localStorage.getItem('lang')
        if (lang) {
            setLangs(lang)
        } else {
            setLangs('en')
        }
        if (document) {
            const htmlElement = document.querySelector('html');
            if (htmlElement) {
                htmlElement.style.backgroundColor = '#000000';
            }
        }
        const getBill = async () => {
            const infoUser = localStorage.getItem('infoUser');
            const token = localStorage.getItem('token');
            if (infoUser) {
                if (token) {
                    const res = await axios.get(`${API_KEY}/bill-data/${JSON.parse(infoUser).email}`, {
                        headers: {
                            Authorization: token
                        }
                    })
                    if (res.data.status == 1) {
                        setDataBIll(res.data.data)
                    }
                }
            }

        }
        getBill()
        return () => {
            if (typeof window !== 'undefined') {
                if (document) {
                    const htmlElement = document.querySelector('html');
                    if (htmlElement) {
                        htmlElement.style.backgroundColor = 'transparent';
                    }
                }
            }
        };
    }, [])
    const btoaData = (obj: any, index: any) => {
        const newObj = { ...obj, index: index }
        const str = btoa(JSON.stringify(newObj))
        const lastIndex = str.length - 2
        const firtIndex = str.length - 13
        return str.slice(firtIndex, lastIndex)
    }
    function formatUnixTimestamp(timestamp: any) {
        const date = new Date(timestamp);
        const year = date.getFullYear();
        const month = (date.getMonth() + 1).toString().padStart(2, '0'); // Tháng bắt đầu từ 0, nên cần cộng thêm 1
        const day = date.getDate().toString().padStart(2, '0');
        const hours = date.getHours().toString().padStart(2, '0');
        const minutes = date.getMinutes().toString().padStart(2, '0');
        const seconds = date.getSeconds().toString().padStart(2, '0');

        return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
    }
    return (
        <div>
            <div className="m_profile_header">
                <div>
                    <svg onClick={() => {
                        router.back()
                    }} className="MuiSvgIcon-root MuiSvgIcon-fontSizeMedium css-vubbuv" focusable="false" aria-hidden="true" viewBox="0 0 24 24" data-testid="ArrowBackIcon"><path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z"></path></svg>
                    <UseTranslate

                        data={{
                            Tag: 'h3',
                            className: '',
                            lang: langs
                        }} >
                        Bill
                    </UseTranslate>
                </div>

            </div>
            <div className="bill_container">
                {dataBill.map((item: any, index: any) => {
                    return (
                        <div className="bill_container_item" key={index}>
                            <div className="bill_container_item_header">
                                <div>
                                    <UseTranslate

                                        data={{
                                            Tag: 'span',
                                            className: '',
                                            lang: langs
                                        }} >
                                        {item.type == 1 ? 'Deposit' : 'Withdraw'}
                                    </UseTranslate>

                                    <UseTranslate

                                        data={{
                                            Tag: 'span',
                                            className: '',
                                            lang: langs
                                        }} >
                                        Income
                                    </UseTranslate>

                                </div>
                                <div>
                                    <span>{btoaData(item, index)}</span>
                                    <span>{formatUnixTimestamp(item.date)}</span>
                                </div>
                            </div>
                            <div className="bill_container_item_container">
                                <div>
                                    <UseTranslate

                                        data={{
                                            Tag: 'span',
                                            className: '',
                                            lang: langs
                                        }} >
                                        Quantity
                                    </UseTranslate>

                                    <span>{item.type == 1 ?Number(item.coin):Number(item.coin) - ((2 / 100) * Number(item.coin))}</span>
                                    
                                </div>
                                <div>
                                    <UseTranslate

                                        data={{
                                            Tag: 'span',
                                            className: '',
                                            lang: langs
                                        }} >
                                        Processing fee
                                    </UseTranslate>

                                    <span>{item.type == 1 ?0:(2 / 100) * Number(item.coin)} USD</span>
                                </div>
                                <div>
                                    <UseTranslate

                                        data={{
                                            Tag: 'span',
                                            className: '',
                                            lang: langs
                                        }} >
                                        Status
                                    </UseTranslate>

                                    <span style={{ backgroundColor: item.status == 1 ? '#112317' : '#2C1110', padding: "4px", color: item.status == 1 ? '#3a8051' : '#b64c48' }}>{item.status == 1 ? 'Thành công' : 'Đang xử lý'}</span>
                                </div>
                            </div>
                        </div>
                    )
                })}
            </div>
        </div>
    )
}
export default Billing