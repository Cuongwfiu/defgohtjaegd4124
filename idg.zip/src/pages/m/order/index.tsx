import { API_KEY } from "@/config/api"
import { socket } from "@/hook/socketIO"
import UseTranslate from "@/hook/translate"
import axios from "axios"
import { useRouter } from "next/router"
import React, { useEffect, useState } from "react"
const Billing: React.FC = () => {
    const router = useRouter()
    const [langs, setLangs] = useState<any>('')
    const [dataCart, setDataCart] = useState<any>([])
    const [minute, setMinute] = useState<any>(1)
    const formatCoin = (number: any) => {
        const formattedNumber = number.toLocaleString('en-US', {
            style: 'decimal',
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
        });
        return formattedNumber;
    }
    useEffect(() => {
        const lang = localStorage.getItem('lang')
        if (lang) {
            setLangs(lang)
        } else {
            setLangs('en')
        }
        const infoUser: any = localStorage.getItem('infoUser');
        if (infoUser) {
            const token = localStorage.getItem('token')
            if (!token) {
                localStorage.removeItem('infoUser')
                window.location.reload()
            }

            socket.emit('cart-user', { email: JSON.parse(infoUser).email })
        } else {
            router.push('/m/login')
        }
        if (document) {
            const htmlElement = document.querySelector('html');
            if (htmlElement) {
                htmlElement.style.backgroundColor = '#000000';
            }
        }
        socket.on('send-cart', res => {
            setDataCart(res.data);
        })
        return () => {
            if (typeof window !== 'undefined') {
                if (document) {
                    const htmlElement = document.querySelector('html');
                    if (htmlElement) {
                        htmlElement.style.backgroundColor = 'transparent';
                    }
                }
            }
        };
    }, [])
   
  
    return (
        <div>
            <div className="m_profile_header">
                <div>
                    <svg onClick={() => {
                        router.back()
                    }} className="MuiSvgIcon-root MuiSvgIcon-fontSizeMedium css-vubbuv" focusable="false" aria-hidden="true" viewBox="0 0 24 24" data-testid="ArrowBackIcon"><path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z"></path></svg>
                    <UseTranslate

                        data={{
                            Tag: 'h3',
                            className: '',
                            lang: langs
                        }} >
                        Order
                    </UseTranslate>
                </div>

            </div>
            <div className="order_container">
              
              
              
              
              
              
                <div className="m_trade_orderTrade">
                    <div className="m_trade_orderTrade_header">
                        <UseTranslate
                            data={{
                                Tag: 'div',
                                className: '',
                                lang: langs
                            }} >
                            <span>Positions <div></div></span>
                            {typeof window !== 'undefined' && window.innerWidth > 550 ? <span>Orders</span> : ''}
                        </UseTranslate>

                        <UseTranslate
                            data={{
                                Tag: 'div',
                                className: '',
                                lang: langs
                            }} >
                            {typeof window !== 'undefined' && window.innerWidth > 550 ? <>
                                <span>Positions <div></div></span>
                                <span>Orders</span>
                            </> : ''}

                            <button>All Orders</button>
                        </UseTranslate >

                    </div>
                    <div className="m_trade_orderTrade_cart">
                        {dataCart.length > 0 ? dataCart.sort((a: any, b: any) => b.date - a.date).map((item: any, index: any) => {
                            const startTime = item.date;
                            const second = Number(minute) * 60

                            const currentTime = new Date().getTime();
                            const elapsedTimeInSeconds = (currentTime - startTime) / 1000;
                            const time = Math.round(second - Number(elapsedTimeInSeconds))
                            const criculeBorder = 359
                            const percentTime = Math.round((time / second) * 100)
                            const parcentIncre = 100 - percentTime
                            const parcentCricucle = Math.round((parcentIncre / 100) * criculeBorder)
                            // console.log(totalCricucle);
                            let timeEnd = false
                            if (elapsedTimeInSeconds > second) {
                                timeEnd = true
                            } else {
                                timeEnd = false
                            }
                            if (timeEnd) {
                                return (
                                    <div className="m_trade_orderTrade_cart_item" key={index}>
                                        <div className="m_trade_orderTrade_cart_item_header">

                                            <div>
                                                {item.nameCoin}/<span>USDT</span> <span>{langs == 'vi' ? 'Giao dịch mua' : 'Purchase transaction'} {item.minute} minute</span>

                                            </div>

                                            <div>
                                                {item.people.length > 0 ? item.people.toLowerCase() == 'win' ? <span style={{ color: "green" }}>{item.people}</span> : <span style={{ color: "red" }}>{item.people}</span> : langs == 'vi' ? 'Chờ kết quả' : 'Wait for results'}
                                            </div>


                                        </div>
                                        <div className="m_trade_orderTrade_cart_item_content" >


                                            <UseTranslate
                                                data={{
                                                    Tag: 'div',
                                                    className: '',
                                                    lang: langs
                                                }} >
                                                <span>Order price</span>
                                                <span>{formatCoin(Number(item.priceOrder))}</span>
                                            </UseTranslate >
                                            <UseTranslate
                                                data={{
                                                    Tag: 'div',
                                                    className: '',
                                                    lang: langs
                                                }} >
                                                <span>Amount of money</span>
                                                <span>{formatCoin(Number(item.coin))} USDT</span>
                                            </UseTranslate >
                                            <UseTranslate
                                                data={{
                                                    Tag: 'div',
                                                    className: '',
                                                    lang: langs
                                                }} >
                                                <span>Expected profits</span>
                                                <span>+ {formatCoin(Number(item.profit))} USDT</span>
                                            </UseTranslate >

                                        </div>
                                    </div>
                                )
                            } else {
                                return (
                                    <div className="m_trade_orderTrade_cart_item" key={index}>
                                        <div className="m_trade_orderTrade_cart_item_header" >

                                            <div>
                                                {item.nameCoin}/<span>USDT</span> <span>{langs == 'vi' ? 'Giao dịch mua' : 'Purchase transaction'} {item.minute} minute</span>
                                            </div>

                                            <div style={{ backgroundImage: `conic-gradient(#F2A301 ${parcentCricucle}deg, rgb(0, 0, 0) 0deg)` }} id="cricule_time"><span>{time} s</span></div>
                                        </div>
                                        <div className="m_trade_orderTrade_cart_item_content" >
                                            <UseTranslate
                                                data={{
                                                    Tag: 'div',
                                                    className: '',
                                                    lang: langs
                                                }} >
                                                <span>Order price</span>
                                                <span>{formatCoin(Number(item.priceOrder))}</span>
                                            </UseTranslate >
                                            <UseTranslate
                                                data={{
                                                    Tag: 'div',
                                                    className: '',
                                                    lang: langs
                                                }} >
                                                <span>Amount of money</span>
                                                <span>{formatCoin(Number(item.coin))} USDT</span>
                                            </UseTranslate >
                                            <UseTranslate
                                                data={{
                                                    Tag: 'div',
                                                    className: '',
                                                    lang: langs
                                                }} >
                                                <span>Expected profits</span>
                                                <span>+ {formatCoin(Number(item.profit))} USDT</span>
                                            </UseTranslate >

                                        </div>
                                    </div>
                                )
                            }

                        }) :
                            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", width: "100%" }}>
                                <img style={{ width: 200, height: 200 }} src="https://www.idg88fx.com/_next/static/media/empty.71a84b9a.svg" alt="" />
                                <h3>No data</h3>
                            </div>
                        }
                    </div>
                </div>
            </div>
        </div>
    )
}
export default Billing