import { API_KEY } from "@/config/api"
import { Alert, Snackbar } from "@mui/material"
import axios from "axios"
import Link from "next/link"
import { useRouter } from "next/router"
import React, { useEffect, useRef, useState } from "react"
const Login: React.FC = () => {
    const router = useRouter()
    const [langs, setLangs] = useState<any>('')
    const [activeConfirm, setActiveConfirm] = useState<any>(false)
    useEffect(() => {
        const lang = localStorage.getItem('lang')
        if (lang) {
            setLangs(lang)
        } else {
            setLangs('en')
        }
        const token = localStorage.getItem('token')
        if (token !== 'undefined') {
            if (token) {
                router.push('/m/home')
            }
        }
    }, [])
    const [dataUser, setDataUser] = useState<any>({
        name: "",
        email: "",
        password: "",
    })



    function isInvalidEmail(email: any) {
        // Sử dụng biểu thức chính quy để kiểm tra địa chỉ email
        const emailPattern = /^[a-zA-Z0-9._-]+@gmail\.com$/;
        return emailPattern.test(email);
    }

    const [open, setOpen] = useState(false);
    const [emailAd, setEmailAd] = useState(false);
    const [passwordAd, setpasswordAd] = useState(false);
    const [nameAd, setnameAd] = useState(false);
    const [ETEmail, setETEmail] = useState(false);
    const handleCloseemailAd = () => {
        setEmailAd(false)
    }
    const handleClosepassAd = () => { setpasswordAd(false) }
    const handleClosenameAd = () => {
        setnameAd(false)
    }
    const handleClose = (event?: React.SyntheticEvent | Event, reason?: string) => {
        if (reason === 'clickaway') {
            return;
        }

        setOpen(false);
    };
    const EnterEmail = () => {
        setETEmail(false)
    }
    const handleLogin = async (e: any) => {
        e.preventDefault();
        const form = e.target.form;

        const data = await axios.get(`${API_KEY}/get-email`)
        const arrEmail = data.data
        const findEmail = arrEmail.find((item: any) => item === dataUser.email)
        const name = dataUser.name
        const email = dataUser.email
        const password = dataUser.password
        if (name.length == 0 || email.length == 0 || password.length == 0) {
            setOpen(true);
        } else {
            if (findEmail) {
                setEmailAd(true)
            } else {
                if (!isInvalidEmail(dataUser.email)) {
                    setETEmail(true)
                } else {
                    if (name.length >= 5) {
                        if (password.length >= 8) {
                            try {
                                const response = await axios.post(`${API_KEY}/register`, {
                                    name: name,
                                    email: email,
                                    password: password
                                }
                                );
                                const { token } = response.data;
                                document.cookie = `token="${token}"`
                                setActiveConfirm(true)
                                axios.post(`${API_KEY}/login`, {
                                    email: email,
                                    password:password
                                }).then(item => {
                                    if (item.data.token == 'undefined') {
                                        alert('Lỗi đăng nhập')
                                    } else {
                                        localStorage.setItem('token', item.data.token)
                                        localStorage.setItem('infoUser', JSON.stringify({ email: item.data.email, name: item.data.username }))
                                        setTimeout(() => {
                                            router.push('/m/home')
                                            setActiveConfirm(false)
                                        }, 4000)
                                  
                                    }
                                })
                              
                            }
                            catch (error) {

                            }
                        } else {
                            setpasswordAd(true)
                        }
                    } else {
                        setnameAd(true)
                    }

                }
            }

        }


        // e.target.closest('form').submit()

    }

    const EnterConfirm = () => {

    }
    return (
        <div className="m_login">
            <div className="m_login_header">
                <svg style={{ cursor: "pointer" }} onClick={() => {
                    router.push('/m/home')
                }} className="MuiSvgIcon-root MuiSvgIcon-fontSizeMedium css-vubbuv" focusable="false" aria-hidden="true" viewBox="0 0 24 24" data-testid="ArrowBackIcon"><path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z"></path></svg>
                <Link href={'/m/login'} >{langs=='vi'?'Đăng nhập':'Log in'}</Link>
            </div>
            <div className="m_login_container">
                <h1>{langs=='vi'?'Đăng ký ngay':'Register immediately!'}</h1>
                <div className="m_login_container_options">
                    <span>E-mail</span>
                </div>
                <form className="m_login_container_form">
                    <div style={{ boxSizing: "border-box" }}>
                        <label style={{

                            left: dataUser ? dataUser.name.length > 0 ? "0.5%" : "1.5%" : "1.5%",
                            top: dataUser ? dataUser.name.length > 0 ? "-20%" : "36%" : "36%",
                            scale: dataUser ? dataUser.name.length > 0 ? "0.9" : "1" : "1",
                            backgroundImage: `linear-gradient(to bottom,  ${dataUser ? dataUser.name.length > 0 ? "#000000" : "#1D1C22" : "#1D1C22"}, #1D1C22)`
                        }}>{langs == 'vi' ? 'Họ tên' : 'User name'}</label>
                        <input
                            style={{ boxSizing: "border-box" }}
                            name="username"
                            type="name"
                            onChange={(e: any) => {

                                const newDataUser = { ...dataUser }
                                newDataUser.name = e.target.value;
                                setDataUser(newDataUser)
                            }}
                        />
                    </div>
                    <div style={{ boxSizing: "border-box" }}>
                        <label style={{
                            left: dataUser ? dataUser.email.length > 0 ? "0.5%" : "1.5%" : "1.5%",
                            top: dataUser ? dataUser.email.length > 0 ? "-20%" : "36%" : "36%",
                            scale: dataUser ? dataUser.email.length > 0 ? "0.9" : "1" : "1",
                            backgroundImage: `linear-gradient(to bottom,  ${dataUser ? dataUser.email.length > 0 ? "#000000" : "#1D1C22" : "#1D1C22"}, #1D1C22)`
                        }}>  {langs == 'vi' ? 'E-mail' : 'E-mail'}</label>

                        <input style={{ boxSizing: "border-box" }}
                            name="email"
                            type="email"
                            onChange={(e: any) => {
                                const newDataUser = { ...dataUser }
                                newDataUser.email = e.target.value;
                                setDataUser(newDataUser)
                            }}
                        />
                    </div>
                    <div style={{ boxSizing: "border-box" }}>
                        <label style={{
                            left: dataUser ? dataUser.password.length > 0 ? "0.5%" : "1.5%" : "1.5%",
                            top: dataUser ? dataUser.password.length > 0 ? "-20%" : "36%" : "36%",
                            scale: dataUser ? dataUser.password.length > 0 ? "0.9" : "1" : "1",
                            backgroundImage: `linear-gradient(to bottom,  ${dataUser ? dataUser.password.length > 0 ? "#000000" : "#1D1C22" : "#1D1C22"}, #1D1C22)`
                        }}>    {langs == 'vi' ? 'Nhập password' : 'Set passord'}</label>

                        <input style={{ boxSizing: "border-box" }}
                            name="set_password"
                            type="password"

                            onChange={(e: any) => {
                                const newDataUser = { ...dataUser }
                                newDataUser.password = e.target.value;
                                setDataUser(newDataUser)
                            }}
                        />
                    </div>
                    <button style={{ cursor: "pointer" }} onClick={handleLogin} type="submit">
                        {langs == 'vi' ? 'Đăng ký.' : 'Register.'}

                    </button>
                </form>
            </div>
            <Snackbar open={open} autoHideDuration={6000} onClose={handleClose}>
                <Alert onClose={handleClose} severity="error" sx={{ width: '100%' }}>
                    {langs == 'vi' ? 'Các trường không thể để trống.' : 'Fields cannot be left blank.'}

                </Alert>
            </Snackbar>
            <Snackbar open={emailAd} autoHideDuration={6000} onClose={handleCloseemailAd}>
                <Alert onClose={handleCloseemailAd} severity="error" sx={{ width: '100%' }}>
                    {langs == 'vi' ? 'Email đã có người khác đăng ký' : 'Email already exists'}

                </Alert>
            </Snackbar>
            <Snackbar open={nameAd} autoHideDuration={6000} onClose={handleClosenameAd}>
                <Alert onClose={handleCloseemailAd} severity="error" sx={{ width: '100%' }}>
                    {langs == 'vi' ? 'Tên của bạn phải lớn hơn 5 ký tự' : 'Your name must be larger than 5 characters.'}

                </Alert>
            </Snackbar>
            <Snackbar open={passwordAd} autoHideDuration={6000} onClose={handleClosepassAd}>
                <Alert onClose={handleCloseemailAd} severity="error" sx={{ width: '100%' }}>
                    {langs == 'vi' ? 'Mật khẩu phải lớn hơn 8 kí tự.' : 'Your password must be larger than 8 characters.'}

                </Alert>
            </Snackbar>
            <Snackbar open={ETEmail} autoHideDuration={6000} onClose={EnterEmail}>
                <Alert onClose={EnterEmail} severity="error" sx={{ width: '100%' }}>
                    {langs == 'vi' ? 'Nhập vào phải là 1 email.' : 'Enter 1 email.'}

                </Alert>
            </Snackbar>
            <Snackbar open={activeConfirm} autoHideDuration={6000} onClose={EnterConfirm}>
                <Alert onClose={EnterEmail} severity="success" sx={{ width: '100%' }}>
                    {langs == 'vi' ? 'Đăng ký thành công tài khoản.' : 'Success register account.'}
                </Alert>
            </Snackbar>
        </div>
    )
}
export default Login