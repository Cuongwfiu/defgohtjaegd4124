import { List, ListItemButton, ListItemText } from "@mui/material"
import { useRouter } from "next/router"
import React, { useEffect, useState } from "react"
import DoneIcon from '@mui/icons-material/Done';
import UseTranslate from "@/hook/translate";
const Locale: React.FC = () => {
    const router = useRouter()
    const [lang, setLang] = useState<any>('')
    useEffect(() => {
        const langLocal = localStorage.getItem('lang') ? localStorage.getItem('lang') : 'en'
        setLang(langLocal)
        if (typeof window !== 'undefined') {
            if (document) {
                const htmlElement = document.querySelector('html');
                if (htmlElement) {
                    htmlElement.style.backgroundColor = 'black';
                }
            }
        }
        return () => {
            if (typeof window !== 'undefined') {
                if (document) {
                    const htmlElement = document.querySelector('html');
                    if (htmlElement) {
                        htmlElement.style.backgroundColor = 'transparent';
                    }
                }
            }
        };
    }, [])
    const dataLocale = [
        {
            name: "English",
            fullname: "English",
            type: "en",
            icon: "https://www.idg88fx.com/static/flags/4x3/us.svg"
        }, {
            name: "Vietnamese",
            fullname: "Tiếng việt",
            type: "vi",
            icon: "https://www.idg88fx.com/static/flags/4x3/vn.svg"
        }
    ]
    const [langs, setLangs] = useState<any>('')

    useEffect(() => {
        const lang = localStorage.getItem('lang')
        if (lang) {
            setLangs(lang)
        } else {
            setLangs('en')
        }
    }, [])
    return (
        <div className="m_locale">
            <div className="m_profile_header">
                <div>
                    <svg onClick={() => {
                        router.back();
                    }} className="MuiSvgIcon-root MuiSvgIcon-fontSizeMedium css-vubbuv" focusable="false" aria-hidden="true" viewBox="0 0 24 24" data-testid="ArrowBackIcon"><path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z"></path></svg>
                    <UseTranslate
                        data={{
                            Tag: 'h3',
                            className: '',
                            lang: langs
                        }} >
                        Language
                    </UseTranslate>

                </div>
            </div>
            <div className="m_locale_container">
                {dataLocale.map((item: any, index: any) => {
                    return (
                        <ListItemButton onClick={() => {
                            localStorage.setItem('lang', item.type)
                            localStorage.setItem('fullnamelang', item.fullname)
                            localStorage.setItem('iconlang', item.icon)
                            setLang(item.type)
                            window.location.reload()
                        }} className="m_locale_container_item" style={{ display: "flex", justifyContent: "space-between", alignContent: "center" }} key={index}>
                            <div className="m_locale_container_item_left">
                                <img src={item.icon} alt="" />
                                <div>
                                    <span>{item.fullname}</span>
                                    <span>{item.name}</span>
                                </div>
                            </div>
                            <div className="m_locale_container_item_right">
                                {lang == item.type && <DoneIcon style={{ color: "rgb(247, 166, 0)" }} />}

                            </div>
                        </ListItemButton>
                    )
                })}
            </div>
        </div>
    )
}
export default Locale