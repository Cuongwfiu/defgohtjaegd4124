import { API_KEY } from "@/config/api"
import UseTranslate from "@/hook/translate"
import { Alert, Button, Snackbar, TextField } from "@mui/material"
import { styled } from '@mui/system'
import axios from "axios"
import { useRouter } from "next/router"
import React, { useEffect, useState } from "react"
const MyButtonConfirm = styled(Button)(({ theme }) => ({
    backgroundColor: "#F7A600",
    fontSize: "13px",
    fontWeight: 600,
    textTransform: "none",
    padding: "7px 0",
    '&:hover': {
        backgroundColor: '#BF7700',
    },
}));
const LoginPassword: React.FC = () => {
    const router = useRouter()
    const [langs, setLangs] = useState<any>('')
    const [security, setSecurity] = useState<any>('')
    const [helperTexts, setHelperTexts] = useState<any>('')
    const [repass, setRepassword] = useState<any>('')
    const [errInput, setErrInput] = useState<any>(false)
    useEffect(() => {
        const lang = localStorage.getItem('lang')
        if (lang) {
            setLangs(lang)
        } else {
            setLangs('en')
        }


        if (document) {
            const htmlElement = document.querySelector('html');
            if (htmlElement) {
                htmlElement.style.backgroundColor = '#000000';
            }
        }
        return () => {
            if (typeof window !== 'undefined') {
                if (document) {
                    const htmlElement = document.querySelector('html');
                    if (htmlElement) {
                        htmlElement.style.backgroundColor = 'transparent';
                    }
                }
            }
        };
    }, [])
    const handleChangeSecurity = (e: any) => {
        setSecurity(e.target.value)
    }
    const rePassword = (e: any) => {
        setRepassword(e.target.value)
    }

    const saveSecurityCode = async () => {
        const infoUser: any = localStorage.getItem('infoUser')
        if (infoUser) {
            const token = localStorage.getItem('token')
            if (token) {
                const res = await axios.put(`${API_KEY}/re-password`, {
                    token: token,
                    email: JSON.parse(infoUser).email,
                    security: security,
                    repass: repass
                })
                if (res.data.status == 1) {
                    setOpen2(false)
                    setOpen(true)
                    setErrInput(false)
                    setHelperTexts('')
                } else if (res.data.status == 2) {
                    setOpen(false)
                    setOpen2(true)
                }
            }

        }
    }
    const [open, setOpen] = useState<any>(false);
    const handleClose = (event?: React.SyntheticEvent | Event, reason?: string) => {
        setOpen(false);
    };


    const [open2, setOpen2] = useState<any>(false);
    const handleClose2 = (event?: React.SyntheticEvent | Event, reason?: string) => {
        setOpen2(false);
    };
    return (
        <div>
            <div className="m_profile_header">
                <div>
                    <svg onClick={() => {
                        router.back()
                    }} className="MuiSvgIcon-root MuiSvgIcon-fontSizeMedium css-vubbuv" focusable="false" aria-hidden="true" viewBox="0 0 24 24" data-testid="ArrowBackIcon"><path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z"></path></svg>
                    <UseTranslate

                        data={{
                            Tag: 'h3',
                            className: '',
                            lang: langs
                        }} >
                        Re set a security password login
                    </UseTranslate>
                </div>

            </div>
            <div>
                <TextField
                    onChange={handleChangeSecurity}
                    value={security}
                    // error={errInput}
                    InputLabelProps={{
                        style: {
                            color: "white"
                        }
                    }}
                    // helperText={helperTexts}

                    inputProps={{ style: { color: "white" } }}
                    fullWidth style={{ backgroundColor: "#1D1C22", marginTop: 20 }}
                    label={langs=='vi'?"Mật khẩu hiện tại":"Current Password"}
                    variant="outlined" />
                <TextField
                    onChange={rePassword}
                    value={repass}
                    error={errInput}
                    InputLabelProps={{
                        style: {
                            color: "white"
                        }
                    }}
                    helperText={helperTexts}

                    inputProps={{ style: { color: "white" } }}
                    fullWidth style={{ backgroundColor: "#1D1C22", marginTop: 20, marginBottom: 20 }}
                    label={langs=='vi'?"Mật khẩu mới":"New Password"}
                    variant="outlined" />
                <MyButtonConfirm
                    onClick={() => {
                        if (repass.length < 8) {
                            setErrInput(true)
                            setHelperTexts('The New Pass must be greater than 8 characters')
                        } else {

                            saveSecurityCode()

                        }

                    }}
                    style={{
                        color: "black"
                    }} fullWidth >
                    <UseTranslate
                        style={{ color: "black" }}
                        data={{
                            Tag: 'span',
                            className: '',
                            lang: langs
                        }} >
                        Confirm
                    </UseTranslate>
                </MyButtonConfirm>

            </div>
            <Snackbar open={open} autoHideDuration={6000} onClose={handleClose}>
                <Alert onClose={handleClose} severity="success" sx={{ width: '100%' }}>
                    <UseTranslate
                        style={{ color: "#2e7d32" }}
                        data={{
                            Tag: 'span',
                            className: '',
                            lang: langs
                        }} >
                        Re set password successfully
                    </UseTranslate>
                </Alert>
            </Snackbar>
            <Snackbar open={open2} autoHideDuration={6000} onClose={handleClose2}>
                <Alert onClose={handleClose2} severity="error" sx={{ width: '100%' }}>
                    <UseTranslate
                        style={{ color: "#d32f2f" }}
                        data={{
                            Tag: 'span',
                            className: '',
                            lang: langs
                        }} >
                        Incorrect password
                    </UseTranslate>

                </Alert>
            </Snackbar>
        </div>
    )
}
export default LoginPassword