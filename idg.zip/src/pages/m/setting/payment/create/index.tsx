import { API_KEY } from "@/config/api"
import axios from "axios"
import { useRouter } from "next/router"
import React, { useEffect, useState } from "react"
import { Alert, FormControl, InputLabel, MenuItem, Select, Snackbar, TextField } from "@mui/material"
import SwipeableDrawer from "@mui/material/SwipeableDrawer"
import CreatePayment from "@/components/createPayment"
import UseTranslate from "@/hook/translate"


const Profile: React.FC = (props) => {

    const router = useRouter()

    const [infoUS, setInfoUS] = useState<any>(null)
    const [langs, setLangs] = useState<any>('')
    useEffect(() => {
        const infoUser: any = localStorage.getItem('infoUser');
        if (infoUser) {
            setInfoUS(JSON.parse(infoUser))
        } else {
            router.push('/m/home')
        }
        const lang = localStorage.getItem('lang')
        if (lang) {
            setLangs(lang)
        } else {
            setLangs('en')
        }
    }, [router])
    // logic ----------------------------------
    const [validat, setValidat] = useState(false);
    const handleCloseVali = () => { setValidat(false) }
    const [isDrawerOpen, setIsDrawerOpen] = useState(false);
    const [lang, setLang] = useState<any>('');
    const [typeBank, setTypeBank] = useState<any>('')
    useEffect(()=>{
        const lans =langs=='vi'?'Tiền tệ pháp định':"Fiat Currency"
        setTypeBank(lans)
    },[langs])
    // Tên quốc gia
    const [bankIns, setBankIns] = useState<any>('');
    // Ngân hàng
    const [BankAcc, setBankAcc] = useState<any>('');
    // Số tài khoản 
    const [realName, setRealname] = useState<any>('');
    // Tên thực tế
    const [contactAdd, setContactAdd] = useState<any>('');
    // Địa chỉ liên hệ
    const [contactPhone, setContactPhone] = useState<any>('');
    // Số liên lạc
    const [idnumber, setIDNumber] = useState<any>('');
    // Thẻ ID
    const [reMark, setRemark] = useState<any>('');
    const addCard = async () => {
        const infoUser: any = localStorage.getItem('infoUser');
        if (infoUser) {
            if (BankAcc.length == 0 || lang.length == 0 || bankIns.length == 0 || realName.length == 0 || contactAdd.length == 0 || contactPhone.length == 0 || idnumber.length == 0) {
                setValidat(true)
            } else {
                console.log(infoUser);
                const obj = {
                    data: {
                        BankAcc,
                        lang,
                        bankIns,
                        realName,
                        contactAdd,
                        contactPhone,
                        idnumber,
                        reMark,
                    },
                    email: JSON.parse(infoUser).email


                }

                const data = await axios.post(`${API_KEY}/add-to-card`, obj)
                if (data.data.status == 'success') {
                    router.push('/m/setting/payment')
                }
            }
        }


    }
    const toggleDrawer = (open: any) => (event: any) => {
        if (
            event &&
            event.type === 'keydown' &&
            (event.key === 'Tab' || event.key === 'Shift')
        ) {
            return;
        }

        setIsDrawerOpen(open);
    };
    
    return (
        <div className="m_setting">
            <div className="m_profile_header">
                <div>
                    <svg onClick={() => {
                        router.back()
                    }} className="MuiSvgIcon-root MuiSvgIcon-fontSizeMedium css-vubbuv" focusable="false" aria-hidden="true" viewBox="0 0 24 24" data-testid="ArrowBackIcon"><path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z"></path></svg>
                    <UseTranslate
                        data={{
                            Tag: 'h3',
                            className: '',
                            lang: langs
                        }} >
                        Add withdrawal account
                    </UseTranslate>

                </div>
            </div>
            <div className="create-card">
                <img src="https://www.idg88fx.com/_next/static/media/type.741010db.svg" alt="" />

            </div>
            <FormControl className="mr" style={{ color: "white" }} fullWidth>
                <InputLabel style={{ color: "#ffffff79" }} htmlFor="type">Type</InputLabel>
                <Select

                    id="outlined-disabled"

                    style={{ background: "#1D1C22", color: "white" }}
                    labelId="type"
                    value={typeBank}
                    label="Type"
                >
                    <MenuItem onClick={() => {
                        if (langs == 'vi') {
                            setTypeBank('Tiền tệ pháp định')
                        } else {
                            setTypeBank('Fiat Currency')
                        }           
                    }} value={langs=='vi'?'Tiền tệ pháp định':"Fiat Currency"}>{langs=='vi'?'Tiền tệ pháp định':"Fiat Currency"}</MenuItem>
                    {/* <MenuItem onClick={() => {
                        setTypeBank('Cryptocurrency')
                    }} value="Cryptocurrency">Cryptocurrency</MenuItem> */}
                </Select>
            </FormControl>
            <TextField
                onClick={() => {
                    setIsDrawerOpen(true)
                }}
                value={lang}
                className="mr fw"
                label={
                    <span style={{ color: '#ffffff79' }}>{langs=='vi'?'Khu vực':"Country"}</span>
                }
                placeholder={langs=='vi'?'Tìm kiếm khu vực':"Search country or region"}
                InputProps={{
                    style: { backgroundColor: '#1D1C22', color: "white" },
                }}
            />
            <TextField
                onChange={(e) => {
                    setBankIns(e.target.value)
                }}
                className="mr fw"
                label={
                    <span style={{ color: '#ffffff79' }}>{langs=='vi'?'Tổ chức ngân hàng':"Bank Institution"}</span>
                }
                placeholder={langs=='vi'?'Nhập vào tên ngân hàng':"Enter the bank institution of the account"}
                InputProps={{
                    style: { backgroundColor: '#1D1C22', color: "white" },
                }}
            />
            <TextField
                className="mr fw"
                onChange={(e) => {
                    setBankAcc(e.target.value)
                }}
                label={
                    <span style={{ color: '#ffffff79' }}>{langs=='vi'?'Tài khoản ngân hàng':"Bank Account"}</span>
                }
                placeholder={langs=='vi'?'Nhập vào số tài khoản':"Enter bank account"}
                InputProps={{
                    style: { backgroundColor: '#1D1C22', color: "white" },
                }}
            />

            <TextField
                className="mr fw"
                onChange={(e) => {
                    setRealname(e.target.value)
                }}
                label={
                    <span style={{ color: '#ffffff79' }}>{langs=='vi'?'Tên của bạn':"Real Name"}</span>
                }
                placeholder={langs=='vi'?'Tên của bạn trên thẻ ngân hàng':"Real name of the account holder"}
                InputProps={{
                    style: { backgroundColor: '#1D1C22', color: "white" },
                }}
            />

            <TextField
                className="mr fw"
                onChange={(e) => {
                    setContactAdd(e.target.value)
                }}
                label={
                    <span style={{ color: '#ffffff79' }}>{langs=='vi'?'Địa chỉ của bạn':"Contact Address"}</span>
                }
                placeholder={langs=='vi'?'Nhập vào chi tiết địa chỉ của bạn':"Detailed contact address"}
                InputProps={{
                    style: { backgroundColor: '#1D1C22', color: "white" },
                }}
            />
            <TextField
                className="mr fw"
                onChange={(e) => {
                    setContactPhone(e.target.value)
                }}
                label={
                    <span style={{ color: '#ffffff79' }}>{langs=='vi'?'Số điện thoại liên hệ':"Contact Phone"}</span>
                }
                placeholder={langs=='vi'?'Nhập vào số điện thoại liên hệ của bạn':"Enter contact your phone"}
                InputProps={{
                    style: { backgroundColor: '#1D1C22', color: "white" },
                }}
            />
            <TextField
                className="mr fw"
                onChange={(e) => {
                    setIDNumber(e.target.value)
                }}
                label={
                    <span style={{ color: '#ffffff79' }}>{langs=='vi'?'Số ID':"ID Number"}</span>
                }
                placeholder={langs=='vi'?'Số ID trên thẻ':"ID Number Card"}
                InputProps={{
                    style: { backgroundColor: '#1D1C22', color: "white" },
                }}
            />
            <TextField
                className="mr fw"
                onChange={(e) => {
                    setRemark(e.target.value)
                }}
                label={
                    <span style={{ color: '#ffffff79' }}>{langs=='vi'?'Ghi chú (Không bắt buộc)':"Remark(Optional)"}</span>
                }
                placeholder={langs=='vi'?'Thêm ghi chú (Không bắt buộc)':"Add remark(Optional)"}
                InputProps={{
                    style: { backgroundColor: '#1D1C22', color: "white" },
                }}
            />
            {/* khong lien quan nua lat lam lai */}
            <SwipeableDrawer
                anchor={'right'}
                open={isDrawerOpen}
                onClose={toggleDrawer(false)}
                onOpen={toggleDrawer(true)}

            >
                <div style={{ width: `${typeof window !== 'undefined' && window?.innerWidth}px` }}>
                    <CreatePayment onClose={() => {
                        setIsDrawerOpen(false)
                    }} onGetData={(type: any, typeName: any, nameLang: any) => {
                        setLang(nameLang)
                        // function deleteCookie(name: any) {
                        //     document.cookie = name + '=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';
                        // }
                        // if (type == 'en') {
                        //     deleteCookie('lang');
                        // } else {
                        //     document.cookie = `lang = ${type}`
                        // }


                        setIsDrawerOpen(false)
                    }} />

                </div>
            </SwipeableDrawer>
            <div className="add-card" onClick={() => {
                router.push('/m/setting/payment/create')
            }}><button onClick={addCard} >{langs=='vi'?'Xác nhận':"Confirm"}</button></div>
            <Snackbar open={validat} autoHideDuration={6000} onClose={handleCloseVali}>
                <Alert onClose={handleCloseVali} severity="error" sx={{ width: '100%' }}>
                {langs=='vi'?'Hãy nhập đủ nhé !':"Please enter enough !"} 
                </Alert>
            </Snackbar>
        </div>
    )

}



export default Profile