import { API_KEY } from "@/config/api"
import UseTranslate from "@/hook/translate"
import axios from "axios"
import { useRouter } from "next/router"
import React, { useEffect, useState } from "react"


const Profile: React.FC = (props) => {
    const router = useRouter()
    const [langs, setLangs] = useState<any>('')
    const [infoUS, setInfoUS] = useState<any>(null)
    const [dataBanking, setDataBanking] = useState<any>(null)
    const [showBanks, setShowBanks] = useState<any>('')
    useEffect(() => {
        const infoUser: any = localStorage.getItem('infoUser');
        if (infoUser) {
            setInfoUS(JSON.parse(infoUser))
            axios.get(`${API_KEY}/active-card/${JSON.parse(infoUser).email}`).then((res: any) => {
                if (res.data.status == 'success') {
                    if (res.data.bankData.length > 0) {
                        setDataBanking(res.data.bankData[0])
                        setShowBanks('show')
                    } else {
                        setShowBanks('hide')
                    }

                } else {

                }
            })
        } else {
            router.push('/m/home')
        }
        const lang = localStorage.getItem('lang')
        if (lang) {
            setLangs(lang)
        } else {
            setLangs('en')
        }
    }, [router])
    function hidePhone(str: any) {
        const atIndex = str.length - 1
        const lastIndex = 4
        const sliceEmail = str.slice(lastIndex, atIndex)
        const lent = sliceEmail.length
        let strLast = ''
        for (let i = 0; i < lent; i++) {
            strLast += '*'
        }
        const relaceEmail = str.replace(sliceEmail, strLast)
        return relaceEmail;
    }
    function hideAccBank(str: any) {
        const atIndex = str.length - 2
        const lastIndex = 3
        const sliceEmail = str.slice(lastIndex, atIndex)
        const lent = sliceEmail.length
        let strLast = ''
        for (let i = 0; i < lent; i++) {
            strLast += '*'
        }
        const relaceEmail = str.replace(sliceEmail, strLast)
        return relaceEmail;
    }
    return (
        <div className="m_setting">
            <div className="m_profile_header">
                <div>
                    <svg onClick={() => {
                        router.back()
                    }} className="MuiSvgIcon-root MuiSvgIcon-fontSizeMedium css-vubbuv" focusable="false" aria-hidden="true" viewBox="0 0 24 24" data-testid="ArrowBackIcon"><path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z"></path></svg>
                    <UseTranslate
                        data={{
                            Tag: 'h3',
                            className: '',
                            lang: langs
                        }} >
                        Withdrawal account
                    </UseTranslate>
                </div>
            </div>


            {showBanks == 'show' ?
                dataBanking && <div className="had-card">
                    <img src="https://www.idg88fx.com/_next/static/media/atm.8f0fc2f1.svg" alt="" />
                    <div className="had-card_content">
                        <div className="had-card_content_header">
                            <span>
                                <div className="had-card_content_header_line"></div>
                                <svg className="w-8 h-8 fill-primary-main" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg"><path d="M25.12,6H6.88A3.89,3.89,0,0,0,3,9.89V21.11A3.89,3.89,0,0,0,6.88,25H25.12A3.89,3.89,0,0,0,29,21.11V9.89A3.89,3.89,0,0,0,25.12,6ZM6.88,8H25.12A1.89,1.89,0,0,1,27,9.89V11H5V9.89A1.89,1.89,0,0,1,6.88,8ZM25.12,23H6.88A1.89,1.89,0,0,1,5,21.11V13H27v8.11A1.89,1.89,0,0,1,25.12,23Z"></path><path d="M24,19H19a1,1,0,0,0,0,2h5a1,1,0,0,0,0-2Z"></path></svg>
                                <p>{dataBanking ? dataBanking.bankIns : ''}</p> <div className="had-card_content_header_ver">Verified</div>
                            </span>
                        </div>
                        <div className="had-card_content_container">
                            <p>{dataBanking ? hideAccBank(dataBanking.BankAcc) : ''}</p>
                            <span>{dataBanking ? dataBanking.lang : ''}</span>
                            <span>{dataBanking ? dataBanking.bankIns : ''}</span>
                            <span>{dataBanking ? dataBanking.realName : ''}</span>
                            <span>{dataBanking ? dataBanking.contactAdd : ''}</span>
                            <span>{dataBanking ? hidePhone(dataBanking.contactPhone) : ''}</span>
                            <span>{dataBanking ? dataBanking.idnumber : ''}</span>
                        </div>
                    </div>
                </div>
                :
                showBanks == 'hide' ? <>
                    <div className="no-card">
                        <img style={{ width: "300px" }} src="https://www.idg88fx.com/_next/static/media/empty.dc408d65.svg" alt="" />
                        <UseTranslate
                            data={{
                                Tag: 'h2',
                                className: '',
                                lang: langs
                            }} >
                            No withdrawal account set
                        </UseTranslate>

                    </div>
                    <div className="add-card" onClick={() => {
                        router.push('/m/setting/payment/create')
                    }}>
                            <UseTranslate
                            data={{
                                Tag: 'button',
                                className: '',
                                lang: langs
                            }} >
                           Add withdrawal account
                        </UseTranslate>
                    </div>
                </>
                    : null



            }


            <div className="m_setting_bg"></div>
        </div>
    )

}

export async function getServerSideProps() {


    return {
        props: {

        }
    }
}


export default Profile