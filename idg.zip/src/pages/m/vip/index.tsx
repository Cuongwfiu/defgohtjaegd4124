import { API_KEY } from "@/config/api"
import UseTranslate from "@/hook/translate"
import axios from "axios"
import { useRouter } from "next/router"
import React, { useEffect, useState } from "react"
const Vip: React.FC = () => {
    const router = useRouter()
    const [langs, setLangs] = useState<any>('')
    const [vip, setVip] = useState<any>('')
    useEffect(() => {
        const lang = localStorage.getItem('lang')
        const fullnamelang = localStorage.getItem('fullnamelang')
        if (lang) {
            setLangs(lang)
        } else {
            setLangs('en')
        }

        const infoUser: any = localStorage.getItem('infoUser')
        if (infoUser) {
            const token = localStorage.getItem('token')
            if (token) {
                const infoUserFunc = async () => {
                    const res = await axios.get(`${API_KEY}/info-user/${JSON.parse(infoUser).email}`, {
                        headers: {
                            Authorization: token
                        }
                    })
                    const data = res.data
                    setVip(data.vip);
                }
                infoUserFunc()
            }


        }

        if (document) {
            const htmlElement = document.querySelector('html');
            if (htmlElement) {
                htmlElement.style.backgroundColor = '#000000';
            }
        }
        return () => {
            if (typeof window !== 'undefined') {
                if (document) {
                    const htmlElement = document.querySelector('html');
                    if (htmlElement) {
                        htmlElement.style.backgroundColor = 'transparent';
                    }
                }
            }
        };
    }, [])
    return (
        <div>
            <div className="m_profile_header">
                <div>
                    <svg onClick={() => {
                        router.back()
                    }} className="MuiSvgIcon-root MuiSvgIcon-fontSizeMedium css-vubbuv" focusable="false" aria-hidden="true" viewBox="0 0 24 24" data-testid="ArrowBackIcon"><path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z"></path></svg>
                    <UseTranslate

                        data={{
                            Tag: 'h3',
                            className: '',
                            lang: langs
                        }} >
                        Member Privilege Plan
                    </UseTranslate>
                </div>
            </div>
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", marginTop: 50, padding: "0 10px", boxSizing: "border-box" }}>
                <div style={{ display: "flex", flexDirection: "column", alignItems: "center" }}><img style={{ width: "60%" }} src="https://www.idg88fx.com/_next/image?url=%2F_next%2Fstatic%2Fmedia%2Fvip.bb24be97.png&w=750&q=75" alt="" /></div>
                <UseTranslate

                    data={{
                        Tag: 'h2',
                        className: '',
                        lang: langs
                    }} >
                    Upgrade my member level
                </UseTranslate>
                <UseTranslate
                    style={{ color: "rgba(255, 255, 255, 0.377)" }}
                    data={{
                        Tag: 'span',
                        className: '',
                        lang: langs
                    }} >
                    We tailor different membership levels according to different users. You can upgrade your membership level by completing the task and enjoy more privileges. For details, click the button below for consultation.
                </UseTranslate>
                <div onClick={() => {
                    router.push('/m/chat')
                }} className="buttonVip">

                    <div> <UseTranslate
                        data={{
                            Tag: 'span',
                            className: '',
                            lang: langs
                        }} >
                        Current level:
                    </UseTranslate><h2>{vip.length > 0 ? `Vip ${vip}` : <UseTranslate
                        data={{
                            Tag: 'span',
                            className: '',
                            lang: langs
                        }} >
                        You are not yet a member
                    </UseTranslate>}</h2></div>
                    <UseTranslate
                        data={{
                            Tag: 'button',
                            className: '',
                            lang: langs
                        }} >
               Contact customer service consultation
                    </UseTranslate>
                </div>
            </div>
        </div>
    )
}
export default Vip