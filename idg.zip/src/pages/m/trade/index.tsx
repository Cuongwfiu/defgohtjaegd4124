import { API_KEY } from "@/config/api"
import React, { useEffect, useRef, useState } from "react"
import { createChart } from "lightweight-charts"
import { socket } from "@/hook/socketIO"
import { useRouter } from "next/router"
import axios from "axios"
import SliderRange from "@/components/sliderRange"
import { InputAdornment, TextField } from "@mui/material"
import UseTranslate from "@/hook/translate"
import { userLogin } from "@/hook/useLogin"

type Props = {

}
const Trade: React.FC<Props> = (props) => {
    const formatCoin = (number: any) => {
        const formattedNumber = number.toLocaleString('en-US', {
            style: 'decimal',
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
        });
        return formattedNumber;
    }

    const router = useRouter()
    const [stopCall, setStopCall] = useState<any>(false)
    const [coinTrade, setCoinTrade] = useState<any>('');
    const [newNumber, setNewNumber] = useState<any>('');
    const [color, setColor] = useState<any>('');
    const [nameTrade, setNameTrade] = useState<any>('');
    // test user login
    const [stopTestUser, setStopTestUser] = useState<any>(false);
    useEffect(() => {
        async function runTestUser() {
            await userLogin(router)
        }
        if (!stopTestUser) {
            runTestUser()
            setStopTestUser(true)
        }
    }, [stopTestUser])
    // test user login
    useEffect(() => {
        const coin = Number(coinTrade);
        setNewNumber(coin);
        if (newNumber > coin) {
            setColor('#DD5350');
        } else {
            setColor('#55AF72');
        }
    }, [coinTrade]);
    const [balance, setBalance] = useState<any>('')
    const [dataCart, setDataCart] = useState<any>([])

    const arrProfit = [
        {
            num: 190,
            minu: "1 Minute",
            minute: 1
        }, {
            num: 170,
            minu: "2 Minute",
            minute: 2
        }, {
            num: 150,
            minu: "3 Minute",
            minute: 3
        }
    ]
    const arrProfitBTC = [
        {
            num: 15,
            minu: "1 Minute",
            minute: 1
        }, {
            num: 25,
            minu: "2 Minute",
            minute: 2
        }, {
            num: 35,
            minu: "3 Minute",
            minute: 3
        }, {
            num: 45,
            minu: "4 Minute",
            minute: 4
        }
    ]
    const [numInCre, setNumInCre] = useState<any>(190)
    const [minute, setMinute] = useState<any>(1)
    useEffect(() => {
        const namePopular = localStorage.getItem('nameCoin') ? localStorage.getItem('nameCoin') : 'BTC'
        if (namePopular === 'BTC') {
            setNumInCre(15)
        } else {
            setNumInCre(190)
        }
        const infoUser: any = localStorage.getItem('infoUser');
        if (infoUser) {
            const token = localStorage.getItem('token')
            if (!token) {
                localStorage.removeItem('infoUser')
                window.location.reload()
            }
            socket.emit('coin-user', { email: JSON.parse(infoUser).email, token })

            socket.emit('cart-user', { email: JSON.parse(infoUser).email })
        } else {
            router.push('/m/login')
        }


        setNameTrade(namePopular)
        let interval: any
        if (stopCall) {
            interval = setInterval(() => {
                axios.get(`${API_KEY}/api-trade/${namePopular ? namePopular : 'BTC'}`).then(item => {
                    setCoinTrade(item.data.coinTrade)
                })
            }, 4000)
        } else {
            axios.get(`${API_KEY}/api-trade/${namePopular ? namePopular : 'BTC'}`).then(item => {
                setCoinTrade(item.data.coinTrade)
                setStopCall(true)
            })
        }

    }, [stopCall, router])


    const [crypto, setCrypto] = useState<any>([])
    const [optionChart, setOptionChart] = useState<any>('Chart')
    const canvasChart = useRef<any>(null)
    const [time, setTime] = useState<any>({ time: '15m', intervalTime: 15 })
    const [stopRenderChart, setStopRenderChart] = useState<any>(false)
    const [chartSet, setchartSet] = useState<any>(false)
    // Create table=------------------------
    useEffect(() => {
        if (canvasChart.current) {
            if (stopRenderChart) {
                chartSet.setData(crypto)
            } else {
                canvasChart.current.innerHTML = ''
                const chart = createChart(canvasChart.current, {
                    height: window.innerWidth > 550 ? 600 : 450,
                    layout: {
                        background: { color: "black" },
                        textColor: "#fff",
                    },
                    grid: {
                        vertLines: {
                            color: 'rgba(255, 255, 255, 0.1)' // Màu cho các đường dọc
                        },
                        horzLines: {
                            color: 'rgba(255, 255, 255, 0.1)' // Màu cho các đường ngang
                        }
                    },
                    timeScale: {
                        timeVisible: true,
                        secondsVisible: false
                    }
                });
                const candleChart = chart.addCandlestickSeries();
                setchartSet(candleChart)
                candleChart.setData(crypto);
                setStopRenderChart(true)
            }

        } else {
            console.log('loading chart');
        }
    }, [canvasChart, stopRenderChart, crypto]);
    // Create table -------------------------------
    useEffect(() => {

        if (nameTrade.length > 0) {
            socket.emit('crypto', { ...time, nameTrade: nameTrade })
        }

    }, [nameTrade])

    socket.on('data-crypto', (data: any) => {
        const formatData = data && data.map((item: any, index: any) => {
            return {
                time: item[0] / 100, open: parseFloat(item[1]), high: parseFloat(item[2]), low: parseFloat(item[3]), close: parseFloat(item[4])
            }
        })
        setCrypto(formatData)
    })
    const [randomNumber, setRandomNumber] = useState({
        num1: 0,
        num2: 0,
        num3: 0,
        num4: 0,
        num5: 0,
        num6: 0,
        num7: 0,
        num8: 0,
        num9: 0,
        num10: 0,
        num11: 0,
        num12: 0,
        num13: 0,
        num14: 0,
    });
    const [initialCart, setInitialCart] = useState<any>(false)
    useEffect(() => {
        socket.on('send-coin', res => {
            setBalance(res.coin);
        })
        // socket.on('send-cart', res => {
        //     setDataCart(res.data);
        // })

        const getCart = async () => {
            const infoUser: any = localStorage.getItem('infoUser');
            if (infoUser) {
                const res = await axios.get(`${API_KEY}/get-cart/${JSON.parse(infoUser).email}`)
                setDataCart(res.data);
            }
        }
        if (!initialCart) {
            getCart()
            setInitialCart(true)
        }
        const intervalCart = setInterval(() => {
            getCart()
        }, 2000)
        return () => {
            clearInterval(intervalCart)
        }
    }, [initialCart])
    useEffect(() => {
        if (typeof window !== 'undefined') {
            if (document) {
                const htmlElement = document.querySelector('html');
                if (htmlElement) {
                    htmlElement.style.backgroundColor = '#000000';
                }
            }
        }

        const min = 10;
        const max = 100;
        const initilrandomNumbers = Array.from({ length: 14 }, () => generateRandomNumber(min, max));
        setRandomNumber((prevState) => {
            return {
                ...prevState,
                num1: initilrandomNumbers[0],
                num2: initilrandomNumbers[1],
                num3: initilrandomNumbers[2],
                num4: initilrandomNumbers[3],
                num5: initilrandomNumbers[4],
                num6: initilrandomNumbers[5],
                num7: initilrandomNumbers[6],
                num8: initilrandomNumbers[7],
                num9: initilrandomNumbers[8],
                num10: initilrandomNumbers[9],
                num11: initilrandomNumbers[10],
                num12: initilrandomNumbers[11],
                num13: initilrandomNumbers[12],
                num14: initilrandomNumbers[13],

            }
        })
        const intervalId = setInterval(() => {
            const newRandomNumbers = Array.from({ length: 14 }, () => generateRandomNumber(min, max));
            setRandomNumber((prevState) => {
                return {
                    ...prevState,
                    num1: newRandomNumbers[0],
                    num2: newRandomNumbers[1],
                    num3: newRandomNumbers[2],
                    num4: newRandomNumbers[3],
                    num5: newRandomNumbers[4],
                    num6: newRandomNumbers[5],
                    num7: newRandomNumbers[6],
                    num8: newRandomNumbers[7],
                    num9: newRandomNumbers[8],
                    num10: newRandomNumbers[9],
                    num11: newRandomNumbers[10],
                    num12: newRandomNumbers[11],
                    num13: newRandomNumbers[12],
                    num14: newRandomNumbers[13],

                }
            })
        }, 1000);

        return () => {
            clearInterval(intervalId);
            if (typeof window !== 'undefined') {
                if (document) {
                    const htmlElement = document.querySelector('html');
                    if (htmlElement) {
                        htmlElement.style.backgroundColor = 'transparent';
                    }
                }
            }
        };

    }, []);






    const [randomQuatity, setRandomQuatity] = useState({
        num1: 0,
        num2: 0,
        num3: 0,
        num4: 0,
        num5: 0,
        num6: 0,
        num7: 0,
        num8: 0,
        num9: 0,
        num10: 0,
        num11: 0,
        num12: 0,
        num13: 0,
        num14: 0,
    });
    const [langs, setLangs] = useState<any>('')
    useEffect(() => {
        const lang = localStorage.getItem('lang')
        if (lang) {
            setLangs(lang)
        } else {
            setLangs('en')
        }
        const min = 6;
        const max = 1335;
        const initilrandomNumbers = Array.from({ length: 14 }, () => generateRandomNumber(min, max));
        setRandomQuatity((prevState) => {
            return {
                ...prevState,
                num1: initilrandomNumbers[0],
                num2: initilrandomNumbers[1],
                num3: initilrandomNumbers[2],
                num4: initilrandomNumbers[3],
                num5: initilrandomNumbers[4],
                num6: initilrandomNumbers[5],
                num7: initilrandomNumbers[6],
                num8: initilrandomNumbers[7],
                num9: initilrandomNumbers[8],
                num10: initilrandomNumbers[9],
                num11: initilrandomNumbers[10],
                num12: initilrandomNumbers[11],
                num13: initilrandomNumbers[12],
                num14: initilrandomNumbers[13],

            }
        })
        const intervalId = setInterval(() => {
            const newRandomNumbers = Array.from({ length: 14 }, () => generateRandomNumber(min, max));
            setRandomQuatity((prevState) => {
                return {
                    ...prevState,
                    num1: newRandomNumbers[0],
                    num2: newRandomNumbers[1],
                    num3: newRandomNumbers[2],
                    num4: newRandomNumbers[3],
                    num5: newRandomNumbers[4],
                    num6: newRandomNumbers[5],
                    num7: newRandomNumbers[6],
                    num8: newRandomNumbers[7],
                    num9: newRandomNumbers[8],
                    num10: newRandomNumbers[9],
                    num11: newRandomNumbers[10],
                    num12: newRandomNumbers[11],
                    num13: newRandomNumbers[12],
                    num14: newRandomNumbers[13],

                }
            })
        }, 1000);

        return () => {
            clearInterval(intervalId);
        };
    }, []);

    function generateRandomNumber(min: any, max: any) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }
    // ran dom number generator


    // -=--------trade----------------------
    const [indexTrade, setIndexTrade] = useState<any>(0)

    const [valueInputCoin, setValueInputCoin] = useState<any>(0)
    const [step, setStep] = useState<number>(0);
    const handleChange = (e: any) => {
        let newValue = e.target.value.replace(/[^0-9]/g, '');
        function customRound(input: any) {
            if (input <= 2.5) {
                return 0;
            }
            const roundedValue = Math.floor((input - 2.5) / 5) * 5 + 5;
            return roundedValue > 100 ? 100 : roundedValue;
        }
        if (newValue <= Number(balance)) {
            const totalCoins = (Number(newValue) / Number(balance)) * 100
            setStep(customRound(totalCoins))
            if (e.target.value.length == 0) {
                setValueInputCoin(0);
            } else {
                setValueInputCoin(parseFloat(newValue));
            }

        }

    };

    const num1 = randomQuatity.num10 > randomQuatity.num1 ? randomQuatity.num10 - randomQuatity.num1 : randomQuatity.num10
    const num2 = randomQuatity.num11 > randomQuatity.num1 ? randomQuatity.num11 - randomQuatity.num1 : randomQuatity.num9
    const num3 = randomQuatity.num12 > randomQuatity.num1 ? randomQuatity.num12 - randomQuatity.num1 : randomQuatity.num8
    const num4 = randomQuatity.num13 > randomQuatity.num1 ? randomQuatity.num13 - randomQuatity.num1 : randomQuatity.num14
    const num5 = randomQuatity.num14 > randomQuatity.num1 ? randomQuatity.num14 - randomQuatity.num1 : randomQuatity.num7
    const num6 = randomQuatity.num9 > randomQuatity.num1 ? randomQuatity.num9 - randomQuatity.num1 : randomQuatity.num13
    const num7 = randomQuatity.num8 > randomQuatity.num1 ? randomQuatity.num8 - randomQuatity.num1 : randomQuatity.num12
    const num8 = randomQuatity.num7 > randomQuatity.num4 ? randomQuatity.num7 - randomQuatity.num4 : randomQuatity.num11
    const num9 = randomQuatity.num6 > randomQuatity.num1 ? randomQuatity.num6 - randomQuatity.num1 : randomQuatity.num6
    const num10 = randomQuatity.num5 > randomQuatity.num1 ? randomQuatity.num5 - randomQuatity.num1 : randomQuatity.num1
    const num11 = randomQuatity.num4 > randomQuatity.num3 ? randomQuatity.num4 - randomQuatity.num3 : randomQuatity.num5
    const num12 = randomQuatity.num3 > randomQuatity.num1 ? randomQuatity.num3 - randomQuatity.num1 : randomQuatity.num2
    const num13 = randomQuatity.num2 > randomQuatity.num1 ? randomQuatity.num2 - randomQuatity.num1 : randomQuatity.num4
    const num14 = randomQuatity.num1 > randomQuatity.num2 ? randomQuatity.num1 - randomQuatity.num2 : randomQuatity.num3
    const priceOrder = Number(Number(coinTrade) + 0.14).toFixed(2)


    return (
        <div className="m_trade">
            <div className="m_trade_header">

                <div>
                    <UseTranslate
                        style={{ color: optionChart === 'Chart' ? '#F7A600' : '#757575' }}
                        onPress={() => {
                            setStopRenderChart(false)
                            setOptionChart('Chart')
                        }}
                        data={{
                            Tag: 'span',
                            className: '',
                            lang: langs
                        }} >
                        Chart

                    </UseTranslate>
                    <div style={{ backgroundColor: optionChart === 'Chart' ? '#F7A600' : 'transparent' }}>
                    </div>
                </div>
                {/* useTrande */}
                <div>
                    <UseTranslate
                        style={{ color: optionChart === 'Trade' ? '#F7A600' : '#757575' }}
                        onPress={() => {
                            setOptionChart('Trade')
                        }}
                        data={{
                            Tag: 'span',
                            className: '',
                            lang: langs
                        }} >
                        Trade

                    </UseTranslate>
                    <div style={{ backgroundColor: optionChart === 'Trade' ? '#F7A600' : 'transparent' }}>
                    </div>
                </div>
            </div>
            {optionChart && optionChart == 'Chart' ? <div className="m_trade_container">
                <div className="m_trade_container_nametrade">
                    {nameTrade} / USDT <span>+0.45%</span>
                </div>
                <div className="m_trade_container_coin">
                    <span style={{ color: color }}>{coinTrade}</span>
                    <span>≈{coinTrade} USD</span>
                </div>
                <div className="canvas-trade" >
                    <div ref={canvasChart} >

                    </div>
                </div>
                <div className="m_trade_container_button">
                    <UseTranslate
                        onPress={() => {
                            setOptionChart('Trade')
                        }}
                        data={{
                            Tag: 'button',
                            className: '',
                            lang: langs
                        }} >
                        {langs == 'vi' ? 'Mua lên' : 'Long'}
                    </UseTranslate>
                    <UseTranslate
                        onPress={() => {
                            setOptionChart('Trade')
                        }}
                        data={{
                            Tag: 'button',
                            className: '',
                            lang: langs
                        }} >
                        {langs == 'vi' ? 'Mua xuống' : 'Short'}
                    </UseTranslate>

                </div>
            </div> :
                <div className="m_trade_container_trade">
                    <div className="m_trade_container_trade_header">
                        {nameTrade} / USDT <span>+0.45%</span>
                    </div>
                    <div className="m_trade_container_trade_content">
                        <div className="m_trade_container_trade_content_left">
                            <div className="option_scroll">
                                <div className="m_trade_container_trade_content_left_option">
                                    {
                                        typeof window !== 'undefined'
                                            && localStorage.getItem('nameCoin') ?
                                            localStorage.getItem('nameCoin') === 'BTC' ? arrProfitBTC.map((item: any, index: any) => {
                                                return (
                                                    <div onClick={() => {
                                                        setIndexTrade(index)
                                                        setNumInCre(item.num)
                                                        setMinute(item.minute)
                                                    }} style={{ border: `1px solid ${indexTrade === index ? '#F2A301' : 'transparent'}` }}>
                                                        <UseTranslate
                                                            onPress={() => {
                                                                setOptionChart('Trade')
                                                            }}
                                                            data={{
                                                                Tag: 'span',
                                                                className: '',
                                                                lang: langs
                                                            }}
                                                            style={{whiteSpace: 'nowrap'}}
                                                            >
                                                            Profit
                                                        </UseTranslate>
                                                        <UseTranslate
                                                        style={{whiteSpace: 'nowrap'}}
                                                            onPress={() => {
                                                                setOptionChart('Trade')
                                                            }}
                                                            data={{
                                                                Tag: 'span',
                                                                className: '',
                                                                lang: langs
                                                            }} >
                                                            {item.num}%
                                                        </UseTranslate>
                                                        <UseTranslate
                                                 style={{whiteSpace: 'nowrap',width: '100%',padding:0,textAlign: 'center'}}
                                                            onPress={() => {
                                                                setOptionChart('Trade')
                                                            }}
                                                            data={{
                                                                Tag: 'span',
                                                                className: '',
                                                                lang: langs
                                                            }} >
                                                            {item.minu}
                                                        </UseTranslate>
                                                    </div>
                                                )
                                            }) : arrProfit.map((item: any, index: any) => {
                                                return (
                                                    <div onClick={() => {
                                                        setIndexTrade(index)
                                                        setNumInCre(item.num)
                                                        setMinute(item.minute)
                                                    }} style={{ border: `1px solid ${indexTrade === index ? '#F2A301' : 'transparent'}` }}>
                                                        <UseTranslate
                                                        style={{whiteSpace: 'nowrap'}}
                                                            onPress={() => {
                                                                setOptionChart('Trade')
                                                            }}
                                                            data={{
                                                                Tag: 'span',
                                                                className: '',
                                                                lang: langs
                                                            }} >
                                                            Profit
                                                        </UseTranslate>
                                                        <UseTranslate
                                                        style={{whiteSpace: 'nowrap'}}
                                                            onPress={() => {
                                                                setOptionChart('Trade')
                                                            }}
                                                            data={{
                                                                Tag: 'span',
                                                                className: '',
                                                                lang: langs
                                                            }} >
                                                            {item.num}%
                                                        </UseTranslate>
                                                        <UseTranslate
                                                      style={{whiteSpace: 'nowrap',width: '100%',padding:0,textAlign: 'center'}}
                                                            onPress={() => {
                                                                setOptionChart('Trade')
                                                            }}
                                                            data={{
                                                                Tag: 'span',
                                                                className: '',
                                                                lang: langs
                                                            }} >
                                                            {item.minu}
                                                        </UseTranslate>


                                                    </div>
                                                )
                                            })
                                            :
                                            arrProfitBTC.map((item: any, index: any) => {
                                                return (
                                                    <div onClick={() => {
                                                        setIndexTrade(index)
                                                        setNumInCre(item.num)
                                                        setMinute(item.minute)
                                                    }} style={{ border: `1px solid ${indexTrade === index ? '#F2A301' : 'transparent'}` }}>
                                                        <UseTranslate
                                                        style={{whiteSpace: 'nowrap'}}
                                                            onPress={() => {
                                                                setOptionChart('Trade')
                                                            }}
                                                            data={{
                                                                Tag: 'span',
                                                                className: '',
                                                                lang: langs
                                                            }} >
                                                            Profit
                                                        </UseTranslate>
                                                        <UseTranslate
                                                        style={{whiteSpace: 'nowrap'}}
                                                            onPress={() => {
                                                                setOptionChart('Trade')
                                                            }}
                                                            data={{
                                                                Tag: 'span',
                                                                className: '',
                                                                lang: langs
                                                            }} >
                                                            {item.num}%
                                                        </UseTranslate>
                                                        <UseTranslate
                                                        style={{whiteSpace: 'nowrap',width: '100%',padding:0,textAlign: 'center'}}
                                                            onPress={() => {
                                                                setOptionChart('Trade')
                                                            }}
                                                            data={{
                                                                Tag: 'span',
                                                                className: '',
                                                                lang: langs
                                                            }} >
                                                            {item.minu}
                                                        </UseTranslate>
                                                    </div>
                                                )
                                            })
                                    }
                                </div>
                            </div>


                            <div className="m_trade_container_trade_content_left_balance">
                                <span>{langs == 'vi' ? 'Tiền còn lại' : 'Balance'}</span>
                                <span>{formatCoin(Number(balance))} USDT</span>
                            </div>


                            <div className="m_trade_container_trade_content_left_sliderRange">
                                <SliderRange step={step} setStep={setStep} totalCoin={(step: any) => {
                                    const totalCoinData: any = Number(balance) * (Number(step) / 100)
                                    setValueInputCoin(parseFloat(totalCoinData));
                                }} />
                            </div>
                            <div className="m_trade_container_trade_content_left_input">
                                <TextField

                                    fullWidth
                                    onChange={handleChange}
                                    InputProps={{
                                        style: {
                                            backgroundColor: "#1D1C22",
                                            borderRadius: 5,
                                            color: "white"
                                        },
                                        endAdornment: (
                                            <InputAdornment position="end">
                                                <span style={{ color: "rgba(255, 255, 255, 0.459)", fontSize: 13 }}>USDT</span>
                                            </InputAdornment>

                                        ),
                                    }}
                                    value={valueInputCoin} />
                            </div>
                            {/* <span style={{ marginTop: "15px", display: "block", fontSize: 13, color: "#ffffffc0" }}>{valueInputCoin >= 100 ? `${formatCoin(Number(valueInputCoin))} USD` : `≈100.00 USDT`}</span> */}
                            <span style={{ marginTop: "15px", display: "block", fontSize: 13, color: "#ffffffc0" }}>{`${formatCoin(Number(valueInputCoin))} USD`}</span>

                            <div className="m_trade_container_trade_content_left_button">
                                <button
                                    onClick={() => {
                                        if (Number(valueInputCoin) > 0) {
                                            const namePopular = localStorage.getItem('nameCoin') ? localStorage.getItem('nameCoin') : 'BTC'
                                            const infoUser: any = localStorage.getItem('infoUser');
                                            if (infoUser) {
                                                const token = localStorage.getItem('token');
                                                if (!token) {
                                                    localStorage.removeItem('infoUser')
                                                    window.location.reload()
                                                }
                                                axios.post(`${API_KEY}/post-to-cart`, {
                                                    type: "Long",
                                                    coin: valueInputCoin,
                                                    date: Date.now(),
                                                    email: JSON.parse(infoUser).email,
                                                    nameCoin: namePopular,
                                                    token: token,
                                                    minute: minute,
                                                    numInCre: numInCre,
                                                    people: "",
                                                    priceOrder: priceOrder,
                                                    coinInitial: balance
                                                }).then((res: any) => {
                                                    if (res.data.status == 'success') {
                                                        setDataCart(res.data.data);
                                                        setValueInputCoin(0)
                                                    }
                                                })
                                            }

                                        }
                                    }}
                                > {langs == 'vi' ? 'Mua lên' : 'Long'}</button>

                                <UseTranslate
                                    onPress={() => {

                                        if (Number(valueInputCoin) > 0) {
                                            const namePopular = localStorage.getItem('nameCoin') ? localStorage.getItem('nameCoin') : 'BTC'
                                            const infoUser: any = localStorage.getItem('infoUser');
                                            if (infoUser) {
                                                const token = localStorage.getItem('token');
                                                if (!token) {
                                                    localStorage.removeItem('infoUser')
                                                    window.location.reload()
                                                }
                                                axios.post(`${API_KEY}/post-to-cart`, {
                                                    type: "Short",
                                                    coin: valueInputCoin,
                                                    date: Date.now(),
                                                    email: JSON.parse(infoUser).email,
                                                    nameCoin: namePopular,
                                                    token: token,
                                                    minute: minute,
                                                    numInCre: numInCre,
                                                    people: "",
                                                    priceOrder: priceOrder,
                                                    coinInitial: balance
                                                }).then((res: any) => {
                                                    if (res.data.status == 'success') {
                                                        setDataCart(res.data.data);
                                                        setValueInputCoin(0)
                                                    }
                                                })
                                            }

                                        }

                                    }}
                                    data={{
                                        Tag: 'button',
                                        className: '',
                                        lang: langs
                                    }} >
                                    {langs == 'vi' ? 'Mua xuống' : 'Short'}</UseTranslate>
                            </div>
                        </div>
                        <div className="m_trade_container_trade_content_right">
                            <UseTranslate
                                data={{
                                    Tag: 'div',
                                    className: 'm_trade_container_trade_content_right_header',
                                    lang: langs
                                }} >
                                <span>Price</span>
                                <span>Quantity</span>
                            </UseTranslate>

                            {/* increase */}
                            <div className="m_trade_container_trade_content_right_dataIncre">
                                <span style={{ color: "rgb(85, 175, 114)" }}>{Number(Number(coinTrade) + 0.14).toFixed(2)}</span>
                                <div style={{ width: `${randomNumber.num1}%` }}><div>{formatCoin(Number(randomQuatity.num1))}.{num1}</div></div>
                            </div>
                            <div className="m_trade_container_trade_content_right_dataIncre">
                                <span style={{ color: "rgb(85, 175, 114)" }}>{Number(Number(coinTrade) + 0.13).toFixed(2)}</span>
                                <div style={{ width: `${randomNumber.num2}%` }}><div>{formatCoin(Number(randomQuatity.num2))}.{num2}</div></div>
                            </div>
                            <div className="m_trade_container_trade_content_right_dataIncre">
                                <span style={{ color: "rgb(85, 175, 114)" }}>{Number(Number(coinTrade) + 0.12).toFixed(2)}</span>
                                <div style={{ width: `${randomNumber.num3}%` }}><div>{formatCoin(Number(randomQuatity.num3))}.{num3}</div></div>
                            </div>
                            <div className="m_trade_container_trade_content_right_dataIncre">
                                <span style={{ color: "rgb(85, 175, 114)" }}>{Number(Number(coinTrade) + 0.11).toFixed(2)}</span>
                                <div style={{ width: `${randomNumber.num4}%` }}><div>{formatCoin(Number(randomQuatity.num4))}.{num4}</div></div>
                            </div>
                            <div className="m_trade_container_trade_content_right_dataIncre">
                                <span style={{ color: "rgb(85, 175, 114)" }}>{Number(Number(coinTrade) + 0.10).toFixed(2)}</span>
                                <div style={{ width: `${randomNumber.num5}%` }}><div>{formatCoin(Number(randomQuatity.num5))}.{num5}</div></div>
                            </div>
                            <div className="m_trade_container_trade_content_right_dataIncre">
                                <span style={{ color: "rgb(85, 175, 114)" }}>{Number(Number(coinTrade) + 0.09).toFixed(2)}</span>
                                <div style={{ width: `${randomNumber.num6}%` }}><div>{formatCoin(Number(randomQuatity.num6))}.{num6}</div></div>
                            </div>
                            <div className="m_trade_container_trade_content_right_dataIncre">
                                <span style={{ color: "rgb(85, 175, 114)" }}>{Number(Number(coinTrade) + 0.08).toFixed(2)}</span>
                                <div style={{ width: `${randomNumber.num7}%` }}><div>{formatCoin(Number(randomQuatity.num7))}.{num7}</div></div>
                            </div>
                            {/* increase */}
                            <div className="priceQuatityBox" style={{ display: "flex", flexDirection: "column" }}>
                                <span style={{ color: color, fontSize: 16, fontWeight: 600 }}>{coinTrade}</span>
                                <span style={{ fontSize: 12 }}>≈{coinTrade} USD</span>
                            </div>
                            {/* decrease */}
                            <div className="m_trade_container_trade_content_right_dataDescrea">
                                <span style={{ color: 'rgb(221, 83, 80)' }}>{Number(Number(coinTrade) + 0.07).toFixed(2)}</span>
                                <div style={{ width: `${randomNumber.num8}%` }}><div>{formatCoin(Number(randomQuatity.num8))}.{num8}</div></div>
                            </div>
                            <div className="m_trade_container_trade_content_right_dataDescrea">
                                <span style={{ color: 'rgb(221, 83, 80)' }}>{Number(Number(coinTrade) + 0.06).toFixed(2)}</span>
                                <div style={{ width: `${randomNumber.num9}%` }}><div>{formatCoin(Number(randomQuatity.num9))}.{num9}</div></div>
                            </div>
                            <div className="m_trade_container_trade_content_right_dataDescrea">
                                <span style={{ color: 'rgb(221, 83, 80)' }}>{Number(Number(coinTrade) + 0.05).toFixed(2)}</span>
                                <div style={{ width: `${randomNumber.num10}%` }}><div>{formatCoin(Number(randomQuatity.num10))}.{num10}</div></div>
                            </div>
                            <div className="m_trade_container_trade_content_right_dataDescrea">
                                <span style={{ color: 'rgb(221, 83, 80)' }}>{Number(Number(coinTrade) + 0.04).toFixed(2)}</span>
                                <div style={{ width: `${randomNumber.num11}%` }}><div>{formatCoin(Number(randomQuatity.num11))}.{num11}</div></div>
                            </div>
                            <div className="m_trade_container_trade_content_right_dataDescrea">
                                <span style={{ color: 'rgb(221, 83, 80)' }}>{Number(Number(coinTrade) + 0.03).toFixed(2)}</span>
                                <div style={{ width: `${randomNumber.num12}%` }}><div>{formatCoin(Number(randomQuatity.num12))}.{num12}</div></div>
                            </div>
                            <div className="m_trade_container_trade_content_right_dataDescrea">
                                <span style={{ color: 'rgb(221, 83, 80)' }}>{Number(Number(coinTrade) + 0.02).toFixed(2)}</span>
                                <div style={{ width: `${randomNumber.num13}%` }}><div>{formatCoin(Number(randomQuatity.num13))}.{num13}</div></div>
                            </div>
                            <div className="m_trade_container_trade_content_right_dataDescrea">
                                <span style={{ color: 'rgb(221, 83, 80)' }}>{Number(Number(coinTrade) + 0.01).toFixed(2)}</span>
                                <div style={{ width: `${randomNumber.num14}%` }}><div>{formatCoin(Number(randomQuatity.num14))}.{num14}</div></div>
                            </div>
                            {/* decrease */}
                        </div>
                    </div>

                </div>
            }
            {optionChart == 'Trade' &&
                <div className="m_trade_orderTrade">
                    <div className="m_trade_orderTrade_header">
                        <UseTranslate
                            data={{
                                Tag: 'div',
                                className: '',
                                lang: langs
                            }} >
                            <span>Positions <div></div></span>
                            {typeof window !== 'undefined' && window.innerWidth > 550 ? <span>Orders</span> : ''}
                        </UseTranslate>

                        <UseTranslate
                            data={{
                                Tag: 'div',
                                className: '',
                                lang: langs
                            }} >
                            {typeof window !== 'undefined' && window.innerWidth > 550 ? <>
                                <span>Positions <div></div></span>
                                <span>Orders</span>
                            </> : ''}

                            <button>All Orders</button>
                        </UseTranslate >

                    </div>
                    <div className="m_trade_orderTrade_cart">
                        {dataCart.length > 0 ? dataCart.sort((a: any, b: any) => b.date - a.date).map((item: any, index: any) => {
                            const startTime = item.date;
                            const timeNow = new Date(startTime)
                            const formatTime = timeNow.toLocaleString()

                            const second = Number(minute) * 60
                            const currentTime = new Date().getTime();
                            const elapsedTimeInSeconds = (currentTime - startTime) / 1000;
                            const time = Math.round(second - Number(elapsedTimeInSeconds))
                            const criculeBorder = 359
                            const percentTime = Math.round((time / second) * 100)
                            const parcentIncre = 100 - percentTime
                            const parcentCricucle = Math.round((parcentIncre / 100) * criculeBorder)
                            let timeEnd = false
                            if (elapsedTimeInSeconds > second) {
                                timeEnd = true
                            } else {
                                timeEnd = false
                            }
                            if (timeEnd) {
                                return (
                                    <div className="m_trade_orderTrade_cart_item" key={index}>
                                        <div className="m_trade_orderTrade_cart_item_header">

                                            <div>
                                                {item.nameCoin}/<span>USDT</span> <span>{langs == 'vi' ? 'Giao dịch mua' : 'Purchase transaction'} {item.minute} minute</span>

                                            </div>

                                            <div>
                                                {item.people.length > 0 ? item.people.toLowerCase() == 'win' ? <span style={{ color: "green" }}>{item.people}</span> : <span style={{ color: "red" }}>{item.people}</span> : langs == 'vi' ? 'Chờ kết quả' : 'Wait for results'}
                                            </div>


                                        </div>
                                        <div className="m_trade_orderTrade_cart_item_content" >


                                            {langs == 'en' ? <>
                                                <div>
                                                    <span>Order price</span>
                                                    <span>
                                                        {formatCoin(Number(item.priceOrder))}
                                                    </span>
                                                </div>
                                                <div>
                                                    <span>Amount of money</span>
                                                    <span>{formatCoin(Number(item.coin))} USDT</span>
                                                </div>

                                                <div>
                                                    <span>Expected profits</span>
                                                    <span>+ {formatCoin(Number(item.profit))} USDT</span>
                                                </div>
                                            </> : langs == 'vi' ?
                                                <>
                                                    <div>
                                                        <span>Giá đặt hàng</span>
                                                        <span>
                                                            {formatCoin(Number(item.priceOrder))}
                                                        </span>
                                                    </div>
                                                    <div>
                                                        <span style={{ color: "gray", fontSize: 12.5, padding: "3px 0" }}>{formatTime}  </span>
                                                        <span>Lượng tiền</span>
                                                        <span>{formatCoin(Number(item.coin))} USDT</span>
                                                    </div>

                                                    <div>
                                                        <span>
                                                            Lợi nhuận dự kiến
                                                        </span>
                                                        <span>+ {formatCoin(Number(item.profit))} USDT</span>
                                                    </div>
                                                </>
                                                :
                                                <></>
                                            }



                                        </div>
                                    </div>
                                )
                            } else {
                                return (
                                    <div className="m_trade_orderTrade_cart_item" key={index}>
                                        <div className="m_trade_orderTrade_cart_item_header" >

                                            <div>
                                                {item.nameCoin}/<span>USDT</span> <span>{langs == 'vi' ? 'Giao dịch mua' : 'Purchase transaction'} {item.minute} minute</span>
                                            </div>

                                            <div style={{ backgroundImage: `conic-gradient(#F2A301 ${parcentCricucle}deg, rgb(0, 0, 0) 0deg)` }} id="cricule_time"><span>{time} s</span></div>
                                        </div>
                                        <div className="m_trade_orderTrade_cart_item_content" >
                                            {langs == 'en' ? <>
                                                <div>
                                                    <span>Order price</span>
                                                    <span>{formatCoin(Number(item.priceOrder))}</span>
                                                </div>
                                                <div>
                                                    <span>Amount of money</span>
                                                    <span>{formatCoin(Number(item.coin))} USDT</span>
                                                </div>
                                                <div>
                                                    <span>Expected profits</span>
                                                    <span>+ {formatCoin(Number(item.profit))} USDT</span>
                                                </div>
                                            </> : langs == 'vi' ?
                                                <>
                                                    <div>
                                                        <span>Giá đặt hàng</span>
                                                        <span>{formatCoin(Number(item.priceOrder))}</span>
                                                    </div>
                                                    <div>
                                                        <span style={{ color: "gray", fontSize: 12.5, padding: "3px 0" }}>{formatTime}  </span>
                                                        <span>Lượng tiền</span>
                                                        <span>{formatCoin(Number(item.coin))} USDT</span>
                                                    </div>
                                                    <div>
                                                        <span>Lợi nhuận dự kiến</span>
                                                        <span>+ {formatCoin(Number(item.profit))} USDT</span>
                                                    </div>

                                                </>
                                                :
                                                <></>
                                            }



                                        </div>
                                    </div>
                                )
                            }

                        }) :
                            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", width: "100%" }}>
                                <img style={{ width: 200, height: 200 }} src="https://www.idg88fx.com/_next/static/media/empty.71a84b9a.svg" alt="" />
                                <UseTranslate
                                    data={{
                                        Tag: 'h3',
                                        className: '',
                                        lang: langs
                                    }} >
                                    No data
                                </UseTranslate>

                            </div>
                        }
                    </div>
                </div>}

        </div>
    )


}

export default Trade