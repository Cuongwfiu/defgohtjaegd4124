
import { useState, useEffect, useRef } from 'react';
import { AppProps } from 'next/app';
import '@/scss/index.scss';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import HandleH from '@/hook/handleH';
import HandleF from '@/hook/handleF';
import HideHF from '@/hook/hideHF';
import { useRouter } from 'next/router';
import ConfirmDialog from '@/components/confirm';
import axios from 'axios';
import { API_KEY } from '@/config/api';


function MyApp({ Component, pageProps }: AppProps) {
  const router = useRouter()
  const [openDialog, setOpenDialog] = useState<any>(false)
  const [msgConfirm, setmsgConfirm] = useState<any>('')
  const [msgTitleConfirm, setMsgTitleConfirm] = useState<any>('')
  const [play, setPlay] = useState<any>(false)
  const [lengthQt, setLengthQt] = useState<any>('')

  useEffect(() => {
    const audio = new Audio(`${API_KEY}/file-img/music/noti.mp3`);

    const notiActive: any = localStorage.getItem('notiActive');
    const langs: any = localStorage.getItem('lang');
    const infoUser = localStorage.getItem('infoUser');
    const denied = Notification.permission == 'denied';
    const granted = Notification.permission == 'granted';
    const defaults = Notification.permission == 'default'
    const msgConfirms = langs ? langs == 'vi' ? 'Chọn ok nếu bạn muốn nhận thông báo' : 'Select ok if you want to receive notifications' : 'Select ok if you want to receive notifications'
    const msgTitleConfirms = langs ? langs == 'vi' ? 'Thông báo trang web' : 'Notification website' : 'Notification website'
    setMsgTitleConfirm(msgTitleConfirms)
    setmsgConfirm(msgConfirms)
    document.onclick = () => {
      setPlay(true)
    }

    let interValChat: any
    if (notiActive ||granted) {
      if (notiActive == 'true'||granted) {
      
        if (granted) {
          if (infoUser) {
            const getDataChatUser = async () => {
              console.log('object');

              const realTime = localStorage.getItem('realTime')
              if (realTime) {
                const { email } = JSON.parse(infoUser)
                const res = await axios.get(`${API_KEY}/get-chat-user/${email}`)

                const { result, status } = res.data
              } else {
                const { email } = JSON.parse(infoUser)
                const res = await axios.get(`${API_KEY}/get-chat-user/${email}`)
                const { result, status } = res.data
                if (status == 1) {
                  if (play) { audio.play() }
                  const quantity = localStorage.getItem('quantity-chat')
                  if (quantity) {
                    localStorage.setItem('quantity-chat', Number(quantity) + result.length)
                    setLengthQt(Number(quantity) + result.length)

                  } else {
                    localStorage.setItem('quantity-chat', result.length)
                    setLengthQt(result.length)
                  }


                  result.forEach((item: any) => {
                    if (item.type == 'text') {
                      const notification = new Notification(`Cskh vừa nhắn tin cho bạn `, {
                        body: item.msg,
                        icon: ''
                      })
                      notification.onclick = () => {
                        window.location.href = 'https://idg88.info.vn/m/chat'
                      }
                    } else {
                      const notification = new Notification(`Cskh vừa gửi cho bạn 1 hình ảnh`, {
                        body: 'Hình ảnh',
                        icon: ''
                      })
                      notification.onclick = () => {
                        window.location.href = 'https://idg88.info.vn/m/chat'
                      }
                    }

                  })
                } else {

                }
              }

            }
            interValChat = setInterval(() => {
              getDataChatUser()
            }, 10000)
          }
        }
      } else {
      }
    } else {
      if (denied || defaults) {
        setOpenDialog(true)
      } else if (granted) {
      }
    }
    return () => {
      clearInterval(interValChat)
    }
  }, [play])


  return (
    <>



      <ConfirmDialog openDialog={openDialog} msg={msgConfirm} msgTitle={msgTitleConfirm} onPress={() => {
        const lcStr: any = localStorage
        setOpenDialog(false)
        const denied = Notification.permission == 'denied';
        const granted = Notification.permission == 'granted';
        const defaults = Notification.permission == 'default'

        if (denied || defaults) {
          Notification.requestPermission().then((permiss) => {
            console.log(permiss);
          })
          lcStr.setItem('notiActive', true)
        } else if (granted) {
        }

      }} onCLose={() => {
        setOpenDialog(false)
        const lcStr: any = localStorage
        lcStr.setItem('notiActive', false)
      }} />
      <HandleH >
        {(shouldShow: any) => (
          shouldShow && <Header lengthQt={lengthQt} />
        )}
      </HandleH>

      <Component {...pageProps} />
      <HideHF>
        {(shouldHide: any) => (
          !shouldHide && <HandleF >
            {(shouldShow: any) => (
              shouldShow && <Footer />
            )}
          </HandleF>
        )}
      </HideHF>


    </>
  );
}

export default MyApp;