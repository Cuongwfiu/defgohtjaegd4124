
// import type { AppProps } from 'next/app'
// import '@/scss/index.scss'
// import Head from 'next/head'
// function MyApp({ Component, pageProps }: AppProps) {
//   return (<>
//     <Head>
//       <script src="https://kit.fontawesome.com/c08976f15f.js" crossOrigin="anonymous"></script>
//       </Head>
//       <Component {...pageProps} />
//       </>)


// }

// export default MyApp
import { useState, useEffect } from 'react';
import { AppProps } from 'next/app';
import '@/scss/index.scss';
import Head from 'next/head';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import HandleH from '@/hook/handleH';
import HandleF from '@/hook/handleF';
import HideHF from '@/hook/hideHF';

function MyApp({ Component, pageProps }: AppProps) {
  return (
    <>
    
      <HandleH >
        {(shouldShow:any)=>(
          shouldShow&& <Header/>
        )}
      </HandleH>

      <Component {...pageProps} />
      <HideHF>
        {(shouldHide:any)=>(
            !shouldHide &&  <HandleF >
            {(shouldShow:any)=>(
              shouldShow&& <Footer/>
           )}
          </HandleF>
        )}
      </HideHF>
    

    </>
  );
}

export default MyApp;