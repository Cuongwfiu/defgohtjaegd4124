
import {useRouter} from "next/router";


type Props = {
    children:any
}

const HideHF = ({children}:Props)=>{
    const router = useRouter();
    const noRender = [
        '/m/login',
        '/m/chat',
        '/m/asset/withdraw',
        '/m/comming'
    ]
    const findPath = noRender.find(path => router.pathname.includes(path))
    return children(Boolean(findPath));
}
export default HideHF;