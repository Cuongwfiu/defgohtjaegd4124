export function getCookies(str: string, context: any,cookieDc:any=null) {
    let cookies 
    if(cookieDc){
        cookies = cookieDc
    }else{
        if(Boolean(context)){
            cookies = context.req.headers.cookie
        }else{
            cookies =undefined
        }
       
    }
    if (typeof cookies === 'string') {
        const blog = cookies.split(';').find(c => {
            const item = c.trim().split('=')

            return item[0] === str
        })

        if (blog) {
            const dataCookie = blog.split('=')[1]
            return dataCookie
        } else {
            // console.warn('Không tìm thấy cookie với tên "' + str + '".')
            return undefined
        }
    } else {
        //   console.error('Lỗi: Giá trị của biến document.cookie không hợp lệ.')
        return undefined
    }
}