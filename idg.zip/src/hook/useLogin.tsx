import { API_KEY } from "@/config/api"
import axios from "axios"




export const userLogin = async (router: any) => {
    const finfoUser = localStorage.getItem('infoUser')

    if (finfoUser) {
        const ftoken = localStorage.getItem('token')
        if (ftoken) {
        
            const res = await axios.get(`${API_KEY}/is-login/${JSON.parse(finfoUser).email}`, {
                headers: { Authorization: `${ftoken}` }
            })
            if (res.data.status === 1) {
          
            } else {
                if(finfoUser){
                    localStorage.removeItem('infoUser')
                }
                if(ftoken){
                    localStorage.removeItem('token')
                }
            }
        } else {
            return undefined
        }
    }
}