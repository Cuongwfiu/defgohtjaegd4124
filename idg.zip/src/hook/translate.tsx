import React, { Fragment, useEffect, useState } from "react";
import ReactDomServer from "react-dom/server"


type Props = {
    children: any,
    data: any,
    onPress?: any,
    style?: any,
    dep?:any
}
const UseTranslate: React.FC<Props> = (Props) => {
    const [styleCss, setStyleCss] = useState<any>(null)
    const { Tag, className, lang } = Props.data
    const { onPress, style,dep } = Props
    const language = lang
    const elReactString = ReactDomServer.renderToString(Props.children)
    const [elTranslate, setElTranslate] = useState<any>('')
    const handleTrans = async () => {
        const data = await fetch(`https://translate.googleapis.com/translate_a/single?client=gtx&sl=${'en'}&tl=${language}&dt=t&q=${encodeURIComponent(elReactString)}`)
        const jsonData = await data.json()
        if (jsonData[0]) {
            const newArr = jsonData[0].map((itemz: any, indexz: any) => {
                return itemz[0]
            })
            setElTranslate(newArr.join(''));
        }

    }
    useEffect(() => {
        if (language.length > 0) {
            if (language !== 'en') {
                handleTrans()
            }
        }
    }, [lang])
    useEffect(() => {
        handleTrans()
     }, dep)
    useEffect(() => {
        setStyleCss(style)
    }, [style])

    if (language !== 'en') {
        return (
            <Tag onClick={onPress ? onPress : undefined} style={styleCss ? styleCss : {}} className={className} dangerouslySetInnerHTML={{ __html: elTranslate }}>

            </Tag>
        )
    } else if (language == 'en') {
        return (
            <Tag onClick={onPress ? onPress : undefined} style={styleCss ? styleCss : {}} className={className} >
                {Props.children}
            </Tag>
        )
    } else {
        return (
            <></>
        )
    }



}

export default UseTranslate