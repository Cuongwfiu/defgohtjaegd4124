import { API_KEY } from "@/config/api";
import axios from "axios";

export default async function isAdmin(auth: any) {

    const dataAdmin = await axios.get(`${API_KEY}/is-admin`, {
        headers: {
            Authorization: `Bearer ${auth}`
        }
    })
    return dataAdmin.data

}