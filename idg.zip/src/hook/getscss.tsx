function getScss (element:any){
    function generateSCSS(el:any, prefix = '') {
      let scss = `${prefix}{`;      
      if (el.children.length === 0) {
        const child = el.children[0];
        if(child){
          const className = `&${child.classList.value.replace(`${el.classList.value}`, '')}`;
          const formatclassName = className==="&"?child.tagName.toLowerCase():className;
          let childScss = generateSCSS(child, className);
          if (childScss) {
            scss += `${childScss}`;
          }
        }
      
      }
  
   
      for (let i = 0; i < el.children.length; i++) {
        const child = el.children[i];
        const className = `&${child.classList.value.replace(`${el.classList.value}`, '')}`;
        const formatclassName = className==="&"?child.tagName.toLowerCase():className;
        let childScss = generateSCSS(child, formatclassName);
        if (childScss) {
          scss += `${childScss}`;
        }
      }
 
      scss += '}';
      return scss; 
    }
    const scss = generateSCSS(element);
    return scss
  }
  export default getScss