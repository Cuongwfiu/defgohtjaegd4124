
import {useRouter} from "next/router";


type Props = {
    children:any
}

const HandleH = ({children}:Props)=>{
    const router = useRouter();
    const noRender = [
        '/m/home'
    ]
    const findPath = noRender.find(path => router.pathname.includes(path))
    return children(Boolean(findPath));
}
export default HandleH;