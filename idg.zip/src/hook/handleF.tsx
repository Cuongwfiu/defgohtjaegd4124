
import {useRouter} from "next/router";


type Props = {
    children:any
}

const HandleF = ({children}:Props)=>{
    const router = useRouter();
    const noRender = [
        '/m'
    ]
    const findPath = noRender.find(path => router.pathname.includes(path))
    return children(Boolean(findPath));
}
export default HandleF;