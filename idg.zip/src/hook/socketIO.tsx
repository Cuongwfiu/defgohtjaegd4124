import { API_KEY } from "@/config/api"
import { io } from "socket.io-client"
export const socket = io(`${API_KEY}`)