
import { API_KEY } from "@/config/api"
import axios from "axios"
import Link from "next/link"
import React, { useEffect, useState } from "react"

type Props={
    namePopular :any
}
const RenderPopular:React.FC<Props> = (props)=>{
    const {namePopular} = props
    const [coinTrade, setCoinTrade] = useState<any>('')
    const [typeTrade, setTypeTrade] = useState<any>('')
    const [stopCall, setStopCall] = useState<any>(false)
    useEffect(() => {
        let interval: any
    
        if (stopCall) {
            interval = setInterval(() => {
                try {
                    axios.get(`${API_KEY}/api-trade/${namePopular}`).then(item => {
                        setCoinTrade(item.data.coinTrade)
                        setTypeTrade(item.data.typeTrade)
                    })
                } catch (error) {
                    if (error){
                        console.log('errrr');
                    }
                }
             
            }, 5000)
        } else {
            axios.get(`${API_KEY}/api-trade/${namePopular}`).then(item => {
                setCoinTrade(item.data.coinTrade)
                setTypeTrade(item.data.typeTrade)
            })
            setStopCall(true)
        }
     
  

        return () => {
            clearInterval(interval)
        }
    }, [stopCall])

return(
    <Link onClick={()=>{
        localStorage.setItem('nameCoin',namePopular)
    }} href={'/m/trade'} className="m_home_popular_item" >
    <div className="m_home_popular_item_title">
        <span>{namePopular}</span><span>/</span><span>USDT</span>
    </div>
    <div className="m_home_popular_item_content">
        <span style={{ color:typeTrade&& typeTrade.type == 'increase' ? '#559F47' : '#D74B4A' }}>{coinTrade}</span>
        <span style={{ color:typeTrade&& typeTrade.type == 'increase' ? '#559F47' : '#D74B4A' }}>{typeTrade?typeTrade.trade24 + '%':''}</span>
    </div>
    <div className="m_home_popular_item_button">
        <span>Trade</span>
        <svg focusable="false" aria-hidden="true" viewBox="0 0 24 24" data-testid="ArrowForwardIcon"><path d="m12 4-1.41 1.41L16.17 11H4v2h12.17l-5.58 5.59L12 20l8-8z"></path></svg>

    </div>
</Link>
)
}
export default RenderPopular