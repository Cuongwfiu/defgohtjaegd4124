import React from "react"
type Props ={
    arr:any
}
const DropDownSelect:React.FC<Props> = (Props)=>{
        const {arr} = Props
return(
<div>
<div className="select-menu">
<div className="select-btn">
    <span className="sBtn-text">Select your drop-down-option</span>
    <i className="bx bx-chevron-down"></i>
</div>
<ul className="drop-down-options">
    <li className="drop-down-option">
        <i className="bx bxl-github" ></i>
        <span className="drop-down-option-text">Github</span>
    </li>
    <li className="drop-down-option">
        <i className="bx bxl-instagram-alt" ></i>
        <span className="drop-down-option-text">Instagram</span>
    </li>
    <li className="drop-down-option">
        <i className="bx bxl-linkedin-square" ></i>
        <span className="drop-down-option-text">Linkedin</span>
    </li>
    <li className="drop-down-option">
        <i className="bx bxl-facebook-circle" ></i>
        <span className="drop-down-option-text">Facebook</span>
    </li>
    <li className="drop-down-option">
        <i className="bx bxl-twitter"></i>
        <span className="drop-down-option-text">Twitter</span>
    </li>
</ul>
</div>
</div>
)
}
export default DropDownSelect