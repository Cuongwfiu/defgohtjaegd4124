'use client';
import UseTranslate from "@/hook/translate";
import Link from "next/link";
import { useRouter } from "next/router";
import React, { useEffect, useState } from "react"
type Props = {

}

const Header: React.FC<Props> = () => {
    const [langs, setLangs] = useState<any>('')
    const [fullNameLang, setFullNameLang] = useState<any>('')
    const [iconlang, setIconlang] = useState<any>('')
    useEffect(() => {
        const iconlangs = localStorage.getItem('iconlang')
        const lang = localStorage.getItem('lang')
        const fullnamelangs = localStorage.getItem('fullnamelang')
        if (lang) {
            setLangs(lang)
        } else {
            setLangs('en')
        }
        if (fullnamelangs) {
            setFullNameLang(fullnamelangs)
        } else {
            setFullNameLang('English')
        }
        if (iconlangs) {
            setIconlang(iconlangs)
        } else {
            setIconlang('https://www.idg88fx.com/static/flags/4x3/us.svg')
        }
    }, [])
    const infoUser: any = typeof window !== 'undefined' && localStorage.getItem('infoUser') ? localStorage.getItem('infoUser') : null;
    const [infoUs, setInfoUs] = useState<any>(null)
    const router = useRouter()
    useEffect(() => {
        const data = JSON.parse(infoUser)
        setInfoUs(data)
    }, [infoUser])
    return (
        <div className="m_Header">
            <div className="m_Header_left">
                <Link href={infoUs ? '/m/profile' : '/m/login'}><i className="fa-solid fa-user"></i> </Link>
                <UseTranslate
                    data={{
                        Tag: 'span',
                        className: '',
                        lang: langs
                    }} >
                    {infoUs?.name}
                </UseTranslate>

            </div>
            <div className="m_Header_right">
                <i className="fa-regular fa-bell" style={{ color: "#ffffff" }}></i>
                <img src={iconlang} alt="" />
                <span style={{ cursor: "pointer" }} onClick={() => {
                    router.push('/m/setting/locale')
                }}>{fullNameLang}</span>
            </div>
        </div>
    )
}

export default Header               