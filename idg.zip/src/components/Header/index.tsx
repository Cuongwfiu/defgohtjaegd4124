'use client';
import UseTranslate from "@/hook/translate";
import Link from "next/link";
import { useRouter } from "next/router";
import React, { useEffect, useState } from "react"
type Props = {
    lengthQt: any
}

const Header: React.FC<Props> = (props) => {
    const { lengthQt } = props;
    const [langs, setLangs] = useState<any>('')
    const [fullNameLang, setFullNameLang] = useState<any>('')
    const [iconlang, setIconlang] = useState<any>('')
    const [noti, setNoti] = useState<any>('')
    const [showNoti, setShowNoti] = useState<any>(false)
    useEffect(() => {
        const iconlangs = localStorage.getItem('iconlang')
        const lang = localStorage.getItem('lang')
        const fullnamelangs = localStorage.getItem('fullnamelang')
        const quantity_chat = localStorage.getItem('quantity-chat')
        if (quantity_chat) {
            setNoti(quantity_chat)
        } else {
            setNoti('')
        }
        if (lang) {
            setLangs(lang)
        } else {
            setLangs('en')
        }
        if (fullnamelangs) {
            setFullNameLang(fullnamelangs)
        } else {
            setFullNameLang('English')
        }
        if (iconlangs) {
            setIconlang(iconlangs)
        } else {
            setIconlang('https://www.idg88fx.com/static/flags/4x3/us.svg')
        }
    }, [lengthQt])







    const infoUser: any = typeof window !== 'undefined' && localStorage.getItem('infoUser') ? localStorage.getItem('infoUser') : null;
    const [infoUs, setInfoUs] = useState<any>(null)
    const router = useRouter()
    useEffect(() => {
        const data = JSON.parse(infoUser)
        setInfoUs(data)
    }, [infoUser])
    return (
        <div className="m_Header">
            <div className="m_Header_left">
                <Link href={infoUs ? '/m/profile' : '/m/login'}><i className="fa-solid fa-user"></i> </Link>
                <UseTranslate
                    data={{
                        Tag: 'span',
                        className: '',
                        lang: langs
                    }} >
                    {infoUs?.name}
                </UseTranslate>

            </div>
            <div className="m_Header_right" style={{ position: "relative" }}>
                <i onClick={() => {
                    localStorage.setItem('quantity-chat', '')
                    setShowNoti(!showNoti)
                }} className="fa-regular fa-bell" style={{ color: "#ffffff", position: "relative", cursor: "pointer" }}>{
                        noti && <span className="notifica">{noti}</span>
                    }</i>
                <img style={{ userSelect: "none" }} src={iconlang} alt="" />
                <span style={{ cursor: "pointer", userSelect: "none" }} onClick={() => {
                    router.push('/m/setting/locale')
                }}>{fullNameLang}</span>
                {showNoti &&noti&& <div style={{
                    position: "absolute", right: "80%", top: "115%",
                    overflow: "hidden", userSelect: "none"
                }}>
                    <div className="notiData" >
                        <a style={{ display: "block", whiteSpace: "nowrap", color: "black", padding: "5px", fontFamily: "monospace" }} href="">{noti} tin nhắn từ cskh gửi.</a>
                    </div>

                </div>}

            </div>
        </div>
    )
}

export default Header               