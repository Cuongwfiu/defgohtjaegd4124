import React, { useEffect, useState } from "react";
import styled from 'styled-components';

type PropsSliderInput = {
    $lefts: any;
}
type Props = {
    totalCoin:any,
    setStep:any,
    step:any,
}
const SliderInput = styled.input`
width: 100%;
position: relative;
&::before {
    content: "";
    position: absolute;
    width: ${(props: any) => props.$lefts}px;
    height: 100%;
    background-color: #F7A600;
    z-index: 1;
    left: 0;
}
`;

const SliderRange: React.FC<Props> = (props) => {
    const {totalCoin,setStep,step} = props
  
    const [leftEl, setLeftEl] = useState<number>(0);

    useEffect(() => {

        const m_slider = document.querySelector('.m_slider')
        const widthSlider: any = m_slider?.clientWidth
        const valueStep = widthSlider / 100
        setLeftEl(valueStep * step)
    }, [step]);


    return (


        <div className={'m_slider'}>
            <SliderInput

                type="range"
                {...{ $lefts: leftEl } as PropsSliderInput}
                value={step}
                max={100}
                step={5}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                    setStep(Number(e.target.value));
                    totalCoin(e.target.value)
                }}
            />
        </div>


    );
}

export default SliderRange;