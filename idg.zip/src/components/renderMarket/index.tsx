
import React, { useEffect, useState } from "react"
import { socket } from "@/hook/socketIO"
import { API_KEY } from "@/config/api"
import { useRouter } from "next/router"
type Props = {
    nameTrade: any
}

const RenderMarket: React.FC<Props> = (props) => {
    const router = useRouter()
  
    const { nameTrade } = props
    const [coinTrade, setCoinTrade] = useState<any>('')
    const [typeTrade, setTypeTrade] = useState<any>('')
    const [stopCall, setStopCall] = useState<any>(false)
    useEffect(() => {
        let interval: any
        if (stopCall) {
            interval = setInterval(() => {
                fetch(`${API_KEY}/api-trade/${nameTrade}`).then(item => item.json()).then((item: any) => {
                    setCoinTrade(item.coinTrade)
                    setTypeTrade(item.typeTrade)
                })
            }, 5000)
        } else {
            fetch(`${API_KEY}/api-trade/${nameTrade}`).then(item => item.json()).then((item: any) => {
                setCoinTrade(item.coinTrade)
                setTypeTrade(item.typeTrade)
            })
            setStopCall(true)
        }

        return () => {
            clearInterval(interval)
        }
    }, [stopCall])

    return (
        <tr onClick={()=>{
            localStorage.setItem('nameCoin',nameTrade)
            router.push('/m/trade')
        }}>

            <td>
                <span>{nameTrade} / <span style={{ color: "rgba(255, 255, 255, 0.356)" }}>USDT</span></span>
            </td>
            <td>
                <div>
                    <span>{coinTrade}</span>
                    <span >{coinTrade} USD</span>
                </div>
            </td>
            <td>
                <div>   <span style={{ backgroundColor: typeTrade && typeTrade.type == "increase" ? '#55AF72' : '#DD5350' }}>{typeTrade.trade24}%</span></div>
            </td>


        </tr>
    )


}
export default React.memo(RenderMarket)              