import React, { useEffect, useState } from "react"
import { useRouter } from "next/router"
import Link from "next/link"
import UseTranslate from "@/hook/translate"
const Footer: React.FC = () => {
    const router = useRouter()
    const [langs, setLangs] = useState<any>('')

    useEffect(() => {
        const lang = localStorage.getItem('lang')
        if (lang) {
            setLangs(lang)
        } else {
            setLangs('en')
        }
    }, [])
    const arrFooter = [
        {
            name: "Home",
            icon: (color: any) => <svg width="25" height="25" fill={color} className="MuiSvgIcon-root MuiSvgIcon-fontSizeMedium css-vubbuv" focusable="false" aria-hidden="true" viewBox="0 0 24 24" data-testid="HomeIcon">
                <path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8"  ></path>
            </svg>,
            path: "/m/home"
        },
        {
            name: "Market",
            icon: (color: any) => <svg width="25" height="25" fill={color} className="MuiSvgIcon-root MuiSvgIcon-fontSizeMedium MuiTab-iconWrapper css-vubbuv" focusable="false" aria-hidden="true" viewBox="0 0 24 24"
                data-testid="CandlestickChartIcon"><path d="M9 4H7v2H5v12h2v2h2v-2h2V6H9zm10 4h-2V4h-2v4h-2v7h2v5h2v-5h2z"></path></svg>,
            path: "/m/market"
        },
        {
            name: "Trade",
            icon: (color: any) => <svg width="25" height="25" fill={color} className="MuiSvgIcon-root MuiSvgIcon-fontSizeMedium MuiTab-iconWrapper css-vubbuv" focusable="false" aria-hidden="true" viewBox="0 0 24 24" data-testid="ReceiptLongIcon"><path d="M19.5 3.5 18 2l-1.5 1.5L15 2l-1.5 1.5L12 2l-1.5 1.5L9 2 7.5 3.5 6 2v14H3v3c0 1.66 1.34 3 3 3h12c1.66 0 3-1.34 3-3V2l-1.5 1.5zM19 19c0 .55-.45 1-1 1s-1-.45-1-1v-3H8V5h11v14z">
            </path><path d="M9 7h6v2H9zm7 0h2v2h-2zm-7 3h6v2H9zm7 0h2v2h-2z" ></path></svg>,
            path: "/m/trade"
        },
        {
            name: "Assets",
            icon: (color: any) => <svg width="25" height="25" fill={color} className="MuiSvgIcon-root MuiSvgIcon-fontSizeMedium MuiTab-iconWrapper css-vubbuv"
                focusable="false" aria-hidden="true" viewBox="0 0 24 24" data-testid="AccountBalanceWalletIcon">
                <path d="M21 18v1c0 1.1-.9 2-2 2H5c-1.11 0-2-.9-2-2V5c0-1.1.89-2 2-2h14c1.1 0 2 .9 2 2v1h-9c-1.11 0-2 .9-2 2v8c0 1.1.89 2 2 2h9zm-9-2h10V8H12v8zm4-2.5c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5z">
                </path></svg>,
            path: "/m/asset"
        }
    ]

    return (
        <div className="m_Footer">

            <ul>
                {
                    arrFooter.map((item: any, index: any) => {
                        return (
                            <li key={index}>
                                <Link style={{ color: router.pathname.includes(item.path.replace('.', '')) ? "#F7A600" : '#888888' }} href={item.path}> {item.icon(router.pathname.includes(item.path.replace('.', '')) ? "#F7A600" : '#888888')}
                                    <UseTranslate
                                        data={{
                                            Tag: 'span',
                                            className: '',
                                            lang: langs
                                        }} >
                                        {item.name}
                                    </UseTranslate>
                                </Link>

                                <div style={{ backgroundColor: router.pathname.includes(item.path.replace('.', '')) ? "#F7A600" : 'transparent' }} className="line_footer"></div>
                            </li>
                        )
                    })
                }
            </ul>
        </div>
    )
}
export default Footer