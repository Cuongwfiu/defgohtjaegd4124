import isAdmin from "@/hook/isAdmin"
import React, { useEffect, useState } from "react"
const Admins: React.FC = () => {
    // isAdmin----------------------------------------------------------------
    const [isAdminClient, setIAdminClient] = useState<any>('')
    useEffect(() => {
        setIAdminClient(true)
        const isAdminFunc = async () => {
            const token = localStorage.getItem('tokenAdmin')
            if (token) {
                const data = await isAdmin(token)
                if(data.status === 'success'){
                    setIAdminClient('isAdmin')
                }else{
                    setIAdminClient('noAdmin')
                }
               
            } else {
                setIAdminClient('noAdmin')
            }

        }
        isAdminFunc()
    }, [])
    // isAdmin----------------------------------------------------------------
    return (
        <>
            {isAdminClient == 'isAdmin' ?
                   // isAdmin
                <div>
                    Bạn là admin
                </div>
                :
                isAdminClient == 'noAdmin' ?
                // noAdmin
                    <div>
                        Không thể xác thực
                    </div> :



                    <></>}

        </>
    )
}
export default Admins