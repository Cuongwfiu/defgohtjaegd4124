import { FormControl, InputAdornment, MenuItem, Popover, Select, TextField } from "@mui/material"
import SearchIcon from '@mui/icons-material/Search'
import React, { useEffect, useState } from "react"



type Props = {
    onGetData: any,
    onClose:any
}
const CreatePayment: React.FC<Props> = (props) => {
    const [searchText, setSearchText] = useState('');
    const { onGetData ,onClose} = props
    const optionLanguage = [
        {
            name: "Vietnam (Việt nam)",
            icon: <img src="https://www.idg88fx.com/static/flags/4x3/vn.svg" alt="" />,
            prefixPhone: "+84",
            type: "vi",
            typeName:"Việt nam"
        },
        {
            name: "United States",
            icon: <img src="https://www.idg88fx.com/static/flags/4x3/us.svg" alt="" />,
            prefixPhone: "+1",
            type: "en",
            typeName:"EngLish"
        }
    ]
    const [dataLang,setDataLang] =useState<any>(optionLanguage)

    const [langs, setLangs] = useState<any>('')
    useEffect(()=>{
        const filterArr = optionLanguage.filter((item:any)=>{
            if(item.name.toLowerCase().includes(searchText.toLowerCase())){
                return item
            }
        })
        setDataLang(filterArr);
        const lang = localStorage.getItem('lang')
        if (lang) {
            setLangs(lang)
        } else {
            setLangs('en')
        }
    },[searchText])
    return (
        <div className="language_main">
            <div className="language_main_header">
                <div className="language_main_header_top">
                    <span><svg onClick={()=>{
                        onClose()
                    }} className="MuiSvgIcon-root MuiSvgIcon-fontSizeMedium css-vubbuv" focusable="false" aria-hidden="true" viewBox="0 0 24 24" data-testid="ArrowBackIcon"><path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z"></path></svg>{langs=='vi'?'Vui lòng chọn quốc gia hoặc khu vực':'Please select the country or region'} </span>
                </div>
                <div className="language_main_header_bottom">
                    <TextField
                        fullWidth
                        onChange={(e) => {
                            setSearchText(e.target.value);
                        }}
                        className="search-field"
                        placeholder={langs=='vi'?'Tìm kiếm quốc gia hoặc khu vực':"Search country or region"}
                        InputProps={{
                            startAdornment: (
                                <InputAdornment position="start">
                                    <SearchIcon style={{ color: 'white' }} />
                                </InputAdornment>
                            ),
                            style: { backgroundColor: '#4C4B4F' },
                        }}
                    />
                </div>
            </div>
            <div className="language_main_container">
                {dataLang.map((item: any, index: any) => {
                    return (
                        <div onClick={() => {
                            onGetData(item.type,item.typeName,item.name)
                        }} key={index}>
                            <span>{item.icon} {item.name}</span>
                            <span>{item.prefixPhone}</span>
                        </div>
                    )
                })}
            </div>
        </div>
    )
}
export default CreatePayment