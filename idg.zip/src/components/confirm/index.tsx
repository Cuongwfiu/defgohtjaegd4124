import { Box, Button, Dialog, DialogActions, DialogContent, DialogTitle, IconButton, Typography } from '@mui/material';
import Close from '@mui/icons-material/Close'
import { useEffect, useState } from 'react';
const ConfirmDialog = (props: any) => {
    const { openDialog, msg, msgTitle, onPress, onCLose } = props

    return (
        <Dialog open={openDialog} maxWidth="sm" fullWidth>
            <DialogTitle color={"black"}>{msgTitle}</DialogTitle>
            <Box position="absolute" top={0} right={0}>
                <IconButton onClick={() => {
                    onCLose()
                }}>
                    <Close />
                </IconButton>
            </Box>
            <DialogContent>
                <Typography>{msg}</Typography>
            </DialogContent>
            <DialogActions>
                <Button onClick={() => {
                    onCLose()
                }} color="primary" variant="contained">
                    Cancel
                </Button>
                <Button onClick={() => {
                    onPress()
                }} color="secondary" variant="contained">
                    Ok
                </Button>
            </DialogActions>
        </Dialog>
    );
};
export default ConfirmDialog