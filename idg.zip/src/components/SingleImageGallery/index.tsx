import React, { useEffect, useState } from 'react';


type Props = {
    imageUrl: any
}

const ImageZoom: React.FC<Props> = (props) => {
    const { imageUrl } = props
    const [isZoomed, setIsZoomed] = useState(false);

    const toggleZoom = () => {
     
        setIsZoomed(!isZoomed);
    };
    useEffect(()=>{
        if(isZoomed ==false){
            const m_content_chat:any = document.querySelector('.m_content_chat')
            const heightContent = m_content_chat.scrollHeight
            m_content_chat.scrollTo({ top: heightContent});
        }
    },[isZoomed])
    return (
        <div className={`image-zoom ${isZoomed ? 'zoomed' : ''}`}>
            <img style={{width:`${isZoomed?'auto':'auto'}`}} src={imageUrl} alt="Zoomed Image" onClick={toggleZoom} />

            {isZoomed && (
                <div className="close-button" onClick={toggleZoom}>
                    <span>&times;</span>
                </div>
            )}
        </div>
    );
};





export default ImageZoom;