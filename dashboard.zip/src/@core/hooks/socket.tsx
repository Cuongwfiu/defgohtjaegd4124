
import { io } from "socket.io-client"
import { API_KEY } from "src/configs/api"
export const socket = io(`${API_KEY.endpoint}`)