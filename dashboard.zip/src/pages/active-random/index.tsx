import { FormControlLabel, FormGroup, Switch } from "@mui/material"
import axios from "axios"
import React, { useEffect, useState } from "react"
import { API_KEY } from "src/configs/api"
const ActiveRandom: React.FC = () => {
    const [check,setCheck]= useState<any>(false)
    useEffect(()=>{
        const getRandom = async()=>{
            const res = await axios.get(`${API_KEY.endpoint}/random-data-card`)
            const {result}= res.data
            setCheck(result)
        }
        getRandom()
    },[])
    return (
        <div>
            <FormGroup>
                <FormControlLabel control={<Switch checked={check} onClick={async()=>{
                    setCheck(!check)
                    const res = await axios.put(`${API_KEY.endpoint}/random-data-card`,{data:!check})
                }}/>} label="Chọn để bật random" />
            
            </FormGroup>
        </div>
    )
}
export default ActiveRandom