
import React, { useEffect, useState } from 'react';
import { Alert, Button, FormControl, InputLabel, MenuItem, Select, Snackbar, TextField } from '@mui/material';
import axios from 'axios';
import { API_KEY } from 'src/configs/api';



function Deposit() {
  const [select, setSelect] = useState<any>(null);
  const [selectEmail, setSelectEmail] = useState<any>('');

  const [coin, setCoin] = useState('');
  const [isFormVisible, setFormVisible] = useState(false);
  const [emailList, setEmailList] = useState([]);
  useEffect(() => {
    const getData = async () => {
      const tokenAdmin = localStorage.getItem('tokenAdmin')
      if (tokenAdmin) {
        const data = await axios.get(`${API_KEY.endpoint}/admin-get-users`, {
          headers: {
            Authorization: tokenAdmin
          }
        })
        if (data.data.status == 1) {
          setEmailList(data.data.arr)
        }
      }

    }
    getData()
  }, [])
  const HandleChange = (event: any) => {
    setSelectEmail(event.target.value);
    setSelect(event.target.value);
  };

  const handleCoinChange = (event: any) => {
    setCoin(event.target.value);
  };

  const [open, setOpen] = useState<any>(false)
  const [msg, setMsg] = useState<any>('')
  const [colorMsg, setColorMsg] = useState<any>('')
  const handleClose = (event: any) => {
    setOpen(false)
  }

  const handleSubmit = async () => {
    if (select) {
      if(select.banking.length > 0) {
        const data = {
          email: select.email,
          coin: coin,
          banking:select.banking[0].BankAcc,
          namebanking:select.banking[0].bankIns
        };
        const res = await axios.post(`${API_KEY.endpoint}/admin-deposit`, data)
        if(res.data.status ==1){
          setOpen(true)
          setMsg('Thêm tiền thành công')
          setColorMsg('success')
        }else{
          setOpen(true)
          setMsg('Thêm tiền không thành công')
          setColorMsg('error')
        }
      }else{
        alert('Tài khoản này chưa đăng ký ngân hàng')
      }
   
    }



  };
  return (
    <div>
      <FormControl >
        <InputLabel>Chọn Email</InputLabel>
        <Select label="Chọn Email" value={selectEmail} onChange={HandleChange}>
          {emailList.map((item:any,index) => (
            <MenuItem key={index} value={item}>
              {item.email}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
      <br />

      {select && (
        <div style={{ marginTop: "20px" }}>
          <TextField
            label="Số Tiền"
            type="number"
            value={coin}
            onChange={handleCoinChange}
          />
          <br />
          <Button style={{ marginTop: "10px" }} variant="contained" color="primary" onClick={handleSubmit}>
            Gửi
          </Button>
        </div>
      )}
      <Snackbar open={open} autoHideDuration={6000} onClose={handleClose}>
        <Alert onClose={handleClose} severity={colorMsg?colorMsg:'success'} sx={{ width: '100%' }}>
          {msg?msg:'Sucessfully submitted'}
        </Alert>
      </Snackbar>
    </div>
  );
}

export default Deposit;
