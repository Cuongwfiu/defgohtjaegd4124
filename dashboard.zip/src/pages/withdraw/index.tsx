// ** MUI Imports
import Grid from '@mui/material/Grid'
import Card from '@mui/material/Card'
import Typography from '@mui/material/Typography'
import CardHeader from '@mui/material/CardHeader'
import { useEffect, useState } from 'react'
import { FormControl, InputLabel, MenuItem, Select } from '@mui/material'
import { socket } from 'src/@core/hooks/socket'
import axios from 'axios'
import { API_KEY } from 'src/configs/api'
import TableDraw from 'src/views/tables/tableDraw'

const WithDraw = () => {
  const [emailList, setEmailList] = useState([]);
  const [email, setEmail] = useState<any>('');

  const [emailListSocket, setEmailListSocket] = useState([]);
  const [email2, setEmail2] = useState('');
  useEffect(() => {
    const getData = async () => {
      const tokenAdmin = localStorage.getItem('tokenAdmin')
      if (tokenAdmin) {
        socket.emit('admin-get-user', { token: tokenAdmin })
        const data = await axios.get(`${API_KEY.endpoint}/admin-get-users`, {
          headers: {
            Authorization: tokenAdmin
          }
        })
        if (data.data.status == 1) {
          setEmailList(data.data.arr)
          setEmail(data.data.arr[0].email)
        }
      }

    }
    getData()


    socket.on('res-user', ({ data }) => {
      setEmailListSocket(data)
    })
  }, [])
  const HandleChange = (event: any) => {
    setEmail(event.target.value);
  };

  return (
    <Grid container spacing={6}>
      <Grid item xs={12}>
        <Typography variant='h5'>
          Theo dõi
        </Typography>
        <FormControl >
          <InputLabel>Chọn Email</InputLabel>
          <Select label="Chọn Email" value={email} onChange={HandleChange}>
            {emailList.map((item: any, index) => (
              <MenuItem key={index} value={item.email}>
                {item.email}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
        <FormControl style={{marginLeft:10}}>
          <Select value={email2} onChange={(e:any)=>{
            setEmail(e.target.value);
            setEmail2(e.target.value);
          }}>
            {emailListSocket.map((item: any, index) => (
           
              <MenuItem key={index} value={item.email}>
                {item.email} đang có {item.resultBill} kết quả chưa xét
              </MenuItem>
            ))}
          </Select>
        </FormControl>
      </Grid>


      <Grid item xs={12}>
        <Card>
          <CardHeader title='Theo dõi người dùng' titleTypographyProps={{ variant: 'h6' }} />
          <TableDraw email={email} />
        </Card>
      </Grid>
    </Grid>
  )
}

export default WithDraw
