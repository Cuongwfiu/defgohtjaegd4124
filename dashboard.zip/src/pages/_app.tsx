// ** Next Imports
import Head from 'next/head'
import { Router, useRouter } from 'next/router'
import type { NextPage } from 'next'
import type { AppProps } from 'next/app'
import '../scss/index.scss'
// ** Loader Import
import NProgress from 'nprogress'

// ** Emotion Imports
import { CacheProvider } from '@emotion/react'
import type { EmotionCache } from '@emotion/cache'

// ** Config Imports
import themeConfig from 'src/configs/themeConfig'

// ** Component Imports
import UserLayout from 'src/layouts/UserLayout'
import ThemeComponent from 'src/@core/theme/ThemeComponent'

// ** Contexts
import { SettingsConsumer, SettingsProvider } from 'src/@core/context/settingsContext'

// ** Utils Imports
import { createEmotionCache } from 'src/@core/utils/create-emotion-cache'

// ** React Perfect Scrollbar Style
import 'react-perfect-scrollbar/dist/css/styles.css'

// ** Global css styles
import '../../styles/globals.css'
import { useEffect, useState } from 'react'
import axios from 'axios'
import { API_KEY } from 'src/configs/api'
import ConfirmDialog from 'src/views/confirm'
import isAdmin from 'src/@core/hooks/isAdmin'

// ** Extend App Props with Emotion
type ExtendedAppProps = AppProps & {
  Component: NextPage
  emotionCache: EmotionCache
}

const clientSideEmotionCache = createEmotionCache()

// ** Pace Loader
if (themeConfig.routingLoader) {
  Router.events.on('routeChangeStart', () => {
    NProgress.start()
  })
  Router.events.on('routeChangeError', () => {
    NProgress.done()
  })
  Router.events.on('routeChangeComplete', () => {
    NProgress.done()
  })
}

// ** Configure JSS & ClassName
const App = (props: ExtendedAppProps) => {
  const { Component, emotionCache = clientSideEmotionCache, pageProps } = props
  const router = useRouter()
  const [openDialog, setOpenDialog] = useState<any>(false)
  const [msgConfirm, setmsgConfirm] = useState<any>('')
  const [msgTitleConfirm, setMsgTitleConfirm] = useState<any>('')

  const [isAdminClient, setIAdminClient] = useState<any>('')
  useEffect(() => {
    setIAdminClient(true)
    const isAdminFunc = async () => {
      const token = localStorage.getItem('tokenAdmin')
      if (token) {
        const data = await isAdmin(token)
        if (data.status === 'success') {
          setIAdminClient('isAdmin')
        } else {
          setIAdminClient('noAdmin')
        }

      } else {
        setIAdminClient('noAdmin')
      }

    }
    isAdminFunc()
  }, [])

  useEffect(() => {
    const notiActive: any = localStorage.getItem('notiActive');
    const langs: any = localStorage.getItem('lang');
    let interValChat: any
    if ('Notification' in window) {
      const denied = Notification.permission == 'denied';
      const granted = Notification.permission == 'granted';
      const defaults = Notification.permission == 'default'
      const msgConfirms = langs ? langs == 'vi' ? 'Chọn ok nếu bạn muốn nhận thông báo' : 'Select ok if you want to receive notifications' : 'Select ok if you want to receive notifications'
      const msgTitleConfirms = langs ? langs == 'vi' ? 'Thông báo trang web' : 'Notification website' : 'Notification website'
      setMsgTitleConfirm(msgTitleConfirms)
      setmsgConfirm(msgConfirms)

      if (notiActive) {
        if (notiActive == 'true') {
          if (granted) {

            if (isAdminClient === 'isAdmin') {
              console.log('object admin');
              const getDataChatUser = async () => {
                const resCart = await axios.get(`${API_KEY.endpoint}/get-cart-user`)
                const { resultz, statusz } = resCart.data
                if (statusz == 1) {
                  resultz.forEach((item: any) => {
                    const msgLS = item.type == 'Long' ? 'Mua lên' : 'Mua xuống'
                    const notification = new Notification(`${item.email} vừa đặt 1 đơn`, {
                      body: `${item.email} đã đặt đơn ${msgLS} với số tiền ${item.coin}`,
                      icon: ''
                    })
                    notification.onclick = () => {
                      window.location.href = 'https://heyiu.online/follow-users'
                    }



                  })
                }
                const res = await axios.get(`${API_KEY.endpoint}/get-chat-admin`)
                const { result, status } = res.data
                if (status == 1) {
                  result.forEach((item: any) => {
                    if (item.type == 'text') {
                      const notification = new Notification(`${item.email} vừa nhắn tin cho bạn `, {
                        body: item.msg,
                        icon: ''
                      })
                      notification.onclick = () => {
                        window.location.href = 'https://heyiu.online/chat'
                      }
                    } else {
                      const notification = new Notification(`${item.email} vừa gửi cho bạn 1 hình ảnh`, {
                        body: 'Hình ảnh',
                        icon: ''
                      })
                      notification.onclick = () => {
                        window.location.href = 'https://heyiu.online/chat'
                      }
                    }
                  })
                }
              }
              interValChat = setInterval(() => {
                getDataChatUser()
              }, 10000)
            }
          }
        }
      } else {
        if (denied || defaults) {
          setOpenDialog(true)
        } else if (granted) {
        }
      }
    } else {


    }

    return () => {
      clearInterval(interValChat)
    }
  }, [router, isAdminClient])
  // Variables
  const getLayout = Component.getLayout ?? (page => <UserLayout>{page}</UserLayout>)

  return (
    <CacheProvider value={emotionCache}>
      <Head>
        <title>{`${themeConfig.templateName} - Material Design React Admin Template`}</title>
        <meta
          name='description'
          content={`${themeConfig.templateName} – Material Design React Admin Dashboard Template – is the most developer friendly & highly customizable Admin Dashboard Template based on MUI v5.`}
        />
        <meta name='keywords' content='Material Design, MUI, Admin Template, React Admin Template' />
        <meta name='viewport' content='initial-scale=1, width=device-width' />
      </Head>

      <SettingsProvider>
        <SettingsConsumer>

          {({ settings }) => {
            return (<>
              <ConfirmDialog openDialog={openDialog} msg={msgConfirm} msgTitle={msgTitleConfirm} onPress={() => {
                const lcStr: any = localStorage
                setOpenDialog(false)
                if ('Notification' in window) {
                  const denied = Notification.permission == 'denied';
                  const granted = Notification.permission == 'granted';
                  const defaults = Notification.permission == 'default'

                  if (denied || defaults) {
                    Notification.requestPermission().then((permiss) => {
                      console.log(permiss);
                    })
                    lcStr.setItem('notiActive', true)
                  } else if (granted) {
                  }
                }


              }} onCLose={() => {
                setOpenDialog(false)
                const lcStr: any = localStorage
                lcStr.setItem('notiActive', false)
              }} />
              <ThemeComponent settings={settings}>{getLayout(<Component {...pageProps} />)}</ThemeComponent>
            </>)


          }}
        </SettingsConsumer>
      </SettingsProvider>
    </CacheProvider>
  )
}

export default App
