
import { Button, SwipeableDrawer } from "@mui/material"
import React, { useEffect, useRef, useState } from "react"
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import isAdmin from "src/@core/hooks/isAdmin";
import { socket } from "src/@core/hooks/socket";
import ImageZoom from "src/@core/components/simpleZoomImg";
import { API_KEY } from "src/configs/api";
const Chat: React.FC = () => {

    const [isAdminClient, setIAdminClient] = useState<any>('')
    const [showChat, setShowChat] = useState<any>(false)
    const [email, setEmail] = useState<any>('')
    const [dataEmailUser, setDataEmailUser] = useState<any>([])
    const [textSend, setTextSend] = useState<any>('')
    const [dataChat, setDataChat] = useState<any>([])
    const [runScroll, setRunScroll] = useState<any>(false)
    const [stopRd, setStopRd] = useState<any>(false)
    const contentChat = useRef<any>(null)
    const fileInputRef = useRef<any>(null)
    const [autoChat, setAutoChat] = useState<any>('')
    useEffect(() => {
        setIAdminClient(true)
        const isAdminFunc = async () => {
            const token = localStorage.getItem('tokenAdmin')
            if (token) {
                const data = await isAdmin(token)
                socket.emit('get-chat-admin', { token: token })
                if (data.status === 'success') {
                    setIAdminClient('isAdmin')
                } else {
                    setIAdminClient('noAdmin')
                }

            } else {
                setIAdminClient('noAdmin')
            }

        }
        isAdminFunc()

        socket.on('chat', ({ data }) => {
            setDataChat(data)
        })
        socket.on('data-chat-all', ({ data }) => {
            setDataChat(data);
            if (data.length > 0) {
            } else {
                setAutoChat('img')
                setTimeout(() => {
                    setAutoChat('msg')
                }, 2000)
            }
        })
        socket.on('send-data-chat', ({ data }) => {
            setDataEmailUser(data);
        })
    }, [])
    useEffect(() => {
        if (!stopRd) {
            if (dataEmailUser[0]) {
                setEmail(dataEmailUser[0].email)
                setStopRd(true)
            }

        }

    }, [stopRd, dataEmailUser])

    useEffect(() => {

        if (contentChat.current) {
            if (contentChat.current.scrollHeight) {
                const heightContent = contentChat.current.scrollHeight
                if (runScroll) {
                    contentChat.current.scrollTo({ top: heightContent, behavior: 'smooth' });
                } else {
                    const heightContent = contentChat.current.scrollHeight
                    contentChat.current.scrollTop = heightContent
                    setRunScroll(true)
                }

            }

        }


    }, [runScroll, dataChat])

    function formatTimeAgo(milliseconds: any) {
        const now = Math.floor(Date.now()); // Lấy thời gian hiện tại dưới dạng mili giây
        const elapsed = now - milliseconds;

        if (elapsed < 60000) { // 60 giây
            return `${Math.floor(elapsed / 1000)} giây trước`;
        } else if (elapsed < 3600000) { // 60 phút
            const minutes = Math.floor(elapsed / 60000);
            return `${minutes} phút trước`;
        } else if (elapsed < 86400000) { // 24 giờ
            const hours = Math.floor(elapsed / 3600000);
            return `${hours} giờ trước`;
        } else if (elapsed < 2592000000) { // 30 ngày
            const days = Math.floor(elapsed / 86400000);
            return `${days} ngày trước`;
        } else if (elapsed < 31536000000) { // 365 ngày
            const months = Math.floor(elapsed / 2592000000);
            return `${months} tháng trước`;
        } else {
            const years = Math.floor(elapsed / 31536000000);
            return `${years} năm trước`;
        }
    }

    const milliseconds = 1698912533558;
    return (
        <>
            {isAdminClient === 'isAdmin' ?
                <div>
                    <div style={{ display: "flex", justifyContent: "center", alignItems: "center", height: "60vh" }}>
                        <div className="admin_optionChat" style={{ overflowY: "auto", display: "flex", justifyContent: "center", alignItems: "center", width: "50%" }}>
                            <select onChange={(e: any) => {
                                setEmail(e.target.value);
                            }} style={{ width: "100%" }}>
                                {dataEmailUser.map((item: any, index: any) => {
                                    return (
                                        <option value={item.email}>
                                            {item.email} {item.quatitySeender} tin nhắn
                                        </option>
                                    )
                                })}
                            </select>
                        </div>
                        <Button onClick={() => {
                            setShowChat(true)
                            const token = localStorage.getItem('tokenAdmin')
                            if (token) {
                                socket.emit('admin-join', { email: email, token: token })
                            }


                        }} style={{ marginLeft: 10 }} variant="outlined">Chat</Button>
                    </div>




                    <SwipeableDrawer
                        anchor="right"
                        onOpen={() => {
                            setShowChat(true)
                        }}
                        open={showChat}
                        onClose={() => {
                            setShowChat(false)
                        }}>
                        {/* <div style={{ width: typeof window !== 'undefined' ? window.innerWidth : 0 }} className="main_chat_msg_admin">
                        <div className="m_header_chat">
                            <ArrowBackIcon style={{ cursor: "pointer" }} onClick={() => {
                                setShowChat(false)
                            }} />
                        </div>
                        <div className="m_content_chat" ref={contentChat}>
                            {dataChat.map((item: any, index: any) => {
                              if(item){
                                if(item.type =='image'){
                                    return(
                                        <div key={index} className={`bubbleWrapper`}>
                                        <div className={`${item.active.toLowerCase() === 'admin' ? 'inlineContainer' : 'inlineContainer own'}`}>
                                            <img style={{ height: "40px", width: "40px" }} className="inlineIcon" src={`${item.active === 'admin' ? 'https://cdn.pixabay.com/photo/2019/08/11/18/59/icon-4399701_1280.png'
                                                : 'https://png.pngtree.com/png-vector/20191125/ourmid/pngtree-beautiful-admin-roles-line-vector-icon-png-image_2035379.jpg'}`} />
                                            <div style={{backgroundColor:"transparent",border:"none"}} className={`${item.active.toLowerCase() === 'admin' ? 'otherBubble other' : 'ownBubble own'}`}>
                                            <ImageZoom imageUrl={`${API_KEY.endpoint.endpoint}${item.msg}`}  />
                                            </div>
                                        </div><span className={`${item.active.toLowerCase() === 'admin' ? 'other' : 'own'}`}>{formatTimeAgo(Number(item.date))}</span>
                                    </div>
                                    )
                                }else{
                                    return (
                                        <div key={index} className={`bubbleWrapper`}>
                                            <div className={`${item.active.toLowerCase() === 'admin' ? 'inlineContainer' : 'inlineContainer own'}`}>
                                                <img style={{ height: "40px", width: "40px" }} className="inlineIcon" src={`${item.active === 'admin' ? 'https://cdn.pixabay.com/photo/2019/08/11/18/59/icon-4399701_1280.png'
                                                    : 'https://png.pngtree.com/png-vector/20191125/ourmid/pngtree-beautiful-admin-roles-line-vector-icon-png-image_2035379.jpg'}`} />
                                                <div className={`${item.active.toLowerCase() === 'admin' ? 'otherBubble other' : 'ownBubble own'}`}>
                                                    {item.msg}
                                                </div>
                                            </div><span className={`${item.active.toLowerCase() === 'admin' ? 'other' : 'own'}`}>{formatTimeAgo(Number(item.date))}</span>
                                        </div>
                                    )
                                }
                            }
                            })}

                        </div>
                        <div className="m_send_chat">
                            <div className="chat-box-footer">
                            <div className="useFile">
                            <label htmlFor="file-chat">
                                <img src={`${API_KEY.endpoint.endpoint}/file-img/dinhkem.png`} alt="" />
                            </label>
                            <input
                            ref={inputChat}
                            onChange={(e:any)=>{
                                
                                if(e.target.files[0].type =='image/jpeg'||e.target.files[0].type =='image/png'){
                                   const ext = e.target.files[0].type.split('/')[1]
                                    socket.emit('chat', { email: email, msg: e.target.files[0], active: "admin", date: Date.now(),type:"image",ext:ext })
                                    inputChat.current.value =null
                                }
                        
                            }} id="file-chat" accept=".png,.jpg" type="file" />
                        </div>
                                <textarea value={textSend} onChange={(e) => {
                                    setTextSend(e.target.value);
                                }} id="chat_input" placeholder="Enter your message here..."></textarea>
                                <button onClick={() => {
                                    
                                    setTextSend('')
                                    socket.emit('chat', { email: email, msg: textSend, active: "admin", date: Date.now(),type:"text" })
                                }} id="send">
                                    <svg style={{ width: "24px", height: "24px" }} viewBox="0 0 24 24">
                                        <path fill="#006ae3" d="M2,21L23,12L2,3V10L17,12L2,14V21Z" />
                                    </svg>
                                </button>
                            </div>
                        </div>
                    </div> */}


                        <div style={{ width: "100vw" }} className="main_chat_msg">
                            <div style={{ backgroundColor: "#247CFF" }} className="m_header_chat">
                                <ArrowBackIcon style={{ cursor: "pointer", color: "white" }}
                                    onClick={() => {
                                        setShowChat(false)
                                    }
                                    } />
                                <h2 style={{ color: "white" }} > Chăm sóc khách hàng</h2>
                            </div>
                            <div ref={contentChat} className="m_content_chat">
                                {dataChat.length > 0 ? dataChat.map((item: any, index: any) => {
                                    if (item) {
                                        if (item.type == 'image') {
                                            return (
                                                <div key={index} className={`bubbleWrapper`}>
                                                    <div className={`${item.active.toLowerCase() === 'admin' ? 'inlineContainer' : 'inlineContainer own'}`}>
                                                        {/* <img style={{ height: "40px", width: "40px" }} className="inlineIcon" src={`${item.active === 'admin' ? 'https://cdn.pixabay.com/photo/2019/08/11/18/59/icon-4399701_1280.png'
                                            : 'https://png.pngtree.com/png-vector/20191125/ourmid/pngtree-beautiful-admin-roles-line-vector-icon-png-image_2035379.jpg'}`} /> */}
                                                        {item.active === 'admin' ? <img style={{ height: "40px", width: "40px" }} className="inlineIcon" src={`${API_KEY.endpoint}/file-img/contact.png`} /> : <></>}
                                                        <div style={{ backgroundColor: "transparent", border: "none" }} className={`${item.active.toLowerCase() === 'admin' ? 'otherBubble other' : 'ownBubble own'}`}>
                                                            <ImageZoom imageUrl={`${API_KEY.endpoint}${item.msg}`} />
                                                        </div>
                                                    </div><span className={`${item.active.toLowerCase() === 'admin' ? 'other' : 'own'}`}>{formatTimeAgo(Number(item.date))}</span>
                                                </div>
                                            )
                                        } else {
                                            return (
                                                <div key={index} className={`bubbleWrapper`}>
                                                    <div className={`${item.active.toLowerCase() === 'admin' ? 'inlineContainer' : 'inlineContainer own'}`}>
                                                        {item.active === 'admin' ? <img style={{ height: "40px", width: "40px" }} className="inlineIcon" src={`${API_KEY.endpoint}/file-img/contact.png`} /> : <></>}

                                                        <div className={`${item.active.toLowerCase() === 'admin' ? 'otherBubble other' : 'ownBubble own'}`}>
                                                            {item.msg}
                                                        </div>
                                                    </div><span className={`${item.active.toLowerCase() === 'admin' ? 'other' : 'own'}`}>{formatTimeAgo(Number(item.date))}</span>
                                                </div>
                                            )
                                        }
                                    }

                                }) : autoChat == 'img' ?
                                    <div className={`bubbleWrapper`}>
                                        <div className={`inlineContainer own'}`}>
                                            <img style={{ height: "40px", width: "40px" }} className="inlineIcon" src={`${API_KEY.endpoint}/file-img/contact.png`} />

                                            <img style={{ width: 80 }} src="https://media.tenor.com/sMenWFrH3YsAAAAC/typing-text.gif" alt="" />

                                        </div><span className={`other`}>{formatTimeAgo(Number(Date.now()))}</span>
                                    </div>
                                    : autoChat == 'msg' ?
                                        <div className={`bubbleWrapper`}>
                                            <div className={`inlineContainer own'}`}>
                                                <img style={{ height: "40px", width: "40px" }} className="inlineIcon" src={`${API_KEY.endpoint}/file-img/contact.png`} />
                                                <div className="otherBubble other">
                                                    Người dùng này chưa nhắn tin cho bạn
                                                </div>

                                            </div><span className={`other`}>{formatTimeAgo(Number(Date.now()))}</span>
                                        </div> : ''
                                }

                            </div>
                            <div className="m_send_chat">
                                <div className="useFile">

                                    <label htmlFor="file-chat">
                                        <img src={`${API_KEY.endpoint}/file-img/photo.png`} alt="" />
                                    </label>
                                    <input
                                        ref={fileInputRef}
                                        onChange={(e: any) => {
                                            if (e.target.files[0].type == 'image/jpeg' || e.target.files[0].type == 'image/png') {
                                                console.log(e.target.files[0])
                                                const ext = e.target.files[0].type.split('/')[1]
                                                socket.emit('chat', { email: email, msg: e.target.files[0], active: "admin", date: Date.now(), type: "image", ext: ext })
                                                fileInputRef.current.value = null;
                                            }

                                        }} id="file-chat" accept=".png,.jpg" type="file" />
                                    <div className="useFile_like">    <img onClick={() => {
                                        const msg = '👍'
                                        setTextSend('')
                                        socket.emit('chat', { email: email, msg: msg, active: "admin", date: Date.now(), type: "text" })
                                    }} src={`${API_KEY.endpoint}/file-img/like.png`} alt="" /></div>
                                </div>
                                <div className="chat-box-footer">

                                    <textarea value={textSend} onChange={(e) => {
                                        setTextSend(e.target.value);
                                    }} id="chat_input" placeholder='Nhập vào tin nhắn của bạn'></textarea>
                                    <button onClick={() => {
                                        setTextSend('')
                                        socket.emit('chat', { email: email, msg: textSend, active: "admin", date: Date.now(), type: "text" })
                                    }} id="send">
                                        <span className="send-chat" style={{ color: "white" }} >Gửi đi</span>


                                    </button>
                                </div>
                            </div>
                        </div>




                    </SwipeableDrawer>
                </div>
                : isAdminClient === 'noAdmin' ? <div>Vui lòng xác thực</div> : <></>}

        </>


    )
}
export default Chat