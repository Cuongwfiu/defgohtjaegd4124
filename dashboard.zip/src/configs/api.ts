type API = {
    endpoint: string;
}

export const API_KEY:API = {
    // endpoint:'http://localhost:4900'
    // endpoint:'https://happynewyear.store'
      endpoint:'https://idg88.info.vn'
}

