


export const dataNameBank: any = {
   
    TCB: [{
            "name": "TCBS",
            "title": "Công ty Cổ phần chứng khoán Kỹ thương",
            "nameIcon": "",
            "group": "TCB"
        },
        {
            "name": "DBS-HCM",
            "title": "Ngân hàng TNHH MTV Phát triển Singapore",
            "nameIcon": "",
            "group": "TCB"
        },
        {
            "name": "Vietcombank",
            "title": "Ngân hàng TMCP Ngoại thương Việt Nam",
            "nameIcon": "",
            "group": "TCB"
        },
        {
            "name": "BIDV",
            "title": "Ngân hàng TMCP Đầu tư và Phát Triển Việt Nam",
            "nameIcon": "",
            "group": "TCB"
        },
        {
            "name": "HDBANK",
            "title": "Ngân hàng TMCP Phát triển TP. Hồ Chí Minh",
            "nameIcon": "",
            "group": "TCB"
        },
        {
            "name": "Sacombank",
            "title": "Ngân hàng TMCP Sài Gòn Thương Tín",
            "nameIcon": "",
            "group": "TCB"
        },
        {
            "name": "VIB",
            "title": "Ngân hàng TMCP Quốc tế Việt Nam",
            "nameIcon": "",
            "group": "TCB"
        },
        {
            "name": "AGRIBANK",
            "title": "Ngân hàng Nông nghiệp và Phát triển Nông thôn Việt Nam",
            "nameIcon": "",
            "group": "TCB"
        },
        {
            "name": "TPBANK",
            "title": "Ngân hàng TMCP Tiên Phong",
            "nameIcon": "",
            "group": "TCB"
        },
        {
            "name": "Vietinbank",
            "title": "Ngân hàng TMCP Công thương Việt Nam",
            "nameIcon": "",
            "group": "TCB"
        },
        {
            "name": "MB",
            "title": "Ngân hàng TMCP Quân Đội",
            "nameIcon": "",
            "group": "TCB"
        },
        {
            "name": "VPBANK",
            "title": "Ngân hàng TMCP Việt Nam Thịnh Vượng",
            "nameIcon": "",
            "group": "TCB"
        }
    ],
    VCB: [{
            "name": "HDBANK",
            "title": "Ngân hàng Phát triển TP.HCM (HD BANK)",
            "nameIcon": "",
            "group": "VCB"
        },
        {
            "name": "MB",
            "title": "Ngân hàng Quân Đội (MB)",
            "nameIcon": "",
            "group": "VCB"
        },
        {
            "name": "Sacombank",
            "title": "Ngân hàng Sài Gòn thương tín (SACOMBANK)",
            "nameIcon": "",
            "group": "VCB"
        },
        {
            "name": "VIB",
            "title": "Ngân hàng Quốc Tế (VIB)",
            "nameIcon": "",
            "group": "VCB"
        },
        {
            "name": "BIDV",
            "title": "Ngân hàng Đầu tư và phát triển Việt Nam (BIDV)",
            "nameIcon": "",
            "group": "VCB"
        },
        {
            "name": "VP BANK",
            "title": "Ngân hàng Việt Nam Thịnh Vượng (VPBANK)",
            "nameIcon": "",
            "group": "VCB"
        },
        {
            "name": "TPBANK",
            "title": "Ngân hàng Tiên phong (TPBANK)",
            "nameIcon": "",
            "group": "VCB"
        },
        {
            "name": "VIETINBANK",
            "title": "Ngân hàng Công Thương Việt Nam (VIETINBANK)",
            "nameIcon": "",
            "group": "VCB"
        }
    ],

    MB: [
        {
            "name": "Ngoại Thương Việt Nam (VIETCOMBANK, VCB)",
            "title": "Ngoại Thương Việt Nam (VIETCOMBANK, VCB)",
            "nameIcon": "vcb",
            "group": "MB"
        },
        {
            "name": "Shinhan bank",
            "title": "Shinhan bank",
            "nameIcon": "shinhanbank",
            "group": "MB"
        },
        {
            "name": "Phương Đông (OCB)",
            "title": "Phương Đông (OCB)",
            "nameIcon": "ocb",
            "group": "MB"
        },
        {
            "name": "Sài Gòn (SCB)",
            "title": "Sài Gòn (SCB)",
            "nameIcon": "scb",
            "group": "MB"
        },
        {
            "name": "Đông Á (DONG A BANK)",
            "title": "Đông Á (DONG A BANK)",
            "nameIcon": "dongabank",
            "group": "MB"
        },
        {
            "name": "Hàng Hải (MSB)",
            "title": "Hàng Hải (MSB)",
            "nameIcon": "msb",
            "group": "MB"
        },
        {
            "name": "Xuất Nhập khẩu Việt Nam (EXIMBANK)",
            "title": "Xuất Nhập khẩu Việt Nam (EXIMBANK)",
            "nameIcon": "exb",
            "group": "MB"
        },
        {
            "name": "Việt Nam Thịnh Vượng (VPBANK)",
            "title": "Việt Nam Thịnh Vượng (VPBANK)",
            "nameIcon": "vpbank",
            "group": "MB"
        },
        {
            "name": "Tiên Phong (TPBANK)",
            "title": "Tiên Phong (TPBANK)",
            "nameIcon": "tpbank",
            "group": "MB"
        },
        {
            "name": "Bắc Á (BAC A BANK)",
            "title": "Bắc Á (BAC A BANK)",
            "nameIcon": "babank",
            "group": "MB"
        },
        {
            "name": "ANZ bank",
            "title": "ANZ bank",
            "nameIcon": "anz",
            "group": "MB"
        },
        {
            "name": "Bản Việt (VIETCAPITALBANK)",
            "title": "Bản Việt (VIETCAPITALBANK)",
            "nameIcon": "vietcapital",
            "group": "MB"
        },
        {
            "name": "Đầu Tư Và Phát Triển Việt Nam (BIDV)",
            "title": "Đầu Tư Và Phát Triển Việt Nam (BIDV)",
            "nameIcon": "bidv",
            "group": "MB"
        },
        {
            "name": "Bưu điện Liên Việt (LPB)",
            "title": "Bưu điện Liên Việt (LPB)",
            "nameIcon": "lpb",
            "group": "MB"
        },
        {
            "name": "Đông Nam Á (SEABANK)",
            "title": "Đông Nam Á (SEABANK)",
            "nameIcon": "seabank",
            "group": "MB"
        },
        {
            "name": "Việt Á (VIETABANK)",
            "title": "Việt Á (VIETABANK)",
            "nameIcon": "vietabank",
            "group": "MB"
        },
        {
            "name": "Kiên Long (KIEN LONG BANK)",
            "title": "Kiên Long (KIEN LONG BANK)",
            "nameIcon": "klb",
            "group": "MB"
        },
        {
            "name": "Quốc Dân (NCB)",
            "title": "Quốc Dân (NCB)",
            "nameIcon": "ncb",
            "group": "MB"
        },
        {
            "name": "An Bình (ABBANK)",
            "title": "An Bình (ABBANK)",
            "nameIcon": "abbank",
            "group": "MB"
        },
        {
            "name": "CitiBank",
            "title": "CitiBank",
            "nameIcon": "citibank",
            "group": "MB"
        },
        {
            "name": "HSBC Việt Nam (HSBC)",
            "title": "HSBC Việt Nam (HSBC)",
            "nameIcon": "hsbc",
            "group": "MB"
        },
        {
            "name": "Quốc tế (VIB)",
            "title": "Quốc tế (VIB)",
            "nameIcon": "vib",
            "group": "MB"
        },
        {
            "name": "Nam Á (NAM A BANK)",
            "title": "Nam Á (NAM A BANK)",
            "nameIcon": "nama",
            "group": "MB"
        },
        {
            "name": "Nông Ngiệp Và Phát Triển Nông Thôn Việt Nam",
            "title": "Nông Ngiệp Và Phát Triển Nông Thôn Việt Nam",
            "nameIcon": "agribank",
            "group": "MB"
        },
        {
            "name": "Sài Gòn Thương Tín (SACOMBANK)",
            "title": "Sài Gòn Thương Tín (SACOMBANK)",
            "nameIcon": "sacombank",
            "group": "MB"
        },
        {
            "name": "Sài Gòn Hà Nội (SHB)",
            "title": "Sài Gòn Hà Nội (SHB)",
            "nameIcon": "shb",
            "group": "MB"
        },
        {
            "name": "Đại chúng (PVCOMBANK)",
            "title": "Đại chúng (PVCOMBANK)",
            "nameIcon": "pvcombank",
            "group": "MB"
        },
        {
            "name": "Sài Gòn Công Thương (SAIGONBANK)",
            "title": "Sài Gòn Công Thương (SAIGONBANK)",
            "nameIcon": "saigonbank",
            "group": "MB"
        },
        {
            "name": "Công Thương Việt Nam (VIETINBANK)",
            "title": "Công Thương Việt Nam (VIETINBANK)",
            "nameIcon": "vietinbank",
            "group": "MB"
        },
        {
            "name": "Kỹ Thương Việt Nam (TECHCOMBANK, TCB)",
            "title": "Kỹ Thương Việt Nam (TECHCOMBANK, TCB)",
            "nameIcon": "techcombank",
            "group": "MB"
        },
        {
            "name": "A Châu (ACB)",
            "title": "A Châu (ACB)",
            "nameIcon": "acb",
            "group": "MB"
        },
        {
            "name": "Phát Triển TP.HCM (HD BANK)",
            "title": "Phát Triển TP.HCM (HD BANK)",
            "nameIcon": "exb",
            "group": "MB"
        }
    ],
    TPB: [
        {
            "name": "ANZ BANK",
            "title": "ANZ BANK",
            "nameIcon": "anz",
            "group": "MB"
        },
        {
            "name": "EXIMBANK",
            "title": "EXIMBANK",
            "nameIcon": "exb",
            "group": "MB"
        },
        {
            "name": "VP BANK",
            "title": "VP BANK",
            "nameIcon": "vpbank",
            "group": "MB"
        },
        {
            "name": "BIDV BANK",
            "title": "BIDV BANK",
            "nameIcon": "bidv",
            "group": "MB"
        },
        {
            "name": "MSB BANK",
            "title": "MSB BANK",
            "nameIcon": "msb",
            "group": "MB"
        },
        {
            "name": "SHINHAN BANK",
            "title": "SHINHAN BANK",
            "nameIcon": "shinhanbank",
            "group": "MB"
        },
        {
            "name": "SHB BANK",
            "title": "SHB BANK",
            "nameIcon": "shb",
            "group": "MB"
        },
        {
            "name": "AN BINH BANK",
            "title": "AN BINH BANK",
            "nameIcon": "abbank",
            "group": "MB"
        },
        {
            "name": "SAI GON BANK",
            "title": "SAI GON BANK",
            "nameIcon": "saigonbank",
            "group": "MB"
        },
        {
            "name": "BAC A BANK",
            "title": "BAC A BANK",
            "nameIcon": "babank",
            "group": "MB"
        },
        {
            "name": "HSBC BANK",
            "title": "HSBC BANK",
            "nameIcon": "hsbc",
            "group": "MB"
        },
        {
            "name": "VIETCAPITAL BANK",
            "title": "VIETCAPITAL BANK",
            "nameIcon": "vietcapital",
            "group": "MB"
        },
        {
            "name": "ACB BANK",
            "title": "ACB BANK",
            "nameIcon": "acb",
            "group": "MB"
        },
        {
            "name": "AGRIBANK",
            "title": "AGRIBANK",
            "nameIcon": "agribank",
            "group": "MB"
        },
        {
            "name": "PVCOMBANK",
            "title": "PVCOMBANK",
            "nameIcon": "pvcombank",
            "group": "MB"
        },
        {
            "name": "VCB BANK",
            "title": "VCB BANK",
            "nameIcon": "vcb",
            "group": "MB"
        },
        {
            "name": "TECHCOMBANK",
            "title": "TECHCOMBANK",
            "nameIcon": "techcombank",
            "group": "MB"
        },
        {
            "name": "VIETINBANK",
            "title": "VIETINBANK",
            "nameIcon": "vietinbank",
            "group": "MB"
        },
        {
            "name": "VIET A BANK",
            "title": "VIET A BANK",
            "nameIcon": "vietabank",
            "group": "TPB"
        },
        {
            "name": "NAM A BANK",
            "title": "NAM A BANK",
            "nameIcon": "namabank",
            "group": "TPB"
        },
        {
            "name": "NCB BANK",
            "title": "NCB BANK",
            "nameIcon": "ncb",
            "group": "TPB"
        },
        {
            "name": "KIEN LONG BANK",
            "title": "KIEN LONG BANK",
            "nameIcon": "klb",
            "group": "TPB"
        },
        {
            "name": "BAO VIET BANK",
            "title": "BAO VIET BANK",
            "nameIcon": "bvbank",
            "group": "TPB"
        },
        {
            "name": "MB BANK",
            "title": "MB BANK",
            "nameIcon": "mb",
            "group": "TPB"
        },
        {
            "name": "HD BANK",
            "title": "HD BANK",
            "nameIcon": "hdbank",
            "group": "TPB"
        },
        {
            "name": "CITIBANK",
            "title": "CITIBANK",
            "nameIcon": "citibank",
            "group": "TPB"
        },
        {
            "name": "LIEN VIET POST BANK",
            "title": "LIEN VIET POST BANK",
            "nameIcon": "lvpb",
            "group": "TPB"
        },
        {
            "name": "SCB BANK",
            "title": "SCB BANK",
            "nameIcon": "scbbank",
            "group": "TPB"
        },
        {
            "name": "VIB BANK",
            "title": "VIB BANK",
            "nameIcon": "vib",
            "group": "TPB"
        },
        {
            "name": "OCB BANK",
            "title": "OCB BANK",
            "nameIcon": "ocb",
            "group": "TPB"
        },
        {
            "name": "DONG A BANK",
            "title": "DONG A BANK",
            "nameIcon": "donga",
            "group": "TPB"
        }
    ]
}


// export const arrUrlImage: any =
//     [
//         {
//             name: "VCB",
//             link: "Ngân hàng Quân Đội (MB)"
//         },
//         {
//             name: "TPB",
//             link: "Ngân hàng Đâu tư và phát triển Việt Nam (BIDV)"
//         }
//     ]



