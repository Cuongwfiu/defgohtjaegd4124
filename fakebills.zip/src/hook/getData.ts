import { API_KEY } from "@/config"
import axios from "axios"


export const getCoins = async (token = '') => {
    if (token) {
        try {
           const data= await axios.get(`${API_KEY}/api/get-coins`, {
                headers: {
                    Authorization: token
                }
            })
            return data
        } catch (error:any) {
            return error.response
        }
    } else {
        return undefined
    }

}
export const getName = async (token = '') => {
    if (token) {
        try {
           const data= await axios.get(`${API_KEY}/api/get-name`, {
                headers: {
                    Authorization: token
                }
            })
            return data
        } catch (error:any) {
            return error.response
        }
    } else {
        return undefined
    }

}
export const getListUser = async (tokenAdmin = '') => {
    if (tokenAdmin) {
        try {
           const data= await axios.get(`${API_KEY}/api/get-list-user`, {
                headers: {
                    Authorization: tokenAdmin
                }
            })
            return data
        } catch (error:any) {
            return error.response
        }
    } else {
        return undefined
    }

}
