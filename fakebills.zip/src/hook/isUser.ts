import { API_KEY } from "@/config"
import axios from "axios"



export const isUser = async (token='') =>{
    if(token){
        try {
            await axios.get(`${API_KEY}/api/protected-user`,{
               headers:{
                   Authorization:token
               }
           })
           return 1
       } catch (error) {
           localStorage.removeItem('token')
           return 0
       }
    }else{
        return 0
    }
 
}