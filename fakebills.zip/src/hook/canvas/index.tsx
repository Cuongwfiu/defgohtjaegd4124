import { API_KEY } from "@/config"
import { dataNameBank } from "@/data/fullData"
import React, { useEffect, useRef, useState } from "react"

type Props = {pin?:any, nameMe?: any, name: any, urlImage: any, nameYour: any, SlectBankIng: any, dateTimeNow: any, timeNow: any, content: any, stkYour: any, codeTransaction: any, coin: any, icon?: any, stkMe?: any }

const CanvasTCB = ({ name, urlImage, nameYour, SlectBankIng, dateTimeNow, timeNow, content, stkYour, codeTransaction, coin ,pin}: Props) => {
    const arrDate = dateTimeNow.split(' ')
    const [hours, prefix, day, fullDate] = arrDate
    const [hoursEl, minuteEl] = hours.split(':')
    let hoursFormat = hoursEl && Number(hoursEl) < 10 ? `0${hoursEl}` : `${hoursEl}`
    let minuteFormat = minuteEl && Number(minuteEl) < 10 ? `0${minuteEl}` : `${minuteEl}`
    const [days, month, year] = fullDate.split('/')
    if (name) {
        return (
            <div className="canvasTCB" style={{ width: "100%", height: "100%" }}>

                <img src={`${urlImage}`} alt="" />
                <div className="canvasTCB_pin_hide">
                    <span></span>
                </div>
                <div className="canvasTCB_pin">
                <span style={{ width: `${pin}%`,backgroundColor:`${pin<20?'red':'black'}` }}></span>
                </div>
                <div className="canvasTCB_time"><span>{hoursFormat}:{minuteFormat}</span></div>


                <div className="canvasTCB_content">

                    <div className="canvasTCB_content_name" style={{ top: '27.7%' }}>
                        <span>Chuyển thành công tới {nameYour}</span>
                    </div>
                    <div className="canvasTCB_content_coin"><span>VND {coin} </span></div>
                    <div className="canvasTCB_content_bank">
                        <span>Thông tin chi tiết</span>
                        <span>{SlectBankIng}</span>
                        <span>{stkYour}</span>
                    </div>
                    <div className="canvasTCB_content_description">
                        <span>Lời nhắn</span>
                        <span>{content}</span>
                    </div>
                    <div className="canvasTCB_content_date">
                        <span>Ngày thực hiện</span>
                        <span>{days} tháng {month}, {year}</span>
                    </div>
                    <div className="canvasTCB_content_code">
                        <span>Mã giao dịch</span>
                        <span>{codeTransaction}</span>
                    </div>
                </div>
            </div>
        )
    } else {
        return (
            <div>

            </div>
        )
    }

}
const CanvasVCB = ({ name, urlImage, nameYour, SlectBankIng, dateTimeNow, timeNow, content, stkYour, codeTransaction, coin,pin }: Props) => {
    const arrDate = dateTimeNow.split(' ')
    const [hours, prefix, day, fullDate] = arrDate
    const [hoursEl, minuteEl] = hours.split(':')
    let hoursFormat = hoursEl && Number(hoursEl) < 10 ? `0${hoursEl}` : `${hoursEl}`
    let minuteFormat = minuteEl && Number(minuteEl) < 10 ? `0${minuteEl}` : `${minuteEl}`
    if (name) {
        return (
            <div className="canvasVCB" style={{ width: "100%", height: "100%" }}>

                <img src={`${urlImage}`} alt="" />
                <div className="canvasVCB_pin_hide">
                    <span></span>
                </div>
                <div className="canvasVCB_pin">
                <span style={{ width: `${pin}%`,backgroundColor:`${pin<20?'red':'white'}` }}></span>
                </div>

                <div className="canvasVCB_time"><span>{hoursFormat}:{minuteFormat}</span></div>
                <div className="canvasVCB_coin"><span>{coin} VND</span></div>
                <div className="canvasVCB_fulldate"><span>{dateTimeNow}</span></div>
                <div className="canvasVCB_name" style={{ top: nameYour.length > 18 ? `42%` : '43.5%' }}>
                    <span></span>
                    <span>{nameYour}</span>
                </div>

                <div className="canvasVCB_name" style={{ top: stkYour.length > 20 ? `50.1%` : '50.1%' }}>
                    <span></span>
                    <span>{stkYour}</span>
                </div>

                <div className="canvasVCB_name" style={{ top: SlectBankIng.length > 20 ? `56.6%` : '58.2%' }}>
                    <span></span>
                    <span>{SlectBankIng}</span>
                </div>
                <div className="canvasVCB_name" style={{ top: codeTransaction.length > 19 ? `65.4%` : '66.4%' }}>
                    <span></span>
                    <span>{codeTransaction}</span>
                </div>
                <div className="canvasVCB_name" style={{ top: content.length > 19 ? `72.1%` : '73.4%' }}>
                    <span></span>
                    <span>{content}</span>
                </div>
            </div>
        )
    } else {
        return (
            <div>

            </div>
        )
    }
}

const CanvasMB = ({ name, urlImage, nameYour, SlectBankIng, dateTimeNow, timeNow, content, stkYour, codeTransaction, coin, icon ,pin}: Props) => {
    const arrDate = dateTimeNow.split(' ')
    const [hours, prefix, day, fullDate] = arrDate
    const [hoursEl, minuteEl] = hours.split(':')
    let hoursFormat = hoursEl && Number(hoursEl) < 10 ? `0${hoursEl}` : `${hoursEl}`
    let minuteFormat = minuteEl && Number(minuteEl) < 10 ? `0${minuteEl}` : `${minuteEl}`
    const [days, month, year] = fullDate.split('/')
 
    if (name) {
        return (
            <div className="CanvasMB" style={{ width: "100%", height: "100%" }}>
                <img className="CanvasMB_bg" src={`${urlImage}`} alt="" />
                {icon && <img className="CanvasMB_icon" src={`${API_KEY}/img-data/${name}/${icon}.png`} alt="" />}
                <div className="CanvasMB_pin_hide">
                    <span></span>
                </div>
                <div className="CanvasMB_pin">
                <span style={{ width: `${pin}%`,backgroundColor:`${pin<20?'red':'white'}` }}></span>
                </div>
                <div className="CanvasMB_time"><span>{hoursFormat}:{minuteFormat}</span></div>
                <div className="CanvasMB_coin"><span>{coin} VND</span></div>
                <div className="CanvasMB_name">
                    <span>{nameYour}</span>
                </div>
                <div className="CanvasMB_stk">
                    <span>{stkYour}</span>
                </div>
                <div className="CanvasMB_banking">
                    <span>{SlectBankIng}</span>
                </div>
                <div className="CanvasMB_content">
                    <div >
                        <span>Tài khoản nguồn</span>
                        <span>
                            <div>{stkYour}</div>
                            <div>{nameYour}</div>
                        </span>
                    </div>
                    <div >
                        <span>Nội dung</span>
                        <span>{content}</span>
                    </div>
                    <div >
                        <span>Thời gian</span>
                        <span>{timeNow && timeNow}, {days && days}/{month && month}/{year && year}</span>
                    </div>
                    <div >
                        <span>Hình thức chuyển</span>
                        <span>Chuyển nhanh Napas 247</span>
                    </div>
                    <div >
                        <span>Mã giao dịch</span>
                        <span>{codeTransaction}</span>
                    </div>
                </div>
            </div>
        )
    } else {
        return (
            <div>

            </div>
        )
    }

}

const CanvasTPB = ({ name, urlImage, nameYour, SlectBankIng, dateTimeNow, timeNow, content, stkYour, codeTransaction, coin, icon, stkMe, nameMe,pin }: Props) => {


    const arrDate = dateTimeNow.split(' ')
    const [hours, prefix, day, fullDate] = arrDate
    const [hoursEl, minuteEl] = hours.split(':')
    let hoursFormat = hoursEl && Number(hoursEl) < 10 ? `0${hoursEl}` : `${hoursEl}`
    let minuteFormat = minuteEl && Number(minuteEl) < 10 ? `0${minuteEl}` : `${minuteEl}`
    const [days, month, year] = fullDate.split('/')
    if (name) {
        return (
            <div className="CanvasTPB" style={{ width: "100%", height: "100%" }}>
                <img className="CanvasTPB_bg" src={`${urlImage}`} alt="" />
                <div className="CanvasTPB_pin_hide">
                    <span></span>
                </div>
                <div className="CanvasTPB_pin">
                <span style={{ width: `${pin}%`,backgroundColor:`${pin<20?'red':'white'}` }}></span>
                </div>
                <div className="CanvasTPB_time"><span>{hoursFormat}:{minuteFormat}</span></div>
                {icon && <img className="CanvasTPB_icon" src={`${API_KEY}/img-data/${name}/${icon}.png`} alt="" />}
                <div className="CanvasTPB_coin"><span>{coin} VND</span></div>
                <div className="CanvasTPB_name">
                    <span>{nameMe}</span>
                </div>
                <div className="CanvasTPB_stkMe">
                    <span>{stkMe}</span>
                </div>


                <div className="CanvasTPB_stkYour">
                    <div>
                        <span>{nameYour}</span>
                        <span>Đã lưu</span>
                    </div>
                    <div>
                        <span>{stkYour} </span> 
                        <span>|</span>
                        <span>{SlectBankIng}</span>
                    </div>
                </div>
                <div className="CanvasTPB_codeTransaction">
                    <span>{codeTransaction}</span>
                </div>
                <div className="CanvasTPB_content">
                    <span>{content}</span>
                </div>
                <div className="CanvasTPB_dateTimeNow">
                    <span>{timeNow}, Ngày {days}/{month}/{year}</span>
                </div>
               
            </div>
        )
    } else {
        return (
            <div>

            </div>
        )
    }

}
const Canvas: any = {
    CanvasVCB, CanvasTCB, CanvasMB, CanvasTPB
}
export default Canvas
