

interface Params {
    urlImage: any,
    noidung: any,
    codeTransaction: any,
    nganhang: any,
    tenthuhuong: any,
    thuhuong: any,
    ngaythang: any,
    thoigian: any,
    coin: any,

}

function checkStringOrNumber(str: any) {
    // Sử dụng biểu thức chính quy để kiểm tra xem chuỗi có chứa chữ không
    const containsLetters = /[^\d]/.test(str);
    // Nếu chuỗi có chứa chữ, trả về "string", ngược lại trả về "number"
    return containsLetters ? "string" : "number";
}
// VCB--------------------------------------------------
export const CanvasVCB = ({ urlImage, noidung, codeTransaction, nganhang, tenthuhuong, thuhuong, ngaythang, thoigian, coin }: Params) => {
    let canvas = document.createElement('canvas');
    let context: any = canvas.getContext('2d');
    function whiteEnterText(texts: string, x: number, y: number, maxWidth: number, maxText: number, heightSp: number) {
        context.textAlign = 'right';
        let words = texts.split(' ');
        let line = '';
        const lentStr = texts.length
        for (let i = 0; i < words.length; i++) {
            let testLine = line + words[i] + ' ';
            let metrics = context.measureText(testLine);
            let testWidth = metrics.width;

            if (testWidth > maxWidth && i > 0) {
                if (lentStr >= 43) {
                    y = y - 28
                    heightSp = 55
                } else if (lentStr >= 20) {
                    y = y - 15
                    heightSp = 43
                }
                context.fillText(line.trim(), x, y);
                line = words[i] + ' ';
                y += heightSp;

            } else {
                line = testLine;
                console.log(y);
            }
        }
        if (lentStr >= 43) {
            y = y - 28
        } else if (lentStr >= 20) {
            y = y - 15
        }
        context.fillText(line.trim(), x, y); // Draw the last line
    }
    function customFont(str: any) {
        return str
    }
    function Vechunhat(x: any, y: any, width: any, height: any, radius: any, color: any) {
        context.fillStyle = color
        context.beginPath();
        context.moveTo(x + radius, y);
        context.lineTo(x + width - radius, y);
        context.arcTo(x + width, y, x + width, y + radius, radius);
        context.lineTo(x + width, y + height - radius);
        context.arcTo(x + width, y + height, x + width - radius, y + height, radius);
        context.lineTo(x + radius, y + height);
        context.arcTo(x, y + height, x, y + height - radius, radius)
        context.lineTo(x, y + radius)
        context.arcTo(x, y, x + radius, y, radius)
        context.closePath();
        context.fill();
    }
    const widthImg = 390
    const heightImg = 844
    var img = new Image();
    img.src = urlImage;
    img.onload = function (e) {
        function paint() {

            canvas.width = widthImg;
            canvas.height = heightImg;
            context.drawImage(img, 0, 0, widthImg, heightImg);
            // THời gian
            context.fillStyle = '#0F1C22'
            context.fillRect(15, 10, 70, 30)
            context.fillStyle = 'white'
            context.font = customFont('530 16.5px "Gill Sans","Trebuchet MS", sans-serif')
            context.letterSpacing = 22
            context.fillText(thoigian, 27, 31);

            // Ngày tháng 

            const dateTime = '17:53 Thứ Hai 11/12/2023'
            context.fillStyle = '#0F1C22'
            context.fillRect(113, 295, 170, 20)
            context.fillStyle = '#677074'
            context.font = customFont('600 13.5px "Gill Sans","Trebuchet MS", sans-serif')
            context.letterSpacing = 22
            context.textAlign = 'center'
            context.fillText(ngaythang, widthImg / 2, 313);
            // Tiền
            context.textAlign = 'center';
            context.fillStyle = '#0F1C22'
            context.fillRect(100, 270, 190, 30)
            context.fillStyle = '#70BB02'
            context.font = customFont("530 25.5px system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif")
            context.fillText(coin, widthImg / 2, 288);


            // Tài khoản thụ hưởng 
            context.fillStyle = '#fffffff5'

            context.font = customFont("530 19px system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif")
            whiteEnterText(thuhuong, (widthImg / 2) + 180, 444, 170, 32, 18)

            // Tên người thu hưởng

            context.font = customFont("530 17px system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif")
            whiteEnterText(tenthuhuong, (widthImg / 2) + 180, 384, 170, 32, 18)


            // Tên Ngân hàng thụ hưởng
            context.font = customFont("530 17px system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif")
            whiteEnterText(nganhang, (widthImg / 2) + 180, 511, 190, 46, 22)

            // Tên Ngân hàng thụ hưởng

            context.font = customFont("530 17px system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif")
            whiteEnterText(codeTransaction, (widthImg / 2) + 180, 579, 170, 39, 22)
            // Nội dung
            context.font = customFont("530 17px system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif")
            whiteEnterText(noidung, (widthImg / 2) + 180, 636, 170, 39, 20)

            Vechunhat(354, 20.4, 20, 9, 1, '#0F1C22')

        }
        paint()
        Vechunhat(354, 20.4, 10, 9, 1, 'white')
    }
    return canvas
}
// TCB ------------------------------------------------

export const CanvasTCB = ({ urlImage, noidung, codeTransaction, nganhang, tenthuhuong, thuhuong, ngaythang, thoigian, coin }: Params) => {
    let tenthuhuongtest =0
    const formatNgayThang = ngaythang.split(' ')[3].split('/')
    const strNgayThang = `${formatNgayThang[0]} tháng ${formatNgayThang[1]}, ${formatNgayThang[2]}`
    let canvas = document.createElement('canvas');
    let context: any = canvas.getContext('2d');
    const widthTenThuHuong = context.measureText(tenthuhuong).width
    function whiteEnterText(texts: string, x: number, y: number, maxWidth: number, maxText: number, heightSp: number, textAlign: string, stroke = 0, stkNganahang = '',heightSpace=0) {
        context.lineWidth = stroke && stroke
        context.strokeStyle = 'black'
        context.textAlign = textAlign;
        const findSpace = texts.split(' ')
        let words = texts.split(' ');
        if (findSpace.length > 1) {
            words = texts.split(' ');
        } else {
            words = texts.split('');
        }


        let line = '';
        const lentStr = texts.length
        for (let i = 0; i < words.length; i++) {
            let testLine = line + words[i] + ' ';
            if (findSpace.length > 1) {
                testLine = line + words[i] + ' ';
            } else {
                testLine = line + words[i] + '';
            }
            let metrics = context.measureText(testLine);
            let testWidth = metrics.width;

            if (testWidth > maxWidth && i > 0) {
                if (lentStr >= 43) {
                    y = y - 28
                    heightSp = 50
                } else if (lentStr >= 20) {
                    y = y - 24
                    heightSp = heightSp
                } else {
                    y = y
                }
                if (stroke) {
                    context.strokeText(line.trim(), x, y)
                }

                context.fillText(line.trim(), x, y);
                if (findSpace.length > 1) {
                    line = words[i] + ' ';
                } else {
                    line = words[i] + '';
                }

                y += heightSp;

            } else {
                line = testLine;
            }

        }
        if (lentStr >= 43) {
            y = y - 28
        } else if (lentStr >= 20) {
            y = y
        } else {
            if(widthTenThuHuong>= ((widthImg / 2) - 130)+35){
                if(heightSpace){
                    y = y + heightSpace
                    x= 26
                }else{
                    y = y 
                }
            }else{
                y = y
            }
          
         
        }
        if (stroke) {
            context.strokeText(line.trim(), x, y)
        }
        context.fillText(line.trim(), x, y); // Draw the last line
        for (let i = 0; i < words.length; i++) {
            if (stkNganahang) {
                if ((i + 1) == words.length) {
                    y += 22
                    context.fillText(stkNganahang, x + 1, y);
                }

            }
        }
    }
    function customFont(str: any) {
        return str
    }
    function Vechunhat(x: any, y: any, width: any, height: any, radius: any, color: any) {
        context.fillStyle = color
        context.beginPath();
        context.moveTo(x + radius, y);
        context.lineTo(x + width - radius, y);
        context.arcTo(x + width, y, x + width, y + radius, radius);
        context.lineTo(x + width, y + height - radius);
        context.arcTo(x + width, y + height, x + width - radius, y + height, radius);
        context.lineTo(x + radius, y + height);
        context.arcTo(x, y + height, x, y + height - radius, radius)
        context.lineTo(x, y + radius)
        context.arcTo(x, y, x + radius, y, radius)
        context.closePath();
        context.fill();
    }
    const widthImg = 390
    const heightImg = 844
    var img = new Image();

    img.src = urlImage;
  
    img.onload = function (e) {
        function paint() {
           
        
  
            if(widthTenThuHuong>= ((widthImg / 2) - 130)+35){
                tenthuhuongtest =30
            }

            canvas.width = widthImg;
            canvas.height = heightImg;
            context.drawImage(img, 0, 0, widthImg, heightImg);
            //    context.drawImage(img2,widthResult+80,0,pinWidth-80,pinHeight-40)

            // Tên người thu hưởng
            context.font = customFont("600 30px -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,'Helvetica Neue',Arial,'Noto Sans',sans-serif,'Apple Color Emoji','Segoe UI Emoji','Segoe UI Symbol','Noto Color Emoji'")
            whiteEnterText(tenthuhuong, (widthImg / 2) - 130, 297, widthImg - 69, 32, 18, 'left',0,'',13)






            // THời gian
            context.fillStyle = 'black'
            context.font = customFont("530 16px system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif")
            context.letterSpacing = 22
            context.fillText(thoigian, 27, 29);

            // Ngày tháng 
            context.fillStyle = 'gray'
            context.font = customFont("600 16px -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,'Helvetica Neue',Arial,'Noto Sans',sans-serif,'Apple Color Emoji','Segoe UI Emoji','Segoe UI Symbol','Noto Color Emoji'")
            whiteEnterText('Ngày thực hiện', (widthImg / 2) - 170, (575-27)+tenthuhuongtest, widthImg - 80, 32, 18, 'left', 0)
            context.fillStyle = 'black'

            context.font = customFont("600 16.5px system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif")
            context.letterSpacing = 22
            context.textAlign = 'left'
            context.fillText(strNgayThang, (widthImg / 2) - 171, 575+tenthuhuongtest);
            // Tiền
            context.font = customFont("600 27px -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,'Helvetica Neue',Arial,'Noto Sans',sans-serif,'Apple Color Emoji','Segoe UI Emoji','Segoe UI Symbol','Noto Color Emoji'")
            whiteEnterText('VND', (widthImg / 2) - 168, 331+tenthuhuongtest, widthImg - 168, 32, 18, 'left')

            context.font = customFont("600 27px -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,'Helvetica Neue',Arial,'Noto Sans',sans-serif,'Apple Color Emoji','Segoe UI Emoji','Segoe UI Symbol','Noto Color Emoji'")

            whiteEnterText(coin, (widthImg / 2) - 105, 331+tenthuhuongtest, widthImg - 168, 32, 18, 'left')

            


            // Tên Ngân hàng thụ hưởng
            context.font = customFont("600 27px -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,'Helvetica Neue',Arial,'Noto Sans',sans-serif,'Apple Color Emoji','Segoe UI Emoji','Segoe UI Symbol','Noto Color Emoji'")
            whiteEnterText('VND', (widthImg / 2) - 168, 331+tenthuhuongtest, widthImg - 168, 32, 18, 'left')

            context.fillStyle = 'gray'
            context.font = customFont("600 16px -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,'Helvetica Neue',Arial,'Noto Sans',sans-serif,'Apple Color Emoji','Segoe UI Emoji','Segoe UI Symbol','Noto Color Emoji'")
            whiteEnterText('Thông tin chi tiết', (widthImg / 2) - 170, (409-27)+tenthuhuongtest, widthImg - 80, 32, 18, 'left', 0)
            context.fillStyle = 'black'
            context.font = customFont("600 16px -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,'Helvetica Neue',Arial,'Noto Sans',sans-serif,'Apple Color Emoji','Segoe UI Emoji','Segoe UI Symbol','Noto Color Emoji'")
            whiteEnterText(nganhang, (widthImg / 2) - 170, 409+tenthuhuongtest, widthImg - 80, 32, 18, 'left', 0, thuhuong)

            // whiteEnterText(nganhang, (widthImg / 2) + 180, 511, 190, 46, 22, 'center')
            context.fillStyle = 'gray'
            context.font = customFont("600 16px -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,'Helvetica Neue',Arial,'Noto Sans',sans-serif,'Apple Color Emoji','Segoe UI Emoji','Segoe UI Symbol','Noto Color Emoji'")
            whiteEnterText('Nội dung', (widthImg / 2) - 170, (502-27)+tenthuhuongtest, widthImg - 80, 32, 18, 'left', 0)
            context.fillStyle = 'black'
            context.font = customFont("600 16px -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,'Helvetica Neue',Arial,'Noto Sans',sans-serif,'Apple Color Emoji','Segoe UI Emoji','Segoe UI Symbol','Noto Color Emoji'")
            whiteEnterText(noidung, (widthImg / 2) - 170, 502+tenthuhuongtest, widthImg - 80, 32, 18, 'left', 0)

            // Mã ngân hàng hàng
            context.fillStyle = 'gray'
            context.font = customFont("600 16px -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,'Helvetica Neue',Arial,'Noto Sans',sans-serif,'Apple Color Emoji','Segoe UI Emoji','Segoe UI Symbol','Noto Color Emoji'")
            whiteEnterText('Mã giao diện', (widthImg / 2) - 170, (649-27)+tenthuhuongtest, widthImg - 80, 32, 18, 'left', 0)
            context.fillStyle = 'black'
            context.font = customFont("530 16.5px system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif")
            whiteEnterText(codeTransaction, (widthImg / 2) - 170, 649+tenthuhuongtest, 170, 39, 22, 'left', 0)
            // Nội dung2
          
            // Vechunhat(354, 20.4, 20, 9, 1, '#0F1C22')
        }
        paint()
    }
    return canvas
}

export const arrBill = [
    {
        img: "https://sieutool.com/uploads/656582c26bad7.jpg",
        path: "atm?queryBank=TPB",
        nameBill: "Bill TPBank",
        nameBank: "TPB"
    },
    {
        img: "https://img.mservice.com.vn/momo_app_v2/img/MB.png",
        path: "atm?queryBank=MB",
        nameBill: "Bill MBBank",
        nameBank: "MB"
    },
    {
        img: "https://sieutool.com/uploads/65641e0c46fb9.png",
          path: "atm?queryBank=TCB",
        nameBill: "Bill Techcombank",
        nameBank: "TCB",
    },
    {
        img: "https://sieutool.com/uploads/65621c5c40671.png",
          path: "atm?queryBank=VCB",
        nameBill: "Bill Vietcombank",
        nameBank: "VCB",
    },
];




