import { API_KEY } from "@/config"
import axios from "axios"



export const isAdmin = async (token='') =>{
    if(token){
        try {
         const data=   await axios.get(`${API_KEY}/api/is-admin`,{
               headers:{
                   Authorization:token
               }
           })
           return 1
       } catch (error:any) {
           localStorage.removeItem('tokenAdmin')
           return 0
       }
    }else{
        return 0
    }
 
}