import { API_KEY } from "@/config"
import axios from "axios"
import { useRouter } from "next/router"
import React, { useState } from "react"
const loginAdmin:React.FC = ()=>{
    const [name, setName] = useState<any>('')
    const [password, setPassword] = useState<any>('')
 
    const [render,setRender] = useState<any>(0)
    const router = useRouter()
    return (
        <div className="paddingLogin" >
            <div className="card p-2 snipcss-WObUc">
                <div className="card-body mt-2">
                    <h4 className="mb-2">
                        Chào mừng đến với heyiuu 👋
                    </h4>
                    <p className="mb-4">
                        Vui lòng đăng nhập để tiếp tục
                    </p>
                    <form id="formAuthentication" className="mb-3" action="" method="POST">
                        <div className="form-floating form-floating-outline mb-3">
                            <input onChange={(e)=>{
                                setName(e.target.value);
                            }} type="text" className="form-control" id="username" name="username" placeholder="Tên tài khoản" />
                            {/* <label htmlFor="username">
                                Username
                            </label> */}
                        </div>
                        <div className="mb-3">
                            <div className="form-password-toggle">
                                <div className="input-group input-group-merge">
                                    <div className="form-floating form-floating-outline">
                                        <input onChange={(e)=>{
                                setPassword(e.target.value);
                            }} type="password" id="password" className="form-control" name="password" placeholder="············" aria-describedby="password" />
                                        {/* <label htmlFor="password">
                                            Mật khẩu
                                        </label> */}
                                    </div>

                                </div>
                            </div>
                        </div>

                        <div className="mb-3">
                            <button className="btn btn-primary d-grid w-100 waves-effect waves-light" type="submit" onClick={async(e)=>{
                                     e.preventDefault()
                                     const obj = {
                                         username: name,
                                         password
                                     }
                                     try {
                                         const res = await axios.post(`${API_KEY}/api/login-admin`, obj)
                                         localStorage.setItem('tokenAdmin',res.data.token)
                                        router.push('/admin')
                                     } catch (error: any) {
                                         const errorData = error.response
                                         alert(errorData.data.error)
                                     }
                            }}>
                                Đăng nhập
                            </button>
                        </div>
                    </form>
                    {/* <p className="text-center">
                        <span>
                            Chưa có tài khoản?
                        </span>
                        <a href="register">
                            <span>
                                Tạo tài khoản
                            </span>
                        </a>
                    </p> */}
                </div>
            </div>


        </div>
    )
}
export default loginAdmin