import { API_KEY } from "@/config"
import { getListUser } from "@/hook/getData"
import { isAdmin } from "@/hook/isAdmin"
import axios from "axios"
import React, { useEffect, useState } from "react"
const Admin: React.FC = () => {

    const [activeAdmin, setActiveAdmin] = useState<any>(0)
    const [selectUser, setSelectUser] = useState<any>([])
    const [valueSelected, setValueSelected] = useState<any>('')
    const [indexSelect, setIndexSelected] = useState<any>(-1)
    const [activeUpdate, setActiveUpdate] = useState<any>(0)
    const [coin, setCoin] = useState<any>('')
    useEffect(() => {
        const tokenAdmin: any = localStorage.getItem('tokenAdmin')
        isAdmin(tokenAdmin).then(it => {
            setActiveAdmin(it);
        })
    }, [])

    useEffect(() => {
        if (activeAdmin) {
            const tokenAdmin: any = localStorage.getItem('tokenAdmin')
            try {
                getListUser(tokenAdmin).then(users => {
                    const { data } = users
                    setSelectUser(data);
                })
            } catch (error) {

            }
        } else {
            setSelectUser([])
        }
    }, [activeAdmin])

    if (activeAdmin) {
        return (
            <div style={{ display: "flex", flexDirection: "column", gap: "20px", padding: "0 20px", boxSizing: "border-box" }}>


                <div style={{ display: "flex", gap: "20px", marginTop: "20px" }}>
                    <button onClick={()=>{
                        setActiveUpdate(0)
                    }}  style={{
                        border: "1px solid black",
                        borderRadius: 3,
                        backgroundColor: `${activeUpdate === 0 ? 'black' : 'white'}`,
                        color: `${activeUpdate === 0 ? 'white' : 'black'}`
                    }}>Thêm</button>
                    <button onClick={()=>{
                        setActiveUpdate(1)
                    }} style={{
                        border: "1px solid black",
                        borderRadius: 3,
                        backgroundColor: `${activeUpdate === 0 ? 'white' : 'black'}`,
                        color: `${activeUpdate === 0 ? 'black' : 'white'}`
                    }}>Sửa</button>
                </div>

                <select value={valueSelected} onChange={(e) => {
                    setValueSelected(e.target.value)
                    const targetOption = e.target.options[e.target.options.selectedIndex]
                    setIndexSelected(Number(targetOption.getAttribute('id')))
                }} name="" id="">
                    <option value="" id='-1'>Chọn 1 người bất kì để thêm coin</option>
                    {selectUser && selectUser.map((it: any, index: any) => {
                        return (
                            <option id={index} key={index} value={it.username} >{it.username}</option>
                        )
                    })}
                </select>
                <span style={{ color: "black" }}>Số coin hiện có của người này  {selectUser.length > 0 && selectUser[indexSelect] && selectUser[indexSelect].coin}</span>
                <input value={coin} onChange={(e) => {
                    setCoin(e.target.value)
                }} type="text" placeholder="coin" />
                {activeUpdate===0?   <button onClick={async () => {
                    const coinFormat = Number(coin)
                    const tokenAdmin = localStorage.getItem('tokenAdmin')
                    const obj = {
                        coin: coinFormat,
                        user: valueSelected
                    }
                    try {
                        const res = await axios.post(`${API_KEY}/api/add-coin`, obj, {
                            headers: {
                                Authorization: tokenAdmin
                            }
                        })
                        const { data } = res
                        alert(data.message)
                        setSelectUser(data.arrUser)
                    } catch (error: any) {
                        const responseError: any = error.response
                        alert(responseError.data.error);
                    }
                }} style={{ border: "none", backgroundColor: "#126d18d9", color: "white", padding: "10px", borderRadius: 10 }}>Thêm</button>
                :
                <button onClick={async () => {
                    const coinFormat = Number(coin)
                    const tokenAdmin = localStorage.getItem('tokenAdmin')
                    const obj = {
                        coin: coinFormat,
                        user: valueSelected
                    }
                    try {
                        const res = await axios.post(`${API_KEY}/api/update-coin`, obj, {
                            headers: {
                                Authorization: tokenAdmin
                            }
                        })
                        const { data } = res
                        alert(data.message)
                        setSelectUser(data.arrUser)
                    } catch (error: any) {
                        const responseError: any = error.response
                        alert(responseError.data.error);
                    }
                }} style={{ border: "none", backgroundColor: "#B22222", color: "white", padding: "10px", borderRadius: 10 }}>Sửa</button>
                }
             
            </div>
        )
    } else {
        return (
            <></>
        )
    }

}
export default Admin