
import { arrBill } from "@/hook/createCanvas";
import { getCoins, getName } from "@/hook/getData";
import { isUser } from "@/hook/isUser";
import Link from "next/link";
import { useRouter } from "next/router";
import { useEffect, useState } from "react"


const Home: React.FC = () => {
  const [renderLogin, setRenderLogin] = useState<any>(2)
  const router = useRouter()
  const [names, setName] = useState<any>('')
  const [coins, setCoin] = useState<any>('')
  const [screen, setScreen] = useState<any>(0)
  useEffect(() => {
    const token: any = localStorage.getItem('token')
    if (window.innerWidth > 800) {
      setScreen(1)
    } else {
      setScreen(0)
    }
    getName(token).then(res => {
      try {
        const { data } = res
        const { name } = data
        setName(name)
      } catch (error) {
        console.log(error);
      }
    })
    getCoins(token).then(res => {
      try {
        const { data } = res
        const { coin } = data
        setCoin(coin)
      } catch (error) {
        console.log(error);
      }
    })


    isUser(token).then(it => {
      if (it === 1) {
        setRenderLogin(it)
      } else {
        setRenderLogin(it)
      }
    })
  }, [router])


  const html_brand = ` <a href="/" class="app-brand-link snipcss0-6-23-24">
  <span class="app-brand-logo demo snipcss0-7-24-25">
      <svg width="25" viewBox="0 0 25 42" version="1.1" xmlns="http://www.w3.org/2000/svg"
          xmlns:xlink="http://www.w3.org/1999/xlink" class="snipcss0-8-25-26">
          <defs class="snipcss0-9-26-27">
              <path
                  d="M13.7918663,0.358365126 L3.39788168,7.44174259 C0.566865006,9.69408886 -0.379795268,12.4788597 0.557900856,15.7960551 C0.68998853,16.2305145 1.09562888,17.7872135 3.12357076,19.2293357 C3.8146334,19.7207684 5.32369333,20.3834223 7.65075054,21.2172976 L7.59773219,21.2525164 L2.63468769,24.5493413 C0.445452254,26.3002124 0.0884951797,28.5083815 1.56381646,31.1738486 C2.83770406,32.8170431 5.20850219,33.2640127 7.09180128,32.5391577 C8.347334,32.0559211 11.4559176,30.0011079 16.4175519,26.3747182 C18.0338572,24.4997857 18.6973423,22.4544883 18.4080071,20.2388261 C17.963753,17.5346866 16.1776345,15.5799961 13.0496516,14.3747546 L10.9194936,13.4715819 L18.6192054,7.984237 L13.7918663,0.358365126 Z"
                  id="path-1">
              </path>
              <path
                  d="M5.47320593,6.00457225 C4.05321814,8.216144 4.36334763,10.0722806 6.40359441,11.5729822 C8.61520715,12.571656 10.0999176,13.2171421 10.8577257,13.5094407 L15.5088241,14.433041 L18.6192054,7.984237 C15.5364148,3.11535317 13.9273018,0.573395879 13.7918663,0.358365126 C13.5790555,0.511491653 10.8061687,2.3935607 5.47320593,6.00457225 Z"
                  id="path-3">
              </path>
              <path
                  d="M7.50063644,21.2294429 L12.3234468,23.3159332 C14.1688022,24.7579751 14.397098,26.4880487 13.008334,28.506154 C11.6195701,30.5242593 10.3099883,31.790241 9.07958868,32.3040991 C5.78142938,33.4346997 4.13234973,34 4.13234973,34 C4.13234973,34 2.75489982,33.0538207 2.37032616e-14,31.1614621 C-0.55822714,27.8186216 -0.55822714,26.0572515 -4.05231404e-15,25.8773518 C0.83734071,25.6075023 2.77988457,22.8248993 3.3049379,22.52991 C3.65497346,22.3332504 5.05353963,21.8997614 7.50063644,21.2294429 Z"
                  id="path-4">
              </path>
              <path
                  d="M20.6,7.13333333 L25.6,13.8 C26.2627417,14.6836556 26.0836556,15.9372583 25.2,16.6 C24.8538077,16.8596443 24.4327404,17 24,17 L14,17 C12.8954305,17 12,16.1045695 12,15 C12,14.5672596 12.1403557,14.1461923 12.4,13.8 L17.4,7.13333333 C18.0627417,6.24967773 19.3163444,6.07059163 20.2,6.73333333 C20.3516113,6.84704183 20.4862915,6.981722 20.6,7.13333333 Z"
                  id="path-5">
              </path>
          </defs>
          <g id="g-app-brand" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"
              class="snipcss0-9-26-28">
              <g id="Brand-Logo" transform="translate(-27.000000, -15.000000)"
                  class="snipcss0-10-28-29">
                  <g id="Icon" transform="translate(27.000000, 15.000000)"
                      class="snipcss0-11-29-30">
                      <g id="Mask" transform="translate(0.000000, 8.000000)"
                          class="snipcss0-12-30-31">
                          <mask id="mask-2" fill="white" class="snipcss0-13-31-32">
                              <use xlink:href="#path-1" class="snipcss0-14-32-33">
                              </use>
                          </mask>
                          <use fill="#696cff" xlink:href="#path-1" class="snipcss0-13-31-34">
                          </use>
                          <g id="Path-3" mask="url(#mask-2)" class="snipcss0-13-31-35">
                              <use fill="#696cff" xlink:href="#path-3"
                                  class="snipcss0-14-35-36">
                              </use>
                              <use fill-opacity="0.2" fill="#FFFFFF" xlink:href="#path-3"
                                  class="snipcss0-14-35-37">
                              </use>
                          </g>
                          <g id="Path-4" mask="url(#mask-2)" class="snipcss0-13-31-38">
                              <use fill="#696cff" xlink:href="#path-4"
                                  class="snipcss0-14-38-39">
                              </use>
                              <use fill-opacity="0.2" fill="#FFFFFF" xlink:href="#path-4"
                                  class="snipcss0-14-38-40">
                              </use>
                          </g>
                      </g>
                      <g id="Triangle"
                          transform="translate(19.000000, 11.000000) rotate(-300.000000) translate(-19.000000, -11.000000) "
                          class="snipcss0-12-30-41">
                          <use fill="#696cff" xlink:href="#path-5" class="snipcss0-13-41-42">
                          </use>
                          <use fill-opacity="0.2" fill="#FFFFFF" xlink:href="#path-5"
                              class="snipcss0-13-41-43">
                          </use>
                      </g>
                  </g>
              </g>
          </g>
      </svg>
  </span>
  <span class="app-brand-text demo menu-text fw-bolder ms-2 snipcss0-7-24-44">
      FakeBill
  </span>
</a>
<a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-xl-none snipcss0-6-23-45">
  <i class="bx bx-chevron-left bx-sm align-middle snipcss0-7-45-46">
  </i>
</a>`
  return (

    <div className="snipcss0-1-1-19 snipcss-OMNLU">

      <div className="layout-wrapper layout-content-navbar snipcss0-2-19-20">
        <div className="layout-container snipcss0-3-20-21">
          {Boolean(screen) && <aside id="layout-menu" className="layout-menu menu-vertical menu bg-menu-theme snipcss0-4-21-22">
            <div className="app-brand demo snipcss0-5-22-23" dangerouslySetInnerHTML={{ __html: html_brand }}>
            </div>
            <div className="menu-inner-shadow snipcss0-5-22-47">
            </div>
            <ul className="menu-inner py-1 ps snipcss0-5-22-48">
              <li className="menu-item active snipcss0-6-48-49">
                <a href="/" className="menu-link snipcss0-7-49-50">
                  <i className="menu-icon tf-icons bx bx-home-circle snipcss0-8-50-51">
                  </i>
                  <div data-i18n="Analytics" className="snipcss0-8-50-52">
                    Fake bill CK
                  </div>
                </a>
              </li>
              <li className="menu-item snipcss0-6-48-53">
                <a href="#" target="_blank" className="menu-link snipcss0-7-53-54">
                  <i className="menu-icon tf-icons bx bx-support snipcss0-8-54-55">
                  </i>
                  <div data-i18n="Support" className="snipcss0-8-54-56">
                    Liên hệ admin
                  </div>
                </a>
              </li>
              <div className="ps__rail-x snipcss0-6-48-57 style-3kqvo" id="style-3kqvo">
                <div className="ps__thumb-x snipcss0-7-57-58 style-wpk6t" tabIndex={0} id="style-wpk6t">
                </div>
              </div>
              <div className="ps__rail-y snipcss0-6-48-59 style-4JR7l" id="style-4JR7l">
                <div className="ps__thumb-y snipcss0-7-59-60 style-GqmxB" tabIndex={0} id="style-GqmxB">
                </div>
              </div>
            </ul>
          </aside>}

          <div className="layout-page snipcss0-4-21-61">
            <div className="content-wrapper snipcss0-5-61-62">
              <div className="container-xxl flex-grow-1 container-p-y snipcss0-6-62-63">
                <div className="row snipcss0-7-63-64">
                  <div className="col-lg-8 mb-4 order-0 snipcss0-8-64-65">
                    <div className="card snipcss0-9-65-66">
                      <div className="d-flex ">
                        <div className="col-sm-7 snipcss0-11-67-68">
                          <div className="card-body snipcss0-12-68-69">
                            <h5 className="card-title text-primary snipcss0-13-69-70">
                              FakeBill 🎉
                            </h5>
                            <p className="mb-4 snipcss0-13-69-71">
                              Website fake bill giá rẻ số 1 thị trường
                            </p>
                            {!screen&&  <a style={{color:"black"}} href="#" target="_blank" className="menu-link snipcss0-7-53-54">
                              <i className="menu-icon tf-icons bx bx-support snipcss0-8-54-55">
                              </i>
                              <div data-i18n="Support" className="snipcss0-8-54-56">
                                Liên hệ admin
                              </div>
                            </a>}
                          
                          </div>

                        </div>
                        <div className="col-sm-5 text-center text-sm-left snipcss0-11-67-72">
                          <div className="card-body pb-0 px-0 px-md-4 snipcss0-12-72-73">
                            <img src="https://fakebillgiare.fun/assets/img/illustrations/man-with-laptop-light.png" height="140" alt="View Badge User" data-app-dark-img="illustrations/man-with-laptop-dark.png" data-app-light-img="illustrations/man-with-laptop-light.png" className="snipcss0-13-73-74" />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  {renderLogin === 0 ? <>   <div style={{ fontWeight: 600 }} className="alert alert-danger snipcss0-8-64-75">
                    Bạn phải đăng nhập trước khi fake bill
                  </div></> : renderLogin === 1 ? <>
                  </> : <></>}


                  <p style={{ display: "flex", gap: "10px" }} className="snipcss0-8-64-76">
                    {renderLogin === 0 ? <>  <Link href="/login" style={{ fontFamily: "inherit" }} className="btn btn-primary snipcss0-9-76-77">
                      Đăng nhập
                    </Link>
                      <Link href="register" style={{ fontFamily: "inherit" }} className="btn btn-success snipcss0-9-76-78">
                        Đăng ký
                      </Link></> : renderLogin === 1 ? <div style={{ display: "flex", alignItems: "flex-start", gap: "10px" }}>  <Link onClick={() => {
                        localStorage.removeItem('token')
                      }} href={'/'} style={{ fontFamily: "inherit", backgroundColor: "red", color: "white" }} className="btn snipcss0-9-76-77">
                        Đăng xuất
                      </Link>   <div style={{ display: "flex", flexDirection: "column" }}>
                          <span className="nameStyle" style={{ color: "#DC143C", fontWeight: 600, fontSize: 20 }}>Chào bạn {names}</span>
                          <span className="nameStyle" style={{ color: "#4B0082", fontWeight: 600 }}>Số tiền hiện có: {coins}</span>
                        </div>
                      </div> : <></>}

                  </p>
                  <div className="col-12 col-md-12 col-lg-12 order-3 order-md-2 snipcss0-8-64-79">
                    <div className="flex-custom" style={{ gridTemplateColumns: `${screen ? 'repeat(4,1fr)' : 'repeat(2,1fr)'}` }}>
                      {arrBill.map((item: any, index: any) => {
                        return (
                          <div className="flex-custom_it" key={index} >
                            <div className="card snipcss0-11-81-82">
                              <div className="card-body snipcss0-12-82-83">
                                <div className="card-title d-flex align-items-start justify-content-between snipcss0-13-83-84">
                                  <div className="avatar flex-shrink-0 snipcss0-14-84-85">
                                    <img src={item.img} alt="Credit Card" />
                                  </div>
                                </div>
                                <span className="d-block mb-1 snipcss0-13-83-87">
                                  {item.nameBill}
                                </span>
                                <Link style={{ fontWeight: 600, fontFamily: "inherit" }} href={item.path} className="btn btn-primary snipcss0-13-83-88">
                                  Tạo bill 20,000/bill
                                </Link>
                              </div>
                            </div>
                          </div>
                        )
                      })}










                    </div>
                  </div>
                </div>
                <div className="row snipcss0-7-63-193">
                </div>
              </div>
              <div className="content-backdrop fade snipcss0-6-62-194 style-r8zfa" id="style-r8zfa">
              </div>
            </div>
          </div>
        </div>
        <div className="layout-overlay layout-menu-toggle snipcss0-3-20-195">
        </div>
      </div>




    </div>
  );






}


export default Home
