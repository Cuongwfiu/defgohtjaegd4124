import React, { useEffect, useRef, useState } from "react"
import moment from "moment"
import axios from "axios"
import { API_KEY } from "@/config";
import { dataNameBank } from "@/data/fullData";
import { useRouter } from "next/router";
import ReactDomServer from "react-dom/server";
import Canvas from "../../hook/canvas";
import html2Canvas from 'html2canvas'
import { isUser } from "@/hook/isUser";
require('moment/locale/vi');
const Atm: React.FC = () => {





    const formatNumberWithCommas = (number: number): string => {
        return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    };
    const router = useRouter()
    const { query } = router
    const { queryBank }: any = query
    const now = moment(); // Lấy thời gian hiện tại
    const hours = now.hours(); // Lấy giờ
    const minutes = now.minutes(); // Lấy phút
    const seconds = now.seconds(); // Lấy giây
    const dayOfWeek = now.format('dddd');
    const capitalizedDayOfWeek = dayOfWeek
        .toLowerCase()
        .replace(/(^|\s)\S/g, (match) => match.toUpperCase());
    const dayOfMonth = now.date(); // Lấy ngày trong tháng
    const month = now.format('MM'); // Lấy tên tháng
    const year = now.year(); // Lấy năm
    const renderCanvas = useRef<any>(null)
    // const [canvasEl, setCanvalEl] = useState<any>(null)
    const [iconBanking, setIconBanking] = useState<any>('techcombank')
    const [blobImage, setBlobImage] = useState<any>('')


    const [nameMe, setNameMe] = useState<any>('')
    const [stkMe, setStkMe] = useState<any>('')
    const [stkYour, setStkYour] = useState<any>('')
    const [SlectBankIng, setSelectBanking] = useState<any>('')
    const [nameYour, setNameYour] = useState<any>('')
    const [coin, setCoin] = useState<any>('')
    const [content, setContent] = useState<any>('')
    const [codeTransaction, setCodeTransaction] = useState<any>('')

    const [timeNow, setTimeNow] = useState<any>(``)
    const [dateTimeNow, setDateTimeNow] = useState<any>(`${hours}:${minutes} ${capitalizedDayOfWeek} ${dayOfMonth}/${month}/${year}`)
    useEffect(() => {
     


        setTimeNow(`${hours}:${minutes}:${seconds}`)
        axios.get(`${API_KEY}/image-bill/${queryBank}`, { responseType: 'arraybuffer' }).then((response) => {
            const newBlob = new Blob([response.data], { type: response.headers['content-type'] });
            const urlBlob = URL.createObjectURL(newBlob);
            setBlobImage(urlBlob)
        })
        // if (Boolean(canvasEl)) {
        //     renderCanvas.current.innerHTML = ''
        //     canvasEl.style = 'width:calc(100% + 50px)'
        //     renderCanvas.current.appendChild(canvasEl)
        // }
    }, [])
    const [download, setDownload] = useState<any>(0)
    const iphone12pro = [390, 844]
    const [pin, setPin] = useState<any>(50)
    return (
        <div className="main_ATM">
            <div className="main_ATM_boxshadow">
                <div className="card mb-4">
                    <div className="cardAtm">
                        <div className="customatm">
                            <div className="customatm_item">
                                <form className="" method="POST" action="">
                                    <h1 style={{ color: "black" }}>{queryBank}</h1>
                                    <div id="namegui" className="row mb-3">
                                        <label className="col-sm-3 col-form-label" htmlFor="form-alignment-username">
                                            Tên bạn
                                        </label>
                                        <div className="col-sm-9">
                                            <input onChange={(e) => {
                                                setNameMe(e.target.value);
                                            }} type="text" id="name_gui" name="name_gui" className="form-control" placeholder="Tên người gửi" value={nameMe} />
                                        </div>
                                    </div>
                                    <div id="stkgui" className="row mb-3">
                                        <label className="col-sm-3 col-form-label" htmlFor="form-alignment-username">
                                            STK bạn
                                        </label>
                                        <div className="col-sm-9">
                                            <input onChange={(e) => {
                                                setStkMe(e.target.value);
                                            }} type="text" id="stk_gui" name="stk_gui" className="form-control" placeholder="STK người gửi" value={stkMe} />
                                        </div>
                                    </div>
                                    <div id="bank1" className="row mb-3">
                                        <label className="col-sm-3 col-form-label" htmlFor="form-alignment-username">
                                            Chuyển đến
                                        </label>
                                        <div className="col-sm-9">
                                            <select value={SlectBankIng} onChange={(e: any) => {
                                                const value = e.target.value
                                                const selectedOption = e.target.options[e.target.selectedIndex];
                                                const selectedId = selectedOption.getAttribute('id');
                                                if (selectedId) {
                                                    setIconBanking(selectedId)
                                                }
                                                setSelectBanking(value)
                                            }} required={true} name="bank" className="form-control" >
                                                <option value={''}>
                                                    Vui lòng chọn 1 ngân hàng
                                                </option>
                                                {queryBank && dataNameBank[queryBank] && dataNameBank[queryBank].map((item: any, index: any) => {
                                                    return (
                                                        <option key={index} value={item.title} id={item && item.nameIcon}>
                                                            {item.name}
                                                        </option>
                                                    )
                                                })}
                                            </select>
                                        </div>
                                    </div>

                                    <div className="row mb-3">
                                        <label className="col-sm-3 col-form-label" htmlFor="form-alignment-username">
                                            STK nhận
                                        </label>
                                        <div className="col-sm-9">
                                            <input onChange={(e) => {
                                                setStkYour(e.target.value);
                                            }} type="text" id="stk" name="stk" required={true} className="form-control" placeholder="Số tài khoản người nhận" value={stkYour} />
                                        </div>
                                    </div>
                                    <div className="row mb-3">
                                        <label className="col-sm-3 col-form-label" htmlFor="form-alignment-username">
                                            Tên người nhận
                                        </label>
                                        <div className="col-sm-9">
                                            <input onChange={(e) => {
                                                setNameYour(e.target.value);
                                            }} type="text" id="name_nhan" name="name_nhan" required={true} className="form-control" placeholder="Tên người nhận " value={nameYour} />
                                        </div>
                                    </div>
                                    <div className="row mb-3">
                                        <label className="col-sm-3 col-form-label" htmlFor="form-alignment-username">
                                            Số tiền chuyển
                                        </label>
                                        <div className="col-sm-9">
                                            <input onChange={(e: any) => {

                                                setCoin(Number(e.target.value));
                                            }} type="text" id="amount" name="amount" required={true} className="form-control" value={coin} placeholder="Ví dụ: 100000" />
                                        </div>
                                    </div>
                                    <div className="row mb-3">
                                        <label className="col-sm-3 col-form-label" htmlFor="form-alignment-username">
                                            Nội dung chuyển khoản
                                        </label>
                                        <div className="col-sm-9">
                                            <textarea onChange={(e) => {
                                                setContent(e.target.value);
                                            }} typeof="text" id="noidung" name="noidung" required={true} className="form-control" placeholder="Nhập nội dung CK" value={content} />

                                        </div>
                                    </div>
                                    <div className="row mb-3" id="magiaodichx">
                                        <label className="col-sm-3 col-form-label" htmlFor="form-alignment-username">
                                            Mã giao dịch
                                        </label>
                                        <div className="col-sm-9">
                                            <input onChange={(e) => {
                                                setCodeTransaction(e.target.value);
                                            }} type="text" id="magiaodich" name="magiaodich" className="form-control" placeholder="Mã giao dịch" value={codeTransaction} />
                                        </div>
                                    </div>
                                    <div>Thời gian: Giờ/Phút/Giây</div>
                                    <div className="row mb-3">
                                        <label className="col-sm-3 col-form-label" htmlFor="form-alignment-username">
                                            Thời gian trên điện thoại
                                        </label>
                                        <div className="col-sm-9">
                                            <input onChange={(e) => {
                                                setTimeNow(e.target.value);
                                            }} type="text" id="time" name="time" required={true} className="form-control" placeholder="Time" value={timeNow} />
                                        </div>
                                    </div>
                                    <div>Thời gian bill: Giờ/Phút - Thứ trong tuần - Ngày/Tháng/Năm</div>
                                    <div className="row mb-3">
                                        <label className="col-sm-3 col-form-label" htmlFor="form-alignment-username">
                                            Thời gian trên bill
                                        </label>
                                        <div className="col-sm-9">
                                            <input onChange={(e) => {
                                                setDateTimeNow(e.target.value);
                                            }} type="text" id="time1" name="time1" required={true} className="form-control" placeholder="Time" value={dateTimeNow} />
                                        </div>
                                    </div>
                                    <div className="row mb-3">
                                        <label className="col-sm-3 col-form-label" htmlFor="form-alignment-username">
                                            Chỉnh pin điện thoại
                                        </label>
                                        <div className="container-pin">
                                            <div className="range-slider-pin">
                                                <span id="rs-bullet-pin" className="rs-label-pin">{pin}% pin</span>
                                                <input onChange={(e: any) => {
                                                    setPin(e.target.value);
                                                }} id="rs-range-line-pin" className="rs-range-pin" type="range" value={pin} min={0} max={100} />

                                            </div>

                                            <div className="box-minmax-pin">
                                                <span>0</span><span>100</span>
                                            </div>

                                        </div>
                                    </div>

                                    {/* <div className="row mb-3">
                                        <label className="col-sm-3 col-form-label" htmlFor="form-alignment-username">
                                            Giao diện app
                                        </label>
                                        <div className="col-sm-9">
                                            <div className="row">
                                                <div className="col-6 mb-md-0 mb-2">
                                                    <div className="form-check custom-option custom-option-image custom-option-image-radio">
                                                        <label className="form-check-label custom-option-content" htmlFor="theme1">
                                                            <span className="custom-option-body">
                                                                <img src="https://sieutool.com/uploads/656ab43cef9a5.jpg" alt="radioImg" id="style-aIhbT" className="style-aIhbT" />
                                                            </span>
                                                        </label>
                                                        <input name="theme" className="form-check-input" type="radio" value="1" id="theme1" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div> */}
                                    {/* <div className="row mb-3">
                                        <label className="col-sm-3 col-form-label" htmlFor="form-alignment-username">
                                            Phần trăm pin
                                        </label>
                                        <div className="col-sm-9">
                                            <div className="row">
                                                <div className="col-md-12 mb-md-0 mb-2">
                                                    <div className="form-check custom-option custom-option-image custom-option-image-radio">
                                                        <label className="form-check-label custom-option-content" htmlFor="pin1">
                                                            <span className="custom-option-body">
                                                                <img src="https://sieutool.com/uploads/6563e6d72d403.png" alt="radioImg" id="style-kqWbe" className="style-kqWbe" />
                                                            </span>
                                                        </label>
                                                        <input name="pin" className="form-check-input" type="radio" value="pin1" id="pin1" />
                                                    </div>
                                                </div>
                                                <div className="col-md-12 mb-md-0 mb-2">
                                                    <div className="form-check custom-option custom-option-image custom-option-image-radio">
                                                        <label className="form-check-label custom-option-content" htmlFor="pin3">
                                                            <span className="custom-option-body">
                                                                <img src="https://sieutool.com/uploads/6563e6e0e1e58.png" alt="radioImg" id="style-kVtSL" className="style-kVtSL" />
                                                            </span>
                                                        </label>
                                                        <input name="pin" className="form-check-input" type="radio" value="pin3" id="pin3" />
                                                    </div>
                                                </div>
                                                <div className="col-md-12 mb-md-0 mb-2">
                                                    <div className="form-check custom-option custom-option-image custom-option-image-radio">
                                                        <label className="form-check-label custom-option-content" htmlFor="pin4">
                                                            <span className="custom-option-body">
                                                                <img src="https://sieutool.com/uploads/6563e6e8a5030.png" alt="radioImg" id="style-YaRvm" className="style-YaRvm" />
                                                            </span>
                                                        </label>
                                                        <input name="pin" className="form-check-input" type="radio" value="pin4" id="pin4" />
                                                    </div>
                                                </div>
                                                <div className="col-md-12 mb-md-0 mb-2">
                                                    <div className="form-check custom-option custom-option-image custom-option-image-radio">
                                                        <label className="form-check-label custom-option-content" htmlFor="pin5">
                                                            <span className="custom-option-body">
                                                                <img src="https://sieutool.com/uploads/6563e6fc036fd.png" alt="radioImg" id="style-oYdac" className="style-oYdac" />
                                                            </span>
                                                        </label>
                                                        <input name="pin" className="form-check-input" type="radio" value="pin5" id="pin5" />
                                                    </div>
                                                </div>
                                                <div className="col-md-12 mb-md-0 mb-2">
                                                    <div className="form-check custom-option custom-option-image custom-option-image-radio">
                                                        <label className="form-check-label custom-option-content" htmlFor="pin6">
                                                            <span className="custom-option-body">
                                                                <img src="https://sieutool.com/uploads/6563e708c548f.png" alt="radioImg" id="style-OPeES" className="style-OPeES" />
                                                            </span>
                                                        </label>
                                                        <input name="pin" className="form-check-input" type="radio" value="pin6" id="pin6" />
                                                    </div>
                                                </div>
                                                <div className="col-md-12 mb-md-0 mb-2">
                                                    <div className="form-check custom-option custom-option-image custom-option-image-radio">
                                                        <label className="form-check-label custom-option-content" htmlFor="pin7">
                                                            <span className="custom-option-body">
                                                                <img src="https://sieutool.com/uploads/6563e711d2fdb.png" alt="radioImg" id="style-3KzsK" className="style-3KzsK" />
                                                            </span>
                                                        </label>
                                                        <input name="pin" className="form-check-input" type="radio" value="pin7" id="pin7" />
                                                    </div>
                                                </div>
                                                <div className="col-md-12 mb-md-0 mb-2">
                                                    <div className="form-check custom-option custom-option-image custom-option-image-radio">
                                                        <label className="form-check-label custom-option-content" htmlFor="pin2">
                                                            <span className="custom-option-body">
                                                                <img src="https://sieutool.com/uploads/6563e71983409.png" alt="radioImg" id="style-GxJxk" className="style-GxJxk" />
                                                            </span>
                                                        </label>
                                                        <input name="pin" className="form-check-input" type="radio" value="pin2" id="pin2" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div> */}
                                    <div className="d-grid">
                                        <button type="submit" onClick={async (e: any) => {
                                            e.preventDefault();
                                            const token = localStorage.getItem('token');
                                            if (token) {
                                                const resIsUser = await isUser(token)
                                                if (resIsUser) {
                                                    try {
                                                        const resBill = await axios.put(`${API_KEY}/api/buy-bill`, {
                                                            typeBill: "ck",
                                                        }, {
                                                            headers: {
                                                                Authorization: token
                                                            }
                                                        })
                                                        alert(resBill.data.message);
                                                        if (resBill.data.message === 'Số tiền của bạn không đủ vui lòng liên hệ admin.') {
                                                            setDownload(0)
                                                        } else {
                                                            setDownload(1)
                                                        }
                                                    } catch (error: any) {
                                                        // localStorage.removeItem('token');
                                                    }
                                                } else {
                                                    alert('Vui lòng đăng nhập')
                                                }
                                            } else {
                                                alert('Vui lòng đăng nhập')
                                            }


                                            const htmlString = ReactDomServer.renderToString(Canvas[`Canvas${queryBank}`]({
                                                name: queryBank,
                                                urlImage: blobImage,
                                                nameYour: nameYour.toUpperCase(),
                                                SlectBankIng: SlectBankIng,
                                                dateTimeNow: dateTimeNow,
                                                timeNow: timeNow,
                                                content: content,
                                                stkYour: stkYour,
                                                codeTransaction: codeTransaction,
                                                coin: formatNumberWithCommas(coin),
                                                stkMe: stkMe,
                                                icon: iconBanking,
                                                nameMe, pin
                                            }))
                                            const divEl: any = document.createElement('div');
                                            divEl.style = `width: ${iphone12pro[0]}px; height: ${iphone12pro[1]}px`
                                            divEl.innerHTML = htmlString
                                            document.body.appendChild(divEl)
                                            const canvasToHTML2 = await html2Canvas(divEl, { useCORS: true, scale: 2 })
                                            renderCanvas.current.innerHTML = ''
                                            renderCanvas.current.appendChild(canvasToHTML2)
                                            document.body.removeChild(divEl)
                                        }} className="btn btn-primary waves-effect waves-light mt-3">
                                            Tạo bill (20,000đ)
                                        </button>

                                    </div>

                                </form>
                                {Boolean(download) && <button onClick={() => {
                                    const canvas = renderCanvas.current.querySelector('canvas')
                                    const urlCanvas = canvas.toDataURL()
                                    const aEl = document.createElement('a')
                                    aEl.href = urlCanvas
                                    aEl.download = ''
                                    document.body.appendChild(aEl)
                                    aEl.click()
                                    document.body.removeChild(aEl)
                                }} style={{ margin: "5px", color: "white", border: "none", borderRadius: 5, padding: 5, backgroundColor: '#800000' }}>Tải xuống</button>}
                            </div>
                            <div ref={renderCanvas} className="customatm_item">
                                <h4>
                                    Hình ảnh mô tả
                                </h4>
                                <div style={{ width: iphone12pro[0], height: iphone12pro[1] }}>
                                    {Canvas[`Canvas${queryBank}`]({
                                        name: queryBank,
                                        urlImage: blobImage,
                                        nameYour: 'NGUYEN MINH PHUONG',
                                        SlectBankIng: 'Ngan hang ABC',
                                        dateTimeNow: dateTimeNow,
                                        timeNow: timeNow,
                                        content: 'NGUYEN THE ANH CK',
                                        stkYour: '0376287894',
                                        codeTransaction: '0312312030',
                                        coin: '1,000,000',
                                        stkMe: '0246286594',
                                        icon: iconBanking,
                                        nameMe: 'NGUYEN THE ANH',
                                        pin
                                    })}
                                </div>
                            </div>

                        </div>




                    </div>
                </div>
            </div>
        </div>

    )
}


export async function getServerSideProps() {

    return {
        props: {
            data: '23'
        }
    }
}
export default Atm