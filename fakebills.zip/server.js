const express = require('express');
const cors = require('cors')
const bodyParser = require('body-parser')
const fs = require('fs')
const path = require('path')
const jwt = require('jsonwebtoken');
const { parse } = require('url')
const bcrypt = require('bcrypt');
const app = express()
const next = require('next')




const appNext = next({ dev: false })
const handlerNextApp = appNext.getRequestHandler()




appNext.prepare().then(() => {
    app.use(cors({
        origin: "*"
    }))

    app.use(bodyParser.urlencoded({ extended: true }))
    app.use(bodyParser.json())


    app.use('/img-data', express.static(path.join(__dirname, 'backend', 'icon')))


    app.get('/image-bill/:name', (req, res) => {
        const name = req.params.name
        const findFile = fs.existsSync(`${__dirname}/backend/image/${name}.png`)
        if (findFile) {
            res.sendFile(`${__dirname}/backend/image/${name}.png`)
        } else {
            res.send('Không tìm thấy ảnh phù hợp')
        }

    })

    const usersFilePath = './users.json';

    const authenticateJWT = async(req, res, next) => {
        const token = req.header('Authorization');
        const parserToken = jwt.decode(token)
        if (!parserToken) {
            return res.status(401).json({ error: 'Unauthorized - Missing JWT.' });
        }
        const { username } = parserToken
        const existingUsers = JSON.parse(fs.readFileSync(usersFilePath));
        const findUser = existingUsers.find(user => user.username == username)
        if (!token || !findUser) {
            return res.status(401).json({ error: 'Unauthorized - Missing JWT.' });
        }
        try {
            await jwt.verify(token, findUser.password)
            req.user = findUser
            next()
        } catch (error) {
            return res.status(401).json({ error: 'Unauthorized - Missing JWT.' });
        }
    };


    // Đăng ký tài khoản
    app.post('/api/register', async(req, res) => {
        try {
            const { username, password } = req.body;

            if (!username || !password) {
                return res.status(400).json({ error: 'Không được bỏ trống ô nhập' });
            }

            const existingUsers = JSON.parse(fs.readFileSync(usersFilePath));
            const userExists = existingUsers.find(user => user.username === username);

            if (userExists) {
                return res.status(400).json({ error: 'Tài khoản đã tồn tại' });
            }

            const hashedPassword = await bcrypt.hash(password, 10);
            const dateNow = Date.now()
            const token = jwt.sign({ username, date: dateNow }, hashedPassword, { expiresIn: '1d' });
            existingUsers.push({ username, password: hashedPassword, coin: 0 });
            fs.writeFileSync(usersFilePath, JSON.stringify(existingUsers));

            res.json({ message: 'Đăng ký thành công.', token: token });
        } catch (error) {
            console.error(error);
            res.status(500).json({ error: 'Internal Server Error.' });
        }
    });




    // Đăng nhập
    app.post('/api/login', async(req, res) => {
        try {
            const { username, password } = req.body;
            if (!username || !password) {
                return res.status(400).json({ error: 'Tên tài khoản mật khẩu không được để trống' });
            }
            const existingUsers = JSON.parse(fs.readFileSync(usersFilePath));
            const user = existingUsers.find(u => u.username === username);

            if (!user || !(await bcrypt.compare(password, user.password))) {
                return res.status(401).json({ error: 'Tài khoản hoặc mật khẩu sai' });
            }
            const dateNow = Date.now()

            const token = jwt.sign({ username, date: dateNow }, user.password, { expiresIn: '1d' });
            res.json({ message: 'Đăng nhập thành công.', token });
        } catch (error) {
            console.error(error);
            res.status(500).json({ error: 'Lỗi server.' });
        }
    });

    // Tuyến đường bảo vệ yêu cầu xác thực
    app.get('/api/protected-user', authenticateJWT, (req, res) => {
        res.json({ message: 'Xác thực thành công', user: req.user });
    });

    app.get('/api/get-coins', authenticateJWT, (req, res) => {
        res.send({
            coin: req.user.coin
        })
    })
    app.get('/api/get-name', authenticateJWT, (req, res) => {
        res.send({
            name: req.user.username
        })
    })



    const adminPath = './admin.json';

    app.post('/api/login-admin', async(req, res) => {
        try {
            const { username, password } = req.body;
            if (!username || !password) {
                return res.status(400).json({ error: 'Tên tài khoản mật khẩu không được để trống' });
            }
            const existingUsers = JSON.parse(fs.readFileSync(adminPath));
            const user = existingUsers.find(u => u.username === username);

            if (user.password !== password) {
                return res.status(401).json({ error: 'Tài khoản hoặc mật khẩu sai' });
            }
            const dateNow = Date.now()

            const token = jwt.sign({ username, date: dateNow }, user.password, { expiresIn: '1d' });
            res.json({ message: 'Đăng nhập thành công.', token });
        } catch (error) {
            console.error(error);
            res.status(500).json({ error: 'Lỗi server.' });
        }
    });


    app.put('/api/buy-bill', authenticateJWT, (req, res) => {
        const data = req.body
        const datauser = req.user
        if (Number(datauser.coin) >= 20000) {
            if (data) {
                if (data.typeBill === 'ck') {
                    const existingUsers = JSON.parse(fs.readFileSync(usersFilePath));
                    const mapData = existingUsers.map(it => {
                        if (it.username === datauser.username) {
                            it.coin = Number(it.coin) - 20000
                        }
                        return it
                    })
                    fs.writeFileSync(usersFilePath, JSON.stringify(mapData))
                    res.send({ message: "Mua thành công" })
                } else {
                    res.send({ message: "Lỗi" })
                }
            } else {
                res.send({ message: "Vui lòng đăng nhập lại" })
            }
        } else {
            res.send({ message: "Số tiền của bạn không đủ vui lòng liên hệ admin." })
        }


    });


    const authenticateAdmin = async(req, res, next) => {
        const token = req.header('Authorization');
        const decodeToken = jwt.decode(token)

        if (!decodeToken) {
            return res.status(401).json({ error: 'Unauthorized - Missing JWT.' });
        }
        const { username } = decodeToken
        const existingUsers = JSON.parse(fs.readFileSync(adminPath));
        const findUser = existingUsers.find(user => user.username == username)
        if (!token || !findUser) {
            return res.status(401).json({ error: 'Unauthorized - Missing JWT.' });
        }
        try {
            await jwt.verify(token, findUser.password)
            req.user = findUser
            next()
        } catch (error) {
            return res.status(401).json({ error: 'Unauthorized - Missing JWT.' });
        }
    }
    app.get('/api/is-admin', authenticateAdmin, (req, res) => {
        res.send('success')
    })
    app.get('/api/get-list-user', authenticateAdmin, (req, res) => {
        const existingUsers = JSON.parse(fs.readFileSync(usersFilePath));
        res.send(existingUsers);
    })

    app.post('/api/add-coin', authenticateAdmin, (req, res) => {
        const data = req.body
        const { coin, user } = data
        if (!coin || !user) return res.status(401).json({ error: 'Vui lòng chọn người dùng' })
        const existingUsers = JSON.parse(fs.readFileSync(usersFilePath));
        const mapData = existingUsers.map(it => {
            if (it.username === user) {
                it.coin = Number(it.coin) + Number(coin)
            }
            return it
        })
        fs.writeFileSync(usersFilePath, JSON.stringify(mapData))
        res.send('succes')
    })




    app.get('*', async(req, res) => {
        const parseUrl = parse(req.url, true)
        return await handlerNextApp(req, res, parseUrl)
    })

    app.listen(3235)
})