
import axios from "axios";
import { API_KEY } from "src/configs/api";

export default async function isAdmin(auth: any) {

    const dataAdmin = await axios.get(`${API_KEY.endpoint}/is-admin`, {
        headers: {
            Authorization: `Bearer ${auth}`
        }
    })
    return dataAdmin.data

}