// ** React Imports
import { useState, ChangeEvent, useEffect } from 'react'

// ** MUI Imports
import Paper from '@mui/material/Paper'
import Table from '@mui/material/Table'
import TableRow from '@mui/material/TableRow'
import TableHead from '@mui/material/TableHead'
import TableBody from '@mui/material/TableBody'
import TableCell from '@mui/material/TableCell'
import TableContainer from '@mui/material/TableContainer'
import TablePagination from '@mui/material/TablePagination'
import { socket } from 'src/@core/hooks/socket'
import axios from 'axios'
import { API_KEY } from 'src/configs/api'



interface Column {
  id: 'fees' | 'banking' | 'coin' | 'nameCoin' | 'namebanking' | 'date' |'confirm'
  label: string
  minWidth?: number
  align?: 'right' | 'center'
  format?: (value: number) => string
}

const columns:readonly Column[] = [

  { id: 'coin', label: 'Số tiền', minWidth: 170 },
  { id: 'fees', label: 'Phí rút', minWidth: 100 },
  {
    id: 'banking',
    label: 'Số tài khoản',
    minWidth: 170,
    align: 'center',
    format: (value: number) => value.toLocaleString('en-US')
  },
  {
    id: 'namebanking',
    label: 'Tên ngân hàng',
    minWidth: 170,
    align: 'center',
    format: (value: number) => value.toLocaleString('en-US')
  },
  {
    id: 'date',
    label: 'Thời gian yêu cầu',
    minWidth: 170,
    align: 'center',
    format: (value: number) => value.toFixed(2)
  },
  {

    id: 'confirm',
    label: 'Xác nhận',
    minWidth: 170,
    align: 'center',
    format: (value: number) => value.toFixed(2)

  }
]



function createData(email: string, code: string, population: number, size: number) {
  const density = population / size + 2222

  return { email, code, population, size, density }
}


type Props = {
  email: any
}
const TableDraw: React.FC<Props> = (props) => {
  function formatTimeAgo(milliseconds: any) {
    const now = Math.floor(Date.now()); // Lấy thời gian hiện tại dưới dạng mili giây
    const elapsed = now - milliseconds;

    if (elapsed < 60000) { // 60 giây
      return `${Math.floor(elapsed / 1000)} giây trước`;
    } else if (elapsed < 3600000) { // 60 phút
      const minutes = Math.floor(elapsed / 60000);
      return `${minutes} phút trước`;
    } else if (elapsed < 86400000) { // 24 giờ
      const hours = Math.floor(elapsed / 3600000);
      return `${hours} giờ trước`;
    } else if (elapsed < 2592000000) { // 30 ngày
      const days = Math.floor(elapsed / 86400000);
      return `${days} ngày trước`;
    } else if (elapsed < 31536000000) { // 365 ngày
      const months = Math.floor(elapsed / 2592000000);
      return `${months} tháng trước`;
    } else {
      const years = Math.floor(elapsed / 31536000000);
      return `${years} năm trước`;
    }
  }
  const formatCoin = (number: any) => {
    const formattedNumber = number.toLocaleString('en-US', {
        style: 'decimal',
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
    });
    return formattedNumber;
}
  const { email } = props
  // ** States
  const [dataCart, setDataBill] = useState<any>([])
  const rows = dataCart
  useEffect(() => {
    const getData = async () => {
      if (Boolean(email)) {
        socket.emit('bill-user', { email: email })
      }

    }
    getData()
    socket.on('send-bill', ({ data, approveCart }) => {

      setDataBill(data)
    })
  }, [email])

  const [page, setPage] = useState<number>(0)
  const [rowsPerPage, setRowsPerPage] = useState<number>(10)

  const handleChangePage = (event: unknown, newPage: number) => {
    setPage(newPage)
  }

  const handleChangeRowsPerPage = (event: ChangeEvent<HTMLInputElement>) => {
    setRowsPerPage(+event.target.value)
    setPage(0)
  }
  const valueOption = ''
  return (
    <Paper sx={{ width: '100%', overflow: 'hidden' }}>
      <TableContainer sx={{ maxHeight: 440 }}>
        <Table stickyHeader aria-label='sticky table'>
          <TableHead>
            <TableRow>
              {columns.map(column => (
                <TableCell key={column.id} align={column.align} sx={{ minWidth: column.minWidth }}>
                  {column.label}
                </TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((row:any) => {
              if(row.type ==2){
                return (
                  <TableRow hover role='checkbox' tabIndex={-1} key={row.code}>
                    {columns.map(column => {
                      const value = row[column.id]
                      if (column.id == 'date') {
                        return (
                          <TableCell key={column.id} align={column.align}>
                            {formatTimeAgo(value)}
                          </TableCell>
                        )
                      } else if (column.id == 'confirm') {
                        const valueConfirm = row.status
                        if(valueConfirm==0){
                          return (
                            <TableCell key={column.id} align={column.align}>
                             <span onClick={()=>{
                              const token = localStorage.getItem('tokenAdmin');
                              if(token){
                                console.log(token);
                                axios.put(`${API_KEY.endpoint}/admin-withdraw`,{
                                  token:token,
                                  id:row.id
                                 })
                              }
                           
                             }} className='warningsBt'>Chọn để chuyển</span>
                            </TableCell>
                          )
                        }else{
                          return (
                            <TableCell key={column.id} align={column.align}>
                              <span className='successBt'>Thành công</span>
                            </TableCell>
                          )
                        }
                       
  
                      } else if (column.id == 'fees') {
                        const fees = (2 / 100) * Number(row.coin)
                        return (
                          <TableCell key={column.id} align={column.align}>
                      {formatCoin(Number(fees))}
                          </TableCell>
                        )
                      } else if (column.id == 'coin') {
                        const coin = Number(row.coin) - ((2 / 100) * Number(row.coin))
                        return (
                          <TableCell key={column.id} align={column.align}>
                            {formatCoin(Number(coin))}
                          </TableCell>
                        )
                      } else {
                        return (
                          <TableCell key={column.id} align={column.align}>
                            {value}
                          </TableCell>
                        )
                      }
  
                    })}
                  </TableRow>
                )
              }
             
            })}
          </TableBody>
        </Table>
      </TableContainer>
      <TablePagination
        rowsPerPageOptions={[10, 25, 100]}
        component='div'
        count={rows.length}
        rowsPerPage={rowsPerPage}
        page={page}
        onPageChange={handleChangePage}
        onRowsPerPageChange={handleChangeRowsPerPage}
      />
    </Paper>
  )
}

export default TableDraw
