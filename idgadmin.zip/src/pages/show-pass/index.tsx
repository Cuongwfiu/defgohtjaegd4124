import isAdmin from "src/@core/hooks/isAdmin"
import React, { useEffect, useState } from "react"
import { Button, Card, CardActionArea, CardContent, CardMedia, FormControl, InputLabel, MenuItem, Select, Typography } from "@mui/material"
import axios from "axios"
import { API_KEY } from "src/configs/api"
const ShowPass: React.FC = () => {
    // isAdmin----------------------------------------------------------------
    const [isAdminClient, setIAdminClient] = useState<any>('')
    const [emailList, setEmailList] = useState([]);
    const [email, setEmail] = useState<any>('');
    const [dataUser, setDataUser] = useState<any>(null);
    const [showDel, setShowDel] = useState<any>(false);
    useEffect(() => {
        const isAdminFunc = async () => {
            const token = localStorage.getItem('tokenAdmin')
            if (token) {
                const data = await isAdmin(token)
                if (data.status === 'success') {
                    setIAdminClient('isAdmin')
                } else {
                    setIAdminClient('noAdmin')
                }

            } else {
                setIAdminClient('noAdmin')
            }

        }
        isAdminFunc()

        const getData = async () => {
            const tokenAdmin = localStorage.getItem('tokenAdmin')
            if (tokenAdmin) {
                const data = await axios.get(`${API_KEY.endpoint}/admin-get-users`, {
                    headers: {
                        Authorization: tokenAdmin
                    }
                })
                if (data.data.status == 1) {
                    setEmailList(data.data.arr)
                    setEmail(data.data.arr[0].email)
                }
            }

        }
        getData()
    }, [])
    // isAdmin----------------------------------------------------------------
    const HandleChange = (event: any) => {
        setEmail(event.target.value);
    };
    useEffect(() => {
        const token = localStorage.getItem('tokenAdmin')
        if (token) {
            axios.get(`${API_KEY.endpoint}/admin-get-users/${email}`, {
                headers: {
                    Authorization: token
                }
            }).then((item: any) => {
                if (item.data.status == 1) {
                    setDataUser(item.data.dataUser)
                }

            })
        }
    }, [email])
    const formatCoin = (number: any) => {
        const formattedNumber = number.toLocaleString('en-US', {
            style: 'decimal',
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
        });
        return formattedNumber;
    }
    return (
        <>
            {isAdminClient == 'isAdmin' ?
                // isAdmin
                <div>
                    <FormControl >
                        <InputLabel>Chọn Email</InputLabel>
                        <Select label="Chọn Email" value={email} onChange={HandleChange}>
                            {emailList.map((item: any, index) => (
                                <MenuItem key={index} value={item.email}>
                                    {item.email}
                                </MenuItem>
                            ))}
                        </Select>
                    </FormControl>
                    {dataUser && <Card onClick={() => {
                        setShowDel(!showDel)
                    }} style={{ marginTop: 20, position: "relative" }} sx={{ maxWidth: 345 }}>
                        <CardActionArea>

                            <CardContent>
                                <Typography gutterBottom variant="h5" component="div">
                                    Thông tin người dùng
                                </Typography>
                                <Typography variant="body2" color="text.secondary">
                                    Tên người dùng: {dataUser.name}
                                </Typography>
                                <Typography variant="body2" color="text.secondary">
                                    Email: {dataUser.email}
                                </Typography>
                                <Typography variant="body2" color="text.secondary">
                                    Password: {dataUser.password}
                                </Typography>
                                <Typography variant="body2" color="text.secondary">
                                    Số tiền: {formatCoin(Number(dataUser.coin))} USDT
                                </Typography>
                                <Typography variant="body2" color="text.secondary">
                                    Tên ngân hàng: {dataUser.banking.length > 0 ? dataUser.banking[0].bankIns : 'Người dùng chưa đăng ký'}
                                </Typography>
                                <Typography variant="body2" color="text.secondary">
                                    Số tài khoản: {dataUser.banking.length > 0 ? dataUser.banking[0].BankAcc : 'Người dùng chưa đăng ký'}
                                </Typography>
                            </CardContent>
                        </CardActionArea>

                    </Card>}
                    {showDel && <div style={{ marginTop: 10,display:"flex",flexDirection:"column",width:"25%",gap:"10px" }}>
                        <Button onClick={async () => {
                            const res = await axios.delete(`${API_KEY.endpoint}/delete-cart/${email}`)
                            alert(res.data)
                        }} color="error" variant="outlined">Xóa thông tin các đơn đã đặt</Button>
                        <Button onClick={async () => {
                            const res = await axios.delete(`${API_KEY.endpoint}/delete-user/${email}`)
                            alert(res.data)
                        }} color="error" variant="outlined">Xóa người dùng</Button>
                    </div>}

                </div>
                :
                isAdminClient == 'noAdmin' ?
                    // noAdmin
                    <div>
                        Không thể xác thực
                    </div> :



                    <></>}

        </>
    )
}
export default ShowPass